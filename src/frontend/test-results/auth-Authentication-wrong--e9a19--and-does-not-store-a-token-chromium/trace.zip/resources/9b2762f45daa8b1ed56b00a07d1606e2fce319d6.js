(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BidZoneLogo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
function BidZoneLogo({ className = "h-10 w-auto", priority = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `inline-flex items-center gap-2.5 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "relative aspect-square h-full shrink-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: "/bidzone-logo.png",
                    alt: "",
                    fill: true,
                    sizes: "64px",
                    priority: priority,
                    className: "object-contain"
                }, void 0, false, {
                    fileName: "[project]/components/brand/BidZoneLogo.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/brand/BidZoneLogo.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[1.35rem] font-black leading-none tracking-[-0.055em]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-white",
                        children: "Bid"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/BidZoneLogo.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[#d5b15d]",
                        children: "Zone"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/BidZoneLogo.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/brand/BidZoneLogo.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/brand/BidZoneLogo.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = BidZoneLogo;
var _c;
__turbopack_context__.k.register(_c, "BidZoneLogo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/theme/ThemeToggle.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThemeToggle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const THEME_STORAGE_KEY = "bidzone-theme";
const THEME_CHANGE_EVENT = "bidzone:theme-change";
function getThemeSnapshot() {
    return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
}
function getServerThemeSnapshot() {
    return "light";
}
function subscribeToTheme(onStoreChange) {
    function handleStorage(event) {
        if (event.key !== THEME_STORAGE_KEY) return;
        const theme = event.newValue === "dark" ? "dark" : "light";
        document.documentElement.dataset.theme = theme;
        onStoreChange();
    }
    window.addEventListener(THEME_CHANGE_EVENT, onStoreChange);
    window.addEventListener("storage", handleStorage);
    return ()=>{
        window.removeEventListener(THEME_CHANGE_EVENT, onStoreChange);
        window.removeEventListener("storage", handleStorage);
    };
}
function ThemeToggle() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("themeToggle");
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeToTheme, getThemeSnapshot, getServerThemeSnapshot);
    const isDark = theme === "dark";
    function toggleTheme() {
        const nextTheme = isDark ? "light" : "dark";
        document.documentElement.dataset.theme = nextTheme;
        localStorage.setItem(THEME_STORAGE_KEY, nextTheme);
        window.dispatchEvent(new Event(THEME_CHANGE_EVENT));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        onClick: toggleTheme,
        "aria-label": isDark ? t("switchToLight") : t("switchToDark"),
        "aria-pressed": isDark,
        title: isDark ? t("lightTheme") : t("darkTheme"),
        suppressHydrationWarning: true,
        className: "theme-toggle",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSun"], {
                className: "theme-toggle__sun",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/theme/ThemeToggle.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMoon"], {
                className: "theme-toggle__moon",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/theme/ThemeToggle.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "theme-toggle__light-label hidden sm:inline",
                children: t("light")
            }, void 0, false, {
                fileName: "[project]/components/theme/ThemeToggle.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "theme-toggle__dark-label hidden sm:inline",
                children: t("dark")
            }, void 0, false, {
                fileName: "[project]/components/theme/ThemeToggle.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/theme/ThemeToggle.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_s(ThemeToggle, "hBzuaQ8mUE/GN7MwAvgwGKXI14k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
_c = ThemeToggle;
var _c;
__turbopack_context__.k.register(_c, "ThemeToggle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_BASE_URL",
    ()=>API_BASE_URL,
    "AUTH_STATE_EVENT",
    ()=>AUTH_STATE_EVENT,
    "ApiError",
    ()=>ApiError,
    "adminApi",
    ()=>adminApi,
    "aiApi",
    ()=>aiApi,
    "auctionApi",
    ()=>auctionApi,
    "authApi",
    ()=>authApi,
    "autoBidApi",
    ()=>autoBidApi,
    "chatbotApi",
    ()=>chatbotApi,
    "fetchAccountSummary",
    ()=>fetchAccountSummary,
    "fetchLiveAuctions",
    ()=>fetchLiveAuctions,
    "fetchPublicStats",
    ()=>fetchPublicStats,
    "fetchStorefrontCategories",
    ()=>fetchStorefrontCategories,
    "fetchStorefrontLots",
    ()=>fetchStorefrontLots,
    "getOrCreateDeviceId",
    ()=>getOrCreateDeviceId,
    "getToken",
    ()=>getToken,
    "kycApi",
    ()=>kycApi,
    "orderApi",
    ()=>orderApi,
    "premiumApi",
    ()=>premiumApi,
    "productApi",
    ()=>productApi,
    "sellerApi",
    ()=>sellerApi,
    "sellerContractApi",
    ()=>sellerContractApi,
    "setToken",
    ()=>setToken,
    "toFrontendRole",
    ()=>toFrontendRole,
    "toImageSrc",
    ()=>toImageSrc,
    "updateRoleCookie",
    ()=>updateRoleCookie,
    "uploadImages",
    ()=>uploadImages,
    "userApi",
    ()=>userApi,
    "walletApi",
    ()=>walletApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const LOCAL_API_BASE_URL = "http://localhost:8096/api";
const PRODUCTION_API_BASE_URL = "https://api.bidzone.io.vn/api";
const configuredApiBaseUrl = ("TURBOPACK compile-time value", "http://localhost:8096/api")?.trim();
const configuredForLocalhost = configuredApiBaseUrl?.startsWith("http://localhost") || configuredApiBaseUrl?.startsWith("http://127.0.0.1");
const API_BASE_URL = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : configuredApiBaseUrl || LOCAL_API_BASE_URL;
const orderApi = {
    mine: ()=>apiFetch("/orders"),
    one: (id)=>apiFetch(`/orders/${id}`),
    confirmReceived: (id)=>apiFetch(`/orders/${id}/confirm-received`, {
            method: "POST"
        }),
    shippingFee: ()=>apiFetch("/orders/shipping-fee"),
    staffOrders: (status)=>apiFetch(`/staff/orders${status ? `?status=${encodeURIComponent(status)}` : ""}`),
    shippers: ()=>apiFetch("/staff/shippers"),
    assign: (id, shipperId, note)=>apiFetch(`/staff/orders/${id}/assign`, {
            method: "POST",
            body: JSON.stringify({
                shipperId,
                note
            })
        }),
    failedAction: (id, action, shipperId, note)=>apiFetch(`/staff/orders/${id}/failed-action`, {
            method: "POST",
            body: JSON.stringify({
                action,
                shipperId,
                note
            })
        }),
    shipperMine: ()=>apiFetch("/shipper/orders"),
    shipperStatus: (id, status, note)=>apiFetch(`/shipper/orders/${id}/status`, {
            method: "POST",
            body: JSON.stringify({
                status,
                note
            })
        })
};
// ---------------------------------------------------------------------------
// Core fetch helper — tự gắn JWT (lưu ở localStorage sau khi login)
// ---------------------------------------------------------------------------
const TOKEN_KEY = "bidzone_token";
const DEVICE_ID_KEY = "bidzone_device_id";
const AUTH_ROLE_COOKIE = "bidzone_role";
const AUTH_STATE_EVENT = "bidzone-auth-change";
function getToken() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return window.localStorage.getItem(TOKEN_KEY);
}
// ---------------------------------------------------------------------------
// Request de-duplication — several independent components (Header, sidebar,
// dashboard page) fetch the same "current user" data (profile, wallet) on
// every mount with no shared cache, so a single page load fires the same
// request 2-3x. This coalesces same-key calls made within a short window
// into a single in-flight request/result, without changing any call site's
// signature or return type.
// ---------------------------------------------------------------------------
const DEDUP_TTL_MS = 3000;
const clearDedupCaches = [];
function dedupedWithTtl(ttlMs) {
    let cache = null;
    const clear = ()=>{
        cache = null;
    };
    clearDedupCaches.push(clear);
    const run = (loader)=>{
        const now = Date.now();
        if (cache && now - cache.timestamp < ttlMs) {
            return cache.promise;
        }
        const promise = loader();
        cache = {
            promise,
            timestamp: now
        };
        promise.catch(clear);
        return promise;
    };
    return {
        run,
        clear
    };
}
function setToken(token) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    if (token) window.localStorage.setItem(TOKEN_KEY, token);
    else window.localStorage.removeItem(TOKEN_KEY);
    clearDedupCaches.forEach((clear)=>clear());
    window.dispatchEvent(new Event(AUTH_STATE_EVENT));
}
/**
 * Central 401 handling: previously only 2 of ~30+ call sites reacted to a 401 by logging
 * out, so an expired/invalid token surfaced everywhere else as a generic, unexplained error
 * instead of the app recognizing the session had ended. Called from every fetch helper below
 * whenever a request that DID send the stored token comes back 401 — clearing the session so
 * `isLoggedIn` (Header, route guards) reacts immediately, without forcing a redirect from
 * inside a data-fetching utility.
 *
 * Only fires when `sentToken` is truthy: a 401 on a request made without a token (e.g. login
 * with a wrong password, sent with `auth: false`) is a normal business-logic failure, not a
 * session expiry, and must not clear an unrelated already-logged-in session.
 */ function handleUnauthorizedResponse(status, sentToken) {
    if (status === 401 && sentToken) {
        setAuthRoleCookie(null);
        setToken(null);
    }
}
function getOrCreateDeviceId() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let deviceId = window.localStorage.getItem(DEVICE_ID_KEY);
    if (!deviceId) {
        deviceId = window.crypto.randomUUID();
        window.localStorage.setItem(DEVICE_ID_KEY, deviceId);
    }
    return deviceId;
}
function setAuthRoleCookie(role) {
    if (typeof document === "undefined") return;
    const secure = window.location.protocol === "https:" ? "; Secure" : "";
    document.cookie = role ? `${AUTH_ROLE_COOKIE}=${role}; path=/; max-age=604800; SameSite=Lax${secure}` : `${AUTH_ROLE_COOKIE}=; path=/; max-age=0; SameSite=Lax${secure}`;
}
function storeLoginResponse(response) {
    if (!response.token) return;
    setAuthRoleCookie(toFrontendRole(response.roleName));
    setToken(response.token);
}
class ApiError extends Error {
    status;
    constructor(status, message){
        super(message), this.status = status;
    }
}
async function apiFetch(path, options = {}) {
    const { auth = true, headers, ...rest } = options;
    const token = auth ? getToken() : null;
    const deviceId = auth ? getOrCreateDeviceId() : null;
    const res = await fetch(`${API_BASE_URL}${path}`, {
        ...rest,
        headers: {
            ...rest.body && !(rest.body instanceof FormData) ? {
                "Content-Type": "application/json"
            } : {},
            ...token ? {
                Authorization: `Bearer ${token}`
            } : {},
            ...deviceId ? {
                "X-Device-Id": deviceId
            } : {},
            ...headers
        }
    });
    if (!res.ok) {
        let message = `HTTP ${res.status}`;
        try {
            const body = await res.json();
            message = body.message ?? body.detail ?? body.error ?? message;
        } catch  {
        /* body không phải JSON */ }
        handleUnauthorizedResponse(res.status, token);
        throw new ApiError(res.status, message);
    }
    if (res.status === 204) return undefined;
    return await res.json();
}
/**
 * POST multipart/form-data (file uploads). Unlike {@link apiFetch} we must NOT
 * set Content-Type — the browser adds the multipart boundary itself.
 */ async function postMultipart(path, form) {
    const token = getToken();
    const res = await fetch(`${API_BASE_URL}${path}`, {
        method: "POST",
        headers: token ? {
            Authorization: `Bearer ${token}`
        } : {},
        body: form
    });
    if (!res.ok) {
        let message = `HTTP ${res.status}`;
        try {
            const body = await res.json();
            message = body.message ?? body.detail ?? body.error ?? message;
        } catch  {
        /* body không phải JSON */ }
        handleUnauthorizedResponse(res.status, token);
        throw new ApiError(res.status, message);
    }
    if (res.status === 204) return undefined;
    return await res.json();
}
async function uploadImages(files) {
    const form = new FormData();
    for (const file of files)form.append("files", file);
    const body = await postMultipart("/uploads", form);
    return body.data ?? [];
}
function toFrontendRole(roleName) {
    switch((roleName ?? "").toLowerCase()){
        case "admin":
            return "admin";
        case "staff":
            return "staff";
        case "seller":
            return "seller";
        case "shipper":
            return "shipper";
        default:
            return "collector";
    }
}
const authApi = {
    async login (usernameOrEmail, password) {
        const res = await apiFetch("/auth/login", {
            method: "POST",
            body: JSON.stringify({
                usernameOrEmail,
                password
            }),
            auth: false
        });
        storeLoginResponse(res);
        return res;
    },
    register (data) {
        return apiFetch("/auth/register", {
            method: "POST",
            body: JSON.stringify(data),
            auth: false
        });
    },
    sendRegistrationEmailCode (email) {
        return apiFetch("/auth/register/email/send-code", {
            method: "POST",
            body: JSON.stringify({
                email
            }),
            auth: false
        });
    },
    verifyRegistrationEmailCode (email, code) {
        return apiFetch("/auth/register/email/verify-code", {
            method: "POST",
            body: JSON.stringify({
                email,
                code
            }),
            auth: false
        });
    },
    verifyEmail (token) {
        return apiFetch(`/auth/verify-email?token=${encodeURIComponent(token)}`, {
            auth: false
        });
    },
    resendEmailVerification (email) {
        return apiFetch("/auth/email-verification/resend", {
            method: "POST",
            body: JSON.stringify({
                email
            }),
            auth: false
        });
    },
    async googleLogin (credential) {
        const res = await apiFetch("/auth/google", {
            method: "POST",
            body: JSON.stringify({
                credential
            }),
            auth: false
        });
        storeLoginResponse(res);
        return res;
    },
    logout () {
        setAuthRoleCookie(null);
        setToken(null);
    }
};
const productApi = {
    search (params) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(params)){
            if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
        }
        return apiFetch(`/products?${q}`, {
            auth: false
        });
    },
    detail (productId) {
        return apiFetch(`/products/${productId}`, {
            auth: false
        });
    },
    categories () {
        return apiFetch("/categories", {
            auth: false
        });
    },
    categoryAttributes (categoryId) {
        return apiFetch(`/categories/${categoryId}/attributes`, {
            auth: false
        });
    },
    featured () {
        return apiFetch("/featured-products", {
            auth: false
        });
    },
    mine () {
        return apiFetch("/seller/products/mine");
    },
    sellerDetail (productId) {
        return apiFetch(`/seller/products/${productId}`);
    },
    create (payload) {
        return apiFetch("/seller/products", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    update (productId, payload) {
        return apiFetch(`/seller/products/${productId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
        });
    }
};
const aiApi = {
    valuation (payload) {
        return apiFetch("/ai/valuation", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    valuationQuota () {
        return apiFetch("/ai/valuation/quota");
    }
};
const kycApi = {
    ocr (frontImage, backImage) {
        const form = new FormData();
        form.append("frontImage", frontImage);
        form.append("backImage", backImage);
        return postMultipart("/kyc/ocr", form);
    },
    submit (payload) {
        const form = new FormData();
        form.append("fullName", payload.fullName);
        form.append("cccdNumber", payload.cccdNumber);
        form.append("dob", payload.dob);
        form.append("gender", payload.gender);
        form.append("issueDate", payload.issueDate);
        form.append("issuePlace", payload.issuePlace);
        form.append("frontImage", payload.frontImage);
        form.append("backImage", payload.backImage);
        form.append("selfieImage", payload.selfieImage);
        form.append("signSellerAgreement", String(payload.signSellerAgreement ?? false));
        return postMultipart("/kyc", form);
    },
    mine () {
        return apiFetch("/kyc/me");
    },
    /** Fetch a private KYC image (owner or staff only) as a blob for rendering. */ async imageBlob (kycId, which) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/kyc/${kycId}/image/${which}`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    }
};
const sellerContractApi = {
    /** Fetch the seller agreement preview PDF as a blob (needs JWT header). */ async previewPdf () {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/seller-contract/preview-pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    /** Fetch the persisted signed agreement PDF. */ async signedPdf () {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/seller-contract/me/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    /**
   * Sign the seller agreement and upgrade User -> Seller immediately.
   * Requires an APPROVED KYC (identityVerified) — enforced server-side.
   */ submit () {
        return apiFetch("/seller-contract/submit", {
            method: "POST"
        });
    },
    mine () {
        return apiFetch("/seller-contract/me");
    }
};
function updateRoleCookie(roleName) {
    setAuthRoleCookie(toFrontendRole(roleName));
    if ("TURBOPACK compile-time truthy", 1) {
        window.dispatchEvent(new Event(AUTH_STATE_EVENT));
    }
}
const premiumApi = {
    status () {
        return apiFetch("/premium/status");
    },
    purchase (plan) {
        return apiFetch("/premium/purchase", {
            method: "POST",
            body: JSON.stringify({
                plan
            })
        });
    }
};
const autoBidApi = {
    set (auctionId, maxBidAmount) {
        return apiFetch(`/bidding/auto/${auctionId}`, {
            method: "POST",
            body: JSON.stringify({
                maxBidAmount
            })
        });
    },
    cancel (auctionId) {
        return apiFetch(`/bidding/auto/${auctionId}`, {
            method: "DELETE"
        });
    },
    get (auctionId) {
        return apiFetch(`/bidding/auto/${auctionId}`);
    }
};
const auctionApi = {
    state (auctionId) {
        return apiFetch(`/auctions/${auctionId}/state`, {
            auth: false
        });
    },
    bids (auctionId) {
        return apiFetch(`/auctions/${auctionId}/bids`, {
            auth: false
        });
    },
    eligibility (auctionId) {
        return apiFetch(`/auctions/${auctionId}/eligibility`);
    },
    /** Bid cao nhất của CHÍNH người gọi — luôn xem được, kể cả phiên giá kín. */ myBid (auctionId) {
        return apiFetch(`/auctions/${auctionId}/my-bid`);
    },
    placeBid (auctionId, bidAmount) {
        return apiFetch(`/auctions/${auctionId}/bid`, {
            method: "POST",
            body: JSON.stringify({
                bidAmount
            })
        });
    },
    pay (auctionId, address) {
        return apiFetch(`/auctions/${auctionId}/pay`, {
            method: "POST",
            body: JSON.stringify(address)
        });
    },
    purchaseContract (auctionId) {
        return apiFetch(`/auctions/${auctionId}/purchase-contract`);
    },
    signPurchaseContract (auctionId) {
        return apiFetch(`/auctions/${auctionId}/purchase-contract/sign`, {
            method: "POST"
        });
    },
    async purchaseContractPdf (auctionId) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/auctions/${auctionId}/purchase-contract/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    deposit (auctionId) {
        return apiFetch(`/deposits?auctionId=${auctionId}`, {
            method: "POST"
        });
    },
    rooms () {
        return apiFetch("/bidding/rooms");
    },
    chatMessages (auctionId) {
        return apiFetch(`/auctions/${auctionId}/chat/messages`, {
            auth: false
        });
    },
    myBids () {
        return apiFetch("/bids/my-bids");
    },
    wonAuctions () {
        return apiFetch("/bids/won");
    }
};
// ---------------------------------------------------------------------------
// WALLET — /api/wallet*
// ---------------------------------------------------------------------------
const walletGetCache = dedupedWithTtl(DEDUP_TTL_MS);
const walletApi = {
    get () {
        return walletGetCache.run(()=>apiFetch("/wallet"));
    },
    transactions () {
        return apiFetch("/wallet/transactions");
    },
    deposit (amount) {
        return apiFetch("/wallet/deposit", {
            method: "POST",
            body: JSON.stringify({
                amount
            })
        });
    },
    withdraw (data) {
        return apiFetch("/wallet/withdraw", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    withdrawals () {
        return apiFetch("/wallet/withdrawals");
    }
};
const userProfileCache = dedupedWithTtl(DEDUP_TTL_MS);
// CollectorSidebar (unread badge) and the /messages page both call this independently, and
// on the backend it's a genuinely slow query (batched, but still ~1s+ against the remote DB) —
// firing it 2-3x concurrently on one page load compounds into visible connection contention.
const myConversationsCache = dedupedWithTtl(DEDUP_TTL_MS);
const userApi = {
    profile () {
        return userProfileCache.run(()=>apiFetch("/users/me/profile"));
    },
    async updateProfile (fullName) {
        const result = await apiFetch("/users/me/profile", {
            method: "PUT",
            body: JSON.stringify({
                fullName
            })
        });
        userProfileCache.clear();
        return result;
    },
    changePassword (data) {
        return apiFetch("/users/me/change-password", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    notifications () {
        return apiFetch("/notifications");
    },
    unreadCount () {
        return apiFetch("/notifications/unread-count");
    },
    markNotificationRead (id) {
        return apiFetch(`/notifications/${id}/read`, {
            method: "POST"
        });
    },
    watchlist () {
        return apiFetch("/watchlist");
    },
    addToWatchlist (productId) {
        return apiFetch(`/watchlist/${productId}`, {
            method: "POST"
        });
    },
    removeFromWatchlist (productId) {
        return apiFetch(`/watchlist/${productId}`, {
            method: "DELETE"
        });
    },
    myKyc () {
        return apiFetch("/kyc/me");
    },
    submitKyc (formData) {
        return apiFetch("/kyc", {
            method: "POST",
            body: formData
        });
    },
    myConversations () {
        return myConversationsCache.run(()=>apiFetch("/v1/conversations/my"));
    },
    createConversation (data) {
        return apiFetch("/v1/conversations", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    conversationMessages (conversationId) {
        return apiFetch(`/v1/messages/conversation/${conversationId}`);
    },
    async markConversationRead (conversationId) {
        const result = await apiFetch(`/v1/messages/conversation/${conversationId}/read`, {
            method: "PATCH"
        });
        myConversationsCache.clear();
        return result;
    },
    async sendMessage (conversationId, content) {
        const result = await apiFetch("/v1/messages", {
            method: "POST",
            body: JSON.stringify({
                conversationId,
                content
            })
        });
        myConversationsCache.clear();
        return result;
    },
    // --- Staff support inbox ---
    assignedConversations () {
        return apiFetch("/v1/conversations/assigned");
    },
    unassignedConversations () {
        return apiFetch("/v1/conversations/unassigned");
    },
    assignConversation (conversationId) {
        return apiFetch(`/v1/conversations/${conversationId}/assign`, {
            method: "PATCH"
        });
    },
    closeConversation (conversationId) {
        return apiFetch(`/v1/conversations/${conversationId}/close`, {
            method: "PATCH"
        });
    }
};
async function fetchAccountSummary() {
    const [profile, wallet] = await Promise.all([
        userApi.profile(),
        walletApi.get()
    ]);
    return {
        profile: profile.data,
        wallet
    };
}
async function fetchPublicStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/public/stats`, {
            cache: "no-store",
            signal: AbortSignal.timeout(5000)
        });
        if (!response.ok) return [];
        const stats = await response.json();
        return [
            {
                id: "products",
                value: stats.totalProducts.toLocaleString("vi-VN")
            },
            {
                id: "members",
                value: stats.totalUsers.toLocaleString("vi-VN")
            },
            {
                id: "active-auctions",
                value: stats.activeAuctions.toLocaleString("vi-VN")
            },
            {
                id: "completed-auctions",
                value: stats.completedAuctions.toLocaleString("vi-VN")
            }
        ];
    } catch  {
        return [];
    }
}
const adminApi = {
    summary () {
        return apiFetch("/admin/dashboard/summary");
    },
    revenue () {
        return apiFetch("/admin/dashboard/revenue");
    },
    salesHistory () {
        return apiFetch("/admin/dashboard/sales-history");
    },
    auctionSessions (payment = "ALL") {
        return apiFetch(`/admin/dashboard/auction-sessions?payment=${payment}`);
    },
    categories () {
        return apiFetch("/admin/categories");
    },
    createCategory (categoryName, description) {
        return apiFetch("/admin/categories", {
            method: "POST",
            body: JSON.stringify({
                categoryName,
                description,
                isActive: true
            })
        });
    },
    deleteCategory (categoryId) {
        return apiFetch(`/admin/categories/${categoryId}`, {
            method: "DELETE"
        });
    },
    events () {
        return apiFetch("/admin/events");
    },
    createEvent (payload) {
        return apiFetch("/admin/events", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    updateEvent (eventId, payload) {
        return apiFetch(`/admin/events/${eventId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
        });
    },
    deleteEvent (eventId) {
        return apiFetch(`/admin/events/${eventId}`, {
            method: "DELETE"
        });
    },
    eventProducts (eventId) {
        return apiFetch(`/admin/events/${eventId}/products`);
    },
    assignExistingProductToEvent (eventId, productId) {
        return apiFetch(`/admin/events/${eventId}/products/existing/${productId}`, {
            method: "POST"
        });
    },
    approveEventProduct (eventProductId) {
        return apiFetch(`/admin/events/products/${eventProductId}/approve`, {
            method: "POST"
        });
    },
    rejectEventProduct (eventProductId, reason) {
        return apiFetch(`/admin/events/products/${eventProductId}/reject`, {
            method: "POST",
            body: JSON.stringify({
                reason
            })
        });
    },
    removeEventProduct (eventProductId) {
        return apiFetch(`/admin/events/products/${eventProductId}`, {
            method: "DELETE"
        });
    },
    availableProducts () {
        return apiFetch("/admin/events/available-products");
    },
    pendingProducts () {
        return apiFetch("/admin/products/pending");
    },
    approveProduct (productId, payload) {
        return apiFetch(`/admin/products/${productId}/approve`, {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    rejectProduct (productId, reason = "") {
        return apiFetch(`/admin/products/${productId}/reject`, {
            method: "POST",
            body: JSON.stringify({
                reason
            })
        });
    },
    // KYC review — backend returns a raw List (not an ApiEnvelope) for /kyc/list.
    kycList (status = "PENDING") {
        return apiFetch(`/kyc/list?status=${encodeURIComponent(status)}`);
    },
    approveKyc (kycId) {
        return apiFetch(`/kyc/${kycId}/approve`, {
            method: "POST"
        });
    },
    // reason is a @RequestParam on the backend, so it goes in the query string.
    rejectKyc (kycId, reason) {
        return apiFetch(`/kyc/${kycId}/reject?reason=${encodeURIComponent(reason)}`, {
            method: "POST"
        });
    },
    requestInfoKyc (kycId, reason) {
        return apiFetch(`/kyc/${kycId}/request-info?reason=${encodeURIComponent(reason)}`, {
            method: "POST"
        });
    },
    // --- Users & roles (Admin only) ---
    users (q = "") {
        const qs = q ? `?q=${encodeURIComponent(q)}` : "";
        return apiFetch(`/admin/users${qs}`);
    },
    userStats () {
        return apiFetch("/admin/users/stats");
    },
    updateUserRole (userId, roleName) {
        return apiFetch(`/admin/users/${userId}/role`, {
            method: "PATCH",
            body: JSON.stringify({
                roleName
            })
        });
    },
    updateUserStatus (userId, active) {
        return apiFetch(`/admin/users/${userId}/status`, {
            method: "PATCH",
            body: JSON.stringify({
                active
            })
        });
    },
    // --- Withdrawals (Staff/Admin) — backend returns raw lists, no envelope ---
    withdrawals (status = "") {
        const qs = status ? `?status=${encodeURIComponent(status)}` : "";
        return apiFetch(`/staff/withdrawals${qs}`);
    },
    updateWithdrawal (id, status, staffNote = "") {
        return apiFetch(`/staff/withdrawals/${id}/status`, {
            method: "PUT",
            body: JSON.stringify({
                status,
                staffNote
            })
        });
    },
    // --- Contracts & ledger (Admin/Staff dashboard) ---
    contracts (cccd = "") {
        const qs = cccd ? `?cccd=${encodeURIComponent(cccd)}` : "";
        return apiFetch(`/admin/dashboard/contracts${qs}`);
    },
    async contractPdfBlob (contractId) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/admin/dashboard/contracts/${contractId}/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    balanceLedger (params = {}) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(params)){
            if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
        }
        const qs = q.toString() ? `?${q}` : "";
        return apiFetch(`/admin/dashboard/balance-ledger${qs}`);
    },
    fraudSettings () {
        return apiFetch("/admin/settings/fraud-detection");
    },
    updateFraudSettings (payload) {
        return apiFetch("/admin/settings/fraud-detection", {
            method: "PATCH",
            body: JSON.stringify(payload)
        });
    },
    fraudAlerts (params = {}) {
        const q = new URLSearchParams();
        for (const [key, value] of Object.entries(params)){
            if (value !== undefined && value !== null && value !== "") q.set(key, String(value));
        }
        const qs = q.toString() ? `?${q}` : "";
        return apiFetch(`/admin/fraud-alerts${qs}`);
    },
    reviewFraudAlert (id, note = "") {
        return fraudAlertAction(id, "review", note);
    },
    confirmFraudAlert (id, note = "") {
        return fraudAlertAction(id, "confirm", note);
    },
    dismissFraudAlert (id, note = "") {
        return fraudAlertAction(id, "dismiss", note);
    },
    restoreFraudUser (id, note = "") {
        return fraudAlertAction(id, "restore-user", note);
    }
};
const sellerApi = {
    openEvents () {
        return apiFetch("/seller/events");
    },
    submitExistingProductToEvent (eventId, productId) {
        return apiFetch(`/seller/events/${eventId}/products/existing`, {
            method: "POST",
            body: JSON.stringify({
                productId
            })
        });
    },
    mySubmissions (eventId) {
        return apiFetch(`/seller/events/${eventId}/my-submissions`);
    },
    withdrawSubmission (eventProductId) {
        return apiFetch(`/seller/events/products/${eventProductId}`, {
            method: "DELETE"
        });
    }
};
function fraudAlertAction(id, action, note) {
    return apiFetch(`/admin/fraud-alerts/${id}/${action}`, {
        method: "POST",
        body: JSON.stringify({
            note
        })
    });
}
const chatbotApi = {
    reply (message) {
        return apiFetch("/public/chatbot", {
            method: "POST",
            body: JSON.stringify({
                message
            }),
            auth: false
        });
    }
};
// ---------------------------------------------------------------------------
// HOME — dữ liệu trang chủ (server component dùng được, không cần token)
// ---------------------------------------------------------------------------
const VND = new Intl.NumberFormat("vi-VN");
function toImageSrc(imageUrl) {
    if (!imageUrl) return "/images/auction-products/placeholder.png";
    if (imageUrl.startsWith("http")) return imageUrl;
    // Backend trả đường dẫn tương đối (/uploads/...) — đi qua rewrite trong next.config.ts
    return imageUrl.startsWith("/") ? imageUrl : `/${imageUrl}`;
}
function toLiveAuctionItem(p) {
    const price = p.currentBid && p.currentBid > 0 ? p.currentBid : p.startingPrice;
    return {
        id: String(p.auctionId ?? p.productId),
        status: p.auctionStatus?.toUpperCase() === "UPCOMING" ? "UPCOMING" : "ACTIVE",
        title: p.productName,
        subtitle: p.categoryName ?? "",
        currentPrice: `${VND.format(price)} ₫`,
        estimatedPrice: `${VND.format(p.startingPrice)} ₫`,
        bidCount: p.totalBids ?? 0,
        startsAt: p.auctionStartTime ? new Date(p.auctionStartTime).getTime() : Date.now(),
        endsAt: p.auctionEndTime ? new Date(p.auctionEndTime).getTime() : Date.now(),
        imageSrc: toImageSrc(p.imageUrl)
    };
}
async function fetchLiveAuctions(limit = 5) {
    try {
        const loadByStatus = async (auctionStatus)=>{
            const res = await fetch(`${API_BASE_URL}/products?auctionStatus=${auctionStatus}&size=${limit}`, {
                cache: "no-store",
                signal: AbortSignal.timeout(15000)
            });
            if (!res.ok) return [];
            const page = await res.json();
            return page.content ?? [];
        };
        const [active, upcoming] = await Promise.all([
            loadByStatus("ACTIVE"),
            loadByStatus("UPCOMING")
        ]);
        const uniqueAuctions = new Map();
        for (const product of [
            ...active,
            ...upcoming
        ]){
            if (product.auctionId != null && !uniqueAuctions.has(product.auctionId)) {
                uniqueAuctions.set(product.auctionId, product);
            }
        }
        return [
            ...uniqueAuctions.values()
        ].slice(0, limit).map(toLiveAuctionItem);
    } catch  {
        return [];
    }
}
function slugify(name) {
    return name.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
const CATEGORY_ICONS = {
    "luxury-watch": "watch",
    "dong-ho": "watch",
    art: "palette",
    "tranh-nghe-thuat": "palette",
    jewelry: "diamond",
    "trang-suc": "diamond",
    automotive: "directions_car",
    furniture: "chair",
    ceramics: "emoji_food_beverage",
    "do-co": "museum"
};
const CATEGORY_IMAGES = {
    art: "/images/categories/art.jpg",
    "tranh-nghe-thuat": "/images/categories/art.jpg",
    "luxury-watch": "/images/categories/watch.jpg",
    "dong-ho": "/images/categories/watch.jpg",
    jewelry: "/images/categories/jewelry.jpg",
    "trang-suc": "/images/categories/jewelry.jpg",
    automotive: "/images/categories/automotive.jpg",
    furniture: "/images/categories/furniture.jpg",
    ceramics: "/images/categories/ceramics.jpg",
    "do-co": "/images/categories/antiques.jpg",
    khac: "/images/categories/collectibles.jpg"
};
function formatTimeLeft(endTime) {
    if (!endTime) return "—";
    const ms = new Date(endTime).getTime() - Date.now();
    if (ms <= 0) return "00:00:00";
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor(totalSec % 3600 / 60);
    const s = totalSec % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function toStorefrontLot(p) {
    return {
        id: String(p.auctionId),
        lotNumber: `LOT ${String(p.productId).padStart(3, "0")}`,
        title: p.productName,
        categoryId: slugify(p.categoryName ?? "khac"),
        categoryLabel: p.categoryName ?? "",
        currentBid: p.currentBid && p.currentBid > 0 ? p.currentBid : p.startingPrice,
        timeLeft: formatTimeLeft(p.auctionEndTime),
        endsAt: p.auctionEndTime ? new Date(p.auctionEndTime).getTime() : null,
        isLive: p.auctionStatus === "ACTIVE",
        auctionStatus: p.auctionStatus,
        image: toImageSrc(p.imageUrl)
    };
}
async function fetchStorefrontLots(limit = 60) {
    try {
        const res = await fetch(`${API_BASE_URL}/products?size=${limit}`, {
            cache: "no-store",
            signal: AbortSignal.timeout(15000)
        });
        if (!res.ok) return [];
        const page = await res.json();
        return (page.content ?? []).filter((p)=>p.auctionId != null).map(toStorefrontLot);
    } catch  {
        return [];
    }
}
async function fetchStorefrontCategories(lots) {
    try {
        const res = await fetch(`${API_BASE_URL}/categories`, {
            cache: "no-store",
            signal: AbortSignal.timeout(15000)
        });
        if (!res.ok) return [];
        const body = await res.json();
        const allLots = lots ?? await fetchStorefrontLots();
        return (body.data ?? []).filter((c)=>c.isActive).map((c)=>{
            const slug = slugify(c.categoryName);
            const inCategory = allLots.filter((lot)=>lot.categoryId === slug);
            return {
                id: slug,
                label: c.categoryName,
                icon: CATEGORY_ICONS[slug] ?? "category",
                count: String(inCategory.length),
                description: c.description ?? "",
                imageSrc: CATEGORY_IMAGES[slug] ?? "/images/categories/collectibles.jpg"
            };
        });
    } catch  {
        return [];
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/auth/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AuthPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fc$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fc/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$theme$2f$ThemeToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/theme/ThemeToggle.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function safeNextPath(value) {
    return value?.startsWith("/") && !value.startsWith("//") ? value : null;
}
const GOOGLE_CLIENT_ID = ("TURBOPACK compile-time value", "722496917683-ff6vgr1m0m84k8abuo0ejtssthfmviu2.apps.googleusercontent.com") ?? "";
const GOOGLE_BUTTON_LOCALE = "vi";
const GSI_SCRIPT_SRC = `https://accounts.google.com/gsi/client?hl=${GOOGLE_BUTTON_LOCALE}`;
const ROLE_HOME = {
    collector: "/dashboard",
    seller: "/inventory",
    staff: "/staff/approvals",
    admin: "/admin/dashboard",
    shipper: "/shipper/orders"
};
const TRUST_ITEMS = [
    {
        icon: "verified_user"
    },
    {
        icon: "lock"
    },
    {
        icon: "support_agent"
    }
];
function AuthPage({ searchParams }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("auth");
    const tPage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("authPage");
    const tCommon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    const heroTitle = tPage("heroTitle").split("\n");
    const resolvedSearchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["use"])(searchParams);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const redirectAfterAuth = safeNextPath(resolvedSearchParams.next);
    const [mode, setMode] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(resolvedSearchParams.mode === "signup" ? "signup" : "login");
    const [showPass, setShowPass] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showConfirmPass, setShowConfirmPass] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loginError, setLoginError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [email, setEmail] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [password, setPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [fullName, setFullName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [confirmPassword, setConfirmPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [signupSuccess, setSignupSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [googleReady, setGoogleReady] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const googleButtonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handleGoogleCredential = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "AuthPage.useCallback[handleGoogleCredential]": async (response)=>{
            if (!response.credential) {
                setLoginError(tPage("googleCredError"));
                return;
            }
            setLoginError("");
            setSubmitting(true);
            try {
                const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authApi"].googleLogin(response.credential);
                const role = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toFrontendRole"])(res.roleName);
                router.push(redirectAfterAuth ?? ROLE_HOME[role]);
            } catch (err) {
                setLoginError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"] ? err.message : tPage("serverError"));
            } finally{
                setSubmitting(false);
            }
        }
    }["AuthPage.useCallback[handleGoogleCredential]"], [
        redirectAfterAuth,
        router,
        tPage
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthPage.useEffect": ()=>{
            if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
            ;
            function renderGoogleButton() {
                const google = window.google;
                if (!google || !googleButtonRef.current) return;
                googleButtonRef.current.replaceChildren();
                const isDark = document.documentElement.dataset.theme === "dark";
                google.accounts.id.renderButton(googleButtonRef.current, {
                    type: "standard",
                    theme: isDark ? "filled_black" : "outline",
                    size: "large",
                    shape: "pill",
                    text: "continue_with",
                    logo_alignment: "left",
                    locale: GOOGLE_BUTTON_LOCALE,
                    width: Math.min(400, googleButtonRef.current.clientWidth || 400)
                });
            }
            function initGoogle() {
                const google = window.google;
                if (!google || !googleButtonRef.current) return;
                google.accounts.id.initialize({
                    client_id: GOOGLE_CLIENT_ID,
                    callback: handleGoogleCredential
                });
                renderGoogleButton();
                setGoogleReady(true);
            }
            function handleThemeChange() {
                renderGoogleButton();
            }
            window.addEventListener("bidzone:theme-change", handleThemeChange);
            let script = null;
            if (window.google) {
                initGoogle();
            } else {
                script = document.querySelector(`script[src="${GSI_SCRIPT_SRC}"]`);
                if (!script) {
                    script = document.createElement("script");
                    script.src = GSI_SCRIPT_SRC;
                    script.async = true;
                    script.defer = true;
                    document.head.appendChild(script);
                }
                script.addEventListener("load", initGoogle);
            }
            return ({
                "AuthPage.useEffect": ()=>{
                    window.removeEventListener("bidzone:theme-change", handleThemeChange);
                    script?.removeEventListener("load", initGoogle);
                }
            })["AuthPage.useEffect"];
        }
    }["AuthPage.useEffect"], [
        handleGoogleCredential
    ]);
    const isSignup = mode === "signup";
    async function resendVerificationEmail() {
        if (!email.trim()) {
            setLoginError(tPage("resendEmailRequired"));
            return;
        }
        setLoginError("");
        setSignupSuccess("");
        setSubmitting(true);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authApi"].resendEmailVerification(email.trim());
            setSignupSuccess(response.message);
        } catch (err) {
            setLoginError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"] ? err.message : tPage("resendError"));
        } finally{
            setSubmitting(false);
        }
    }
    async function handleSubmit(e) {
        e.preventDefault();
        setLoginError("");
        setSignupSuccess("");
        setSubmitting(true);
        try {
            if (isSignup) {
                if (password !== confirmPassword) {
                    setLoginError(tPage("passwordMismatch"));
                    return;
                }
                if (password.length < 8 || !/[A-Z]/.test(password) || !/[a-z]/.test(password) || !/\d/.test(password)) {
                    setLoginError(tPage("passwordWeak"));
                    return;
                }
                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authApi"].register({
                    fullName: fullName.trim(),
                    email: email.trim().toLowerCase(),
                    password,
                    confirmPassword
                });
                setSignupSuccess(response.message);
                setMode("login");
                return;
            }
            const res = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authApi"].login(email.trim().toLowerCase(), password);
            const role = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toFrontendRole"])(res.roleName);
            router.push(redirectAfterAuth ?? ROLE_HOME[role]);
        } catch (err) {
            if (err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"]) {
                setLoginError(err.status === 401 ? tPage("wrongCredentials") : err.message);
            } else {
                setLoginError(tPage("serverError"));
            }
        } finally{
            setSubmitting(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "luxora-app auth-page min-h-screen overflow-x-hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "auth-page__glow auth-page__glow--one",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/app/auth/page.tsx",
                lineNumber: 258,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "auth-page__glow auth-page__glow--two",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/app/auth/page.tsx",
                lineNumber: 259,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative z-10 mx-auto flex min-h-screen w-full max-w-[1440px] flex-col px-4 sm:px-6 lg:px-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "flex h-20 shrink-0 items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "inline-flex items-center",
                                "aria-label": "BidZone",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    priority: true,
                                    className: "h-12 w-auto"
                                }, void 0, false, {
                                    fileName: "[project]/app/auth/page.tsx",
                                    lineNumber: 268,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/auth/page.tsx",
                                lineNumber: 263,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 sm:gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: "/",
                                        className: "auth-back-link hidden h-10 items-center gap-2 rounded-full px-4 text-xs font-semibold sm:inline-flex sm:text-sm",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "material-symbols-outlined text-base",
                                                children: "arrow_back"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 276,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "hidden sm:inline",
                                                children: tPage("backHome")
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 277,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/page.tsx",
                                        lineNumber: 272,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$theme$2f$ThemeToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/app/auth/page.tsx",
                                        lineNumber: 279,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/auth/page.tsx",
                                lineNumber: 271,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/auth/page.tsx",
                        lineNumber: 262,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "auth-layout mb-6 grid overflow-hidden rounded-[28px] lg:mb-5 lg:min-h-[calc(100dvh-7rem)] lg:grid-cols-[1.08fr_0.92fr]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "theme-dark-content relative hidden min-h-0 overflow-hidden lg:flex",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/images/hero-auction-dark-v2.webp",
                                        alt: tPage("heroImageAlt"),
                                        fill: true,
                                        priority: true,
                                        sizes: "(min-width: 1024px) 56vw, 100vw",
                                        className: "object-cover object-center"
                                    }, void 0, false, {
                                        fileName: "[project]/app/auth/page.tsx",
                                        lineNumber: 285,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute inset-0 bg-gradient-to-r from-black/95 via-black/70 to-black/10"
                                    }, void 0, false, {
                                        fileName: "[project]/app/auth/page.tsx",
                                        lineNumber: 293,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/90"
                                    }, void 0, false, {
                                        fileName: "[project]/app/auth/page.tsx",
                                        lineNumber: 294,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "relative z-10 flex h-full w-full flex-col justify-between p-10 xl:p-14",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "inline-flex w-fit items-center gap-2 rounded-full border border-white/15 bg-black/20 px-4 py-2 text-[11px] font-semibold tracking-[0.24em] text-white/70 backdrop-blur",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "h-1.5 w-1.5 rounded-full bg-[#f0c982]"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 298,
                                                        columnNumber: 17
                                                    }, this),
                                                    tPage("verifiedPlatform")
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 297,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "max-w-[520px] py-12",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-xs font-semibold tracking-[0.42em] text-[#f0c982]",
                                                        children: tPage("heroBadge")
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 303,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                        className: "mt-6 text-5xl font-bold leading-[1.02] tracking-[-0.03em] text-white xl:text-6xl",
                                                        children: [
                                                            heroTitle[0],
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 308,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-[#f0c982]",
                                                                children: heroTitle[1]
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 309,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 306,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-6 max-w-[460px] text-base leading-7 text-white/68",
                                                        children: tPage("heroDesc")
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 311,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 302,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "grid grid-cols-3 gap-3 border-t border-white/15 pt-7",
                                                children: TRUST_ITEMS.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "min-w-0",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "material-symbols-outlined text-xl text-[#f0c982]",
                                                                children: item.icon
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 319,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "mt-2 block text-[10px] font-semibold tracking-wider text-white xl:text-[11px]",
                                                                children: tPage(`trust.${index}.title`)
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 322,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, item.icon, true, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 318,
                                                        columnNumber: 19
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 316,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/page.tsx",
                                        lineNumber: 296,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/auth/page.tsx",
                                lineNumber: 284,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "auth-form-pane flex min-h-[calc(100dvh-7rem)] min-w-0 flex-col justify-center px-5 py-8 sm:px-10 lg:px-12 lg:py-8 xl:px-16",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "theme-dark-content relative mb-8 min-h-40 overflow-hidden rounded-2xl p-6 lg:hidden",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                src: "/images/hero-auction-dark-v2.webp",
                                                alt: tPage("heroImageAlt"),
                                                fill: true,
                                                sizes: "100vw",
                                                className: "object-cover object-[68%_center]"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 333,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "absolute inset-0 bg-gradient-to-r from-black via-black/75 to-black/20"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 340,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "relative z-10 max-w-[260px]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "text-[10px] font-semibold tracking-[0.3em] text-[#f0c982]",
                                                        children: "BIDZONE"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 342,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-3 text-2xl font-bold leading-tight text-white",
                                                        children: [
                                                            tPage("mobileTitle.0"),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 347,
                                                                columnNumber: 19
                                                            }, this),
                                                            tPage("mobileTitle.1")
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 345,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 341,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/page.tsx",
                                        lineNumber: 332,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                                        onSubmit: handleSubmit,
                                        className: `auth-form mx-auto min-w-0 w-full max-w-[470px] ${isSignup ? "auth-form--signup" : ""}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xs font-semibold tracking-[0.26em] text-[var(--luxora-gold-dark)]",
                                                children: tPage("accountBadge")
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 358,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mt-3 flex items-end justify-between gap-4",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                            className: "text-3xl font-bold tracking-[-0.03em] text-[var(--luxora-text)] sm:text-4xl",
                                                            children: isSignup ? tPage("signupTitle") : tPage("loginTitle")
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/auth/page.tsx",
                                                            lineNumber: 363,
                                                            columnNumber: 19
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            className: "mt-2 text-sm leading-6 text-[var(--luxora-text-muted)]",
                                                            children: isSignup ? tPage("signupDesc") : tPage("loginDesc")
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/auth/page.tsx",
                                                            lineNumber: 366,
                                                            columnNumber: 19
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/auth/page.tsx",
                                                    lineNumber: 362,
                                                    columnNumber: 17
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 361,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "auth-mode-switch mt-7 grid grid-cols-2 rounded-xl p-1",
                                                children: [
                                                    "login",
                                                    "signup"
                                                ].map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        type: "button",
                                                        onClick: ()=>{
                                                            setMode(item);
                                                            setEmail("");
                                                            setPassword("");
                                                            setConfirmPassword("");
                                                            setLoginError("");
                                                        },
                                                        className: `h-11 rounded-lg text-sm font-semibold transition-all ${mode === item ? "auth-mode-switch__active" : "text-[var(--luxora-text-muted)] hover:text-[var(--luxora-text)]"}`,
                                                        children: item === "login" ? t("login") : t("register")
                                                    }, item, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 374,
                                                        columnNumber: 19
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 372,
                                                columnNumber: 15
                                            }, this),
                                            loginError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-5 rounded-xl border border-red-500/25 bg-red-500/10 px-4 py-3 text-sm text-red-600",
                                                children: loginError
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 396,
                                                columnNumber: 17
                                            }, this) : null,
                                            signupSuccess ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-5 rounded-xl border border-green-500/25 bg-green-500/10 px-4 py-3 text-sm text-green-700",
                                                children: signupSuccess
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 402,
                                                columnNumber: 17
                                            }, this) : null,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "auth-fields mt-6 space-y-4",
                                                children: [
                                                    isSignup ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                className: "auth-label",
                                                                children: t("fullName").toUpperCase()
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 410,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "auth-field",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "material-symbols-outlined text-lg text-white/45",
                                                                        children: "person"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 414,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "text",
                                                                        required: true,
                                                                        value: fullName,
                                                                        onChange: (event)=>setFullName(event.target.value),
                                                                        placeholder: tPage("placeholderFullName"),
                                                                        className: "auth-input min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/35"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 417,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 413,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 409,
                                                        columnNumber: 19
                                                    }, this) : null,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                className: "text-[11px] font-semibold tracking-wider text-white/75",
                                                                children: "EMAIL"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 430,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "auth-field",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "material-symbols-outlined text-lg text-white/45",
                                                                        children: "mail"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 434,
                                                                        columnNumber: 21
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: "email",
                                                                        required: true,
                                                                        value: email,
                                                                        onChange: (event)=>setEmail(event.target.value),
                                                                        placeholder: tPage("placeholderEmail"),
                                                                        className: "auth-input min-w-0 flex-1 bg-transparent text-sm text-white outline-none placeholder:text-white/35"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 437,
                                                                        columnNumber: 21
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 433,
                                                                columnNumber: 19
                                                            }, this),
                                                            isSignup && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                className: "mt-1.5 text-[10px] text-white/40",
                                                                children: tPage("emailActivationHint")
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 447,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 429,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "flex items-center justify-between gap-3",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                        className: "auth-label",
                                                                        children: t("password").toUpperCase()
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 455,
                                                                        columnNumber: 21
                                                                    }, this),
                                                                    !isSignup ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        type: "button",
                                                                        className: "shrink-0 text-[11px] font-medium text-[#f0c982] hover:text-[#f4d79b]",
                                                                        children: t("forgotPassword")
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 459,
                                                                        columnNumber: 23
                                                                    }, this) : null
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 454,
                                                                columnNumber: 19
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "auth-field",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "material-symbols-outlined text-lg text-white/45",
                                                                        children: "lock"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 468,
                                                                        columnNumber: 21
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: showPass ? "text" : "password",
                                                                        required: true,
                                                                        value: password,
                                                                        onChange: (event)=>setPassword(event.target.value),
                                                                        placeholder: tPage("placeholderPassword"),
                                                                        className: "auth-input min-w-0 flex-1 bg-transparent text-sm text-[var(--luxora-text)] outline-none placeholder:text-[var(--luxora-text-muted)]"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 471,
                                                                        columnNumber: 21
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        type: "button",
                                                                        onClick: ()=>setShowPass((current)=>!current),
                                                                        className: "shrink-0 text-white/45 transition-colors hover:text-white",
                                                                        "aria-label": showPass ? tPage("hidePassword") : tPage("showPassword"),
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "material-symbols-outlined text-lg",
                                                                            children: showPass ? "visibility_off" : "visibility"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/auth/page.tsx",
                                                                            lineNumber: 485,
                                                                            columnNumber: 23
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 479,
                                                                        columnNumber: 21
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 467,
                                                                columnNumber: 19
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 453,
                                                        columnNumber: 17
                                                    }, this),
                                                    isSignup ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                                className: "auth-label",
                                                                children: t("confirmPassword").toUpperCase()
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 494,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "auth-field",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "material-symbols-outlined text-lg text-white/45",
                                                                        children: "lock_reset"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 498,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                                        type: showConfirmPass ? "text" : "password",
                                                                        required: true,
                                                                        value: confirmPassword,
                                                                        onChange: (event)=>setConfirmPassword(event.target.value),
                                                                        placeholder: tPage("placeholderConfirmPassword"),
                                                                        className: "auth-input min-w-0 flex-1 bg-transparent text-sm text-[var(--luxora-text)] outline-none placeholder:text-[var(--luxora-text-muted)]"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 501,
                                                                        columnNumber: 23
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                        type: "button",
                                                                        onClick: ()=>setShowConfirmPass((current)=>!current),
                                                                        className: "shrink-0 text-white/45 transition-colors hover:text-white",
                                                                        "aria-label": showConfirmPass ? tPage("hidePassword") : tPage("showPassword"),
                                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                            className: "material-symbols-outlined text-lg",
                                                                            children: showConfirmPass ? "visibility_off" : "visibility"
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/auth/page.tsx",
                                                                            lineNumber: 521,
                                                                            columnNumber: 25
                                                                        }, this)
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/auth/page.tsx",
                                                                        lineNumber: 511,
                                                                        columnNumber: 23
                                                                    }, this)
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/auth/page.tsx",
                                                                lineNumber: 497,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 493,
                                                        columnNumber: 19
                                                    }, this) : null
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 407,
                                                columnNumber: 15
                                            }, this),
                                            isSignup ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                className: "auth-consent mt-4 flex items-start gap-3 text-xs leading-relaxed text-[var(--luxora-text-muted)]",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                        type: "checkbox",
                                                        required: true,
                                                        className: "mt-0.5 h-4 w-4 accent-[#f0c982]"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 532,
                                                        columnNumber: 19
                                                    }, this),
                                                    tPage("agreeTerms")
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 531,
                                                columnNumber: 17
                                            }, this) : null,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "submit",
                                                disabled: submitting,
                                                className: "auth-submit mt-6 h-12 w-full rounded-xl bg-[#e2b34f] text-sm font-bold tracking-wide text-[#17130b] shadow-[0_12px_30px_rgba(194,137,38,0.2)] transition-all hover:-translate-y-0.5 hover:bg-[#efc66e] disabled:cursor-not-allowed disabled:opacity-60",
                                                children: submitting ? tCommon("loading").toUpperCase() : isSignup ? t("register").toUpperCase() : t("login").toUpperCase()
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 541,
                                                columnNumber: 15
                                            }, this),
                                            !isSignup && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>void resendVerificationEmail(),
                                                disabled: submitting,
                                                className: "mt-2 w-full text-center text-[11px] font-medium text-[#f0c982] transition hover:text-[#f4d79b] disabled:opacity-50",
                                                children: tPage("resendVerification")
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 554,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "my-3 flex items-center gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "h-px flex-1 bg-white/10"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 565,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-[11px] uppercase tracking-wider text-white/35",
                                                        children: isSignup ? tPage("orRegisterWith") : tPage("orLoginWith")
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 566,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "auth-divider h-px flex-1"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 569,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 564,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                ref: googleButtonRef,
                                                className: googleReady ? "auth-google-slot flex min-w-0 justify-center overflow-hidden" : "hidden"
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 572,
                                                columnNumber: 15
                                            }, this),
                                            !googleReady ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                disabled: true,
                                                className: "auth-google-button mx-auto grid h-11 w-full max-w-[400px] cursor-wait grid-cols-[28px_1fr_28px] items-center rounded-full px-4 text-sm font-medium",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fc$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FcGoogle"], {
                                                        className: "mx-auto text-lg",
                                                        "aria-hidden": "true"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 582,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "text-center",
                                                        children: isSignup ? tPage("googleRegister") : tPage("googleLogin")
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 583,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        "aria-hidden": "true"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/auth/page.tsx",
                                                        lineNumber: 586,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 577,
                                                columnNumber: 17
                                            }, this) : null,
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "auth-security-note mt-6 text-center text-xs leading-5 text-[var(--luxora-text-muted)]",
                                                children: tPage("securityNotice")
                                            }, void 0, false, {
                                                fileName: "[project]/app/auth/page.tsx",
                                                lineNumber: 590,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/auth/page.tsx",
                                        lineNumber: 352,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/auth/page.tsx",
                                lineNumber: 331,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/auth/page.tsx",
                        lineNumber: 283,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/auth/page.tsx",
                lineNumber: 261,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/auth/page.tsx",
        lineNumber: 257,
        columnNumber: 5
    }, this);
}
_s(AuthPage, "ty16xr5qYe8avDWk9dbaXb2v22k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = AuthPage;
var _c;
__turbopack_context__.k.register(_c, "AuthPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_1densh7._.js.map