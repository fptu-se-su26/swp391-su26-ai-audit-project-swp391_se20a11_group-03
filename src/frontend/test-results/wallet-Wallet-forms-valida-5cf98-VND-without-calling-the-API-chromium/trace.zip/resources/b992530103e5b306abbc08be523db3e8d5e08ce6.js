(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BidZoneLogo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
function BidZoneLogo({ className = "h-10 w-auto", priority = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `inline-flex items-center gap-2.5 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "relative aspect-square h-full shrink-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: "/bidzone-logo.png",
                    alt: "",
                    fill: true,
                    sizes: "64px",
                    priority: priority,
                    className: "object-contain"
                }, void 0, false, {
                    fileName: "[project]/components/brand/BidZoneLogo.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/brand/BidZoneLogo.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[1.35rem] font-black leading-none tracking-[-0.055em]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-white",
                        children: "Bid"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/BidZoneLogo.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[#d5b15d]",
                        children: "Zone"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/BidZoneLogo.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/brand/BidZoneLogo.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/brand/BidZoneLogo.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = BidZoneLogo;
var _c;
__turbopack_context__.k.register(_c, "BidZoneLogo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/i18n/LanguageSwitcher.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LanguageSwitcher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
/**
 * Persist the locale in NEXT_LOCALE and refresh without changing URL structure.
 */ function setLocaleCookie(locale) {
    document.cookie = `NEXT_LOCALE=${locale}; path=/; max-age=31536000; SameSite=Lax`;
}
function LanguageSwitcher({ compactOnMobile = false }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("language");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isPending, startTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])();
    function handleSwitch() {
        // Read the active locale from the cookie.
        const current = document.cookie.split("; ").find((row)=>row.startsWith("NEXT_LOCALE="))?.split("=")[1] ?? "vi";
        const next = current === "vi" ? "en" : "vi";
        setLocaleCookie(next);
        startTransition(()=>{
            router.refresh();
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        onClick: handleSwitch,
        disabled: isPending,
        "aria-label": t("switchTo"),
        className: `language-switcher${compactOnMobile ? " language-switcher--compact" : ""}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiGlobe"], {
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: compactOnMobile ? "hidden sm:inline" : undefined,
                children: t("current")
            }, void 0, false, {
                fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
_s(LanguageSwitcher, "IQNdCJE7xrs4v6E4HoZyj8QB7U4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"]
    ];
});
_c = LanguageSwitcher;
var _c;
__turbopack_context__.k.register(_c, "LanguageSwitcher");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_BASE_URL",
    ()=>API_BASE_URL,
    "AUTH_STATE_EVENT",
    ()=>AUTH_STATE_EVENT,
    "ApiError",
    ()=>ApiError,
    "adminApi",
    ()=>adminApi,
    "aiApi",
    ()=>aiApi,
    "auctionApi",
    ()=>auctionApi,
    "authApi",
    ()=>authApi,
    "autoBidApi",
    ()=>autoBidApi,
    "chatbotApi",
    ()=>chatbotApi,
    "fetchAccountSummary",
    ()=>fetchAccountSummary,
    "fetchLiveAuctions",
    ()=>fetchLiveAuctions,
    "fetchPublicStats",
    ()=>fetchPublicStats,
    "fetchStorefrontCategories",
    ()=>fetchStorefrontCategories,
    "fetchStorefrontLots",
    ()=>fetchStorefrontLots,
    "getOrCreateDeviceId",
    ()=>getOrCreateDeviceId,
    "getToken",
    ()=>getToken,
    "kycApi",
    ()=>kycApi,
    "orderApi",
    ()=>orderApi,
    "premiumApi",
    ()=>premiumApi,
    "productApi",
    ()=>productApi,
    "sellerApi",
    ()=>sellerApi,
    "sellerContractApi",
    ()=>sellerContractApi,
    "setToken",
    ()=>setToken,
    "toFrontendRole",
    ()=>toFrontendRole,
    "toImageSrc",
    ()=>toImageSrc,
    "updateRoleCookie",
    ()=>updateRoleCookie,
    "uploadImages",
    ()=>uploadImages,
    "userApi",
    ()=>userApi,
    "walletApi",
    ()=>walletApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const LOCAL_API_BASE_URL = "http://localhost:8096/api";
const PRODUCTION_API_BASE_URL = "https://api.bidzone.io.vn/api";
const configuredApiBaseUrl = ("TURBOPACK compile-time value", "http://localhost:8096/api")?.trim();
const configuredForLocalhost = configuredApiBaseUrl?.startsWith("http://localhost") || configuredApiBaseUrl?.startsWith("http://127.0.0.1");
const API_BASE_URL = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : configuredApiBaseUrl || LOCAL_API_BASE_URL;
const orderApi = {
    mine: ()=>apiFetch("/orders"),
    one: (id)=>apiFetch(`/orders/${id}`),
    confirmReceived: (id)=>apiFetch(`/orders/${id}/confirm-received`, {
            method: "POST"
        }),
    shippingFee: ()=>apiFetch("/orders/shipping-fee"),
    staffOrders: (status)=>apiFetch(`/staff/orders${status ? `?status=${encodeURIComponent(status)}` : ""}`),
    shippers: ()=>apiFetch("/staff/shippers"),
    assign: (id, shipperId, note)=>apiFetch(`/staff/orders/${id}/assign`, {
            method: "POST",
            body: JSON.stringify({
                shipperId,
                note
            })
        }),
    failedAction: (id, action, shipperId, note)=>apiFetch(`/staff/orders/${id}/failed-action`, {
            method: "POST",
            body: JSON.stringify({
                action,
                shipperId,
                note
            })
        }),
    shipperMine: ()=>apiFetch("/shipper/orders"),
    shipperStatus: (id, status, note)=>apiFetch(`/shipper/orders/${id}/status`, {
            method: "POST",
            body: JSON.stringify({
                status,
                note
            })
        })
};
// ---------------------------------------------------------------------------
// Core fetch helper — tự gắn JWT (lưu ở localStorage sau khi login)
// ---------------------------------------------------------------------------
const TOKEN_KEY = "bidzone_token";
const DEVICE_ID_KEY = "bidzone_device_id";
const AUTH_ROLE_COOKIE = "bidzone_role";
const AUTH_STATE_EVENT = "bidzone-auth-change";
function getToken() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return window.localStorage.getItem(TOKEN_KEY);
}
// ---------------------------------------------------------------------------
// Request de-duplication — several independent components (Header, sidebar,
// dashboard page) fetch the same "current user" data (profile, wallet) on
// every mount with no shared cache, so a single page load fires the same
// request 2-3x. This coalesces same-key calls made within a short window
// into a single in-flight request/result, without changing any call site's
// signature or return type.
// ---------------------------------------------------------------------------
const DEDUP_TTL_MS = 3000;
const clearDedupCaches = [];
function dedupedWithTtl(ttlMs) {
    let cache = null;
    const clear = ()=>{
        cache = null;
    };
    clearDedupCaches.push(clear);
    const run = (loader)=>{
        const now = Date.now();
        if (cache && now - cache.timestamp < ttlMs) {
            return cache.promise;
        }
        const promise = loader();
        cache = {
            promise,
            timestamp: now
        };
        promise.catch(clear);
        return promise;
    };
    return {
        run,
        clear
    };
}
function setToken(token) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    if (token) window.localStorage.setItem(TOKEN_KEY, token);
    else window.localStorage.removeItem(TOKEN_KEY);
    clearDedupCaches.forEach((clear)=>clear());
    window.dispatchEvent(new Event(AUTH_STATE_EVENT));
}
/**
 * Central 401 handling: previously only 2 of ~30+ call sites reacted to a 401 by logging
 * out, so an expired/invalid token surfaced everywhere else as a generic, unexplained error
 * instead of the app recognizing the session had ended. Called from every fetch helper below
 * whenever a request that DID send the stored token comes back 401 — clearing the session so
 * `isLoggedIn` (Header, route guards) reacts immediately, without forcing a redirect from
 * inside a data-fetching utility.
 *
 * Only fires when `sentToken` is truthy: a 401 on a request made without a token (e.g. login
 * with a wrong password, sent with `auth: false`) is a normal business-logic failure, not a
 * session expiry, and must not clear an unrelated already-logged-in session.
 */ function handleUnauthorizedResponse(status, sentToken) {
    if (status === 401 && sentToken) {
        setAuthRoleCookie(null);
        setToken(null);
    }
}
function getOrCreateDeviceId() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let deviceId = window.localStorage.getItem(DEVICE_ID_KEY);
    if (!deviceId) {
        deviceId = window.crypto.randomUUID();
        window.localStorage.setItem(DEVICE_ID_KEY, deviceId);
    }
    return deviceId;
}
function setAuthRoleCookie(role) {
    if (typeof document === "undefined") return;
    const secure = window.location.protocol === "https:" ? "; Secure" : "";
    document.cookie = role ? `${AUTH_ROLE_COOKIE}=${role}; path=/; max-age=604800; SameSite=Lax${secure}` : `${AUTH_ROLE_COOKIE}=; path=/; max-age=0; SameSite=Lax${secure}`;
}
function storeLoginResponse(response) {
    if (!response.token) return;
    setAuthRoleCookie(toFrontendRole(response.roleName));
    setToken(response.token);
}
class ApiError extends Error {
    status;
    constructor(status, message){
        super(message), this.status = status;
    }
}
async function apiFetch(path, options = {}) {
    const { auth = true, headers, ...rest } = options;
    const token = auth ? getToken() : null;
    const deviceId = auth ? getOrCreateDeviceId() : null;
    const res = await fetch(`${API_BASE_URL}${path}`, {
        ...rest,
        headers: {
            ...rest.body && !(rest.body instanceof FormData) ? {
                "Content-Type": "application/json"
            } : {},
            ...token ? {
                Authorization: `Bearer ${token}`
            } : {},
            ...deviceId ? {
                "X-Device-Id": deviceId
            } : {},
            ...headers
        }
    });
    if (!res.ok) {
        let message = `HTTP ${res.status}`;
        try {
            const body = await res.json();
            message = body.message ?? body.detail ?? body.error ?? message;
        } catch  {
        /* body không phải JSON */ }
        handleUnauthorizedResponse(res.status, token);
        throw new ApiError(res.status, message);
    }
    if (res.status === 204) return undefined;
    return await res.json();
}
/**
 * POST multipart/form-data (file uploads). Unlike {@link apiFetch} we must NOT
 * set Content-Type — the browser adds the multipart boundary itself.
 */ async function postMultipart(path, form) {
    const token = getToken();
    const res = await fetch(`${API_BASE_URL}${path}`, {
        method: "POST",
        headers: token ? {
            Authorization: `Bearer ${token}`
        } : {},
        body: form
    });
    if (!res.ok) {
        let message = `HTTP ${res.status}`;
        try {
            const body = await res.json();
            message = body.message ?? body.detail ?? body.error ?? message;
        } catch  {
        /* body không phải JSON */ }
        handleUnauthorizedResponse(res.status, token);
        throw new ApiError(res.status, message);
    }
    if (res.status === 204) return undefined;
    return await res.json();
}
async function uploadImages(files) {
    const form = new FormData();
    for (const file of files)form.append("files", file);
    const body = await postMultipart("/uploads", form);
    return body.data ?? [];
}
function toFrontendRole(roleName) {
    switch((roleName ?? "").toLowerCase()){
        case "admin":
            return "admin";
        case "staff":
            return "staff";
        case "seller":
            return "seller";
        case "shipper":
            return "shipper";
        default:
            return "collector";
    }
}
const authApi = {
    async login (usernameOrEmail, password) {
        const res = await apiFetch("/auth/login", {
            method: "POST",
            body: JSON.stringify({
                usernameOrEmail,
                password
            }),
            auth: false
        });
        storeLoginResponse(res);
        return res;
    },
    register (data) {
        return apiFetch("/auth/register", {
            method: "POST",
            body: JSON.stringify(data),
            auth: false
        });
    },
    sendRegistrationEmailCode (email) {
        return apiFetch("/auth/register/email/send-code", {
            method: "POST",
            body: JSON.stringify({
                email
            }),
            auth: false
        });
    },
    verifyRegistrationEmailCode (email, code) {
        return apiFetch("/auth/register/email/verify-code", {
            method: "POST",
            body: JSON.stringify({
                email,
                code
            }),
            auth: false
        });
    },
    verifyEmail (token) {
        return apiFetch(`/auth/verify-email?token=${encodeURIComponent(token)}`, {
            auth: false
        });
    },
    resendEmailVerification (email) {
        return apiFetch("/auth/email-verification/resend", {
            method: "POST",
            body: JSON.stringify({
                email
            }),
            auth: false
        });
    },
    async googleLogin (credential) {
        const res = await apiFetch("/auth/google", {
            method: "POST",
            body: JSON.stringify({
                credential
            }),
            auth: false
        });
        storeLoginResponse(res);
        return res;
    },
    logout () {
        setAuthRoleCookie(null);
        setToken(null);
    }
};
const productApi = {
    search (params) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(params)){
            if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
        }
        return apiFetch(`/products?${q}`, {
            auth: false
        });
    },
    detail (productId) {
        return apiFetch(`/products/${productId}`, {
            auth: false
        });
    },
    categories () {
        return apiFetch("/categories", {
            auth: false
        });
    },
    categoryAttributes (categoryId) {
        return apiFetch(`/categories/${categoryId}/attributes`, {
            auth: false
        });
    },
    featured () {
        return apiFetch("/featured-products", {
            auth: false
        });
    },
    mine () {
        return apiFetch("/seller/products/mine");
    },
    sellerDetail (productId) {
        return apiFetch(`/seller/products/${productId}`);
    },
    create (payload) {
        return apiFetch("/seller/products", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    update (productId, payload) {
        return apiFetch(`/seller/products/${productId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
        });
    }
};
const aiApi = {
    valuation (payload) {
        return apiFetch("/ai/valuation", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    valuationQuota () {
        return apiFetch("/ai/valuation/quota");
    }
};
const kycApi = {
    ocr (frontImage, backImage) {
        const form = new FormData();
        form.append("frontImage", frontImage);
        form.append("backImage", backImage);
        return postMultipart("/kyc/ocr", form);
    },
    submit (payload) {
        const form = new FormData();
        form.append("fullName", payload.fullName);
        form.append("cccdNumber", payload.cccdNumber);
        form.append("dob", payload.dob);
        form.append("gender", payload.gender);
        form.append("issueDate", payload.issueDate);
        form.append("issuePlace", payload.issuePlace);
        form.append("frontImage", payload.frontImage);
        form.append("backImage", payload.backImage);
        form.append("selfieImage", payload.selfieImage);
        form.append("signSellerAgreement", String(payload.signSellerAgreement ?? false));
        return postMultipart("/kyc", form);
    },
    mine () {
        return apiFetch("/kyc/me");
    },
    /** Fetch a private KYC image (owner or staff only) as a blob for rendering. */ async imageBlob (kycId, which) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/kyc/${kycId}/image/${which}`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    }
};
const sellerContractApi = {
    /** Fetch the seller agreement preview PDF as a blob (needs JWT header). */ async previewPdf () {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/seller-contract/preview-pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    /** Fetch the persisted signed agreement PDF. */ async signedPdf () {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/seller-contract/me/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    /**
   * Sign the seller agreement and upgrade User -> Seller immediately.
   * Requires an APPROVED KYC (identityVerified) — enforced server-side.
   */ submit () {
        return apiFetch("/seller-contract/submit", {
            method: "POST"
        });
    },
    mine () {
        return apiFetch("/seller-contract/me");
    }
};
function updateRoleCookie(roleName) {
    setAuthRoleCookie(toFrontendRole(roleName));
    if ("TURBOPACK compile-time truthy", 1) {
        window.dispatchEvent(new Event(AUTH_STATE_EVENT));
    }
}
const premiumApi = {
    status () {
        return apiFetch("/premium/status");
    },
    purchase (plan) {
        return apiFetch("/premium/purchase", {
            method: "POST",
            body: JSON.stringify({
                plan
            })
        });
    }
};
const autoBidApi = {
    set (auctionId, maxBidAmount) {
        return apiFetch(`/bidding/auto/${auctionId}`, {
            method: "POST",
            body: JSON.stringify({
                maxBidAmount
            })
        });
    },
    cancel (auctionId) {
        return apiFetch(`/bidding/auto/${auctionId}`, {
            method: "DELETE"
        });
    },
    get (auctionId) {
        return apiFetch(`/bidding/auto/${auctionId}`);
    }
};
const auctionApi = {
    state (auctionId) {
        return apiFetch(`/auctions/${auctionId}/state`, {
            auth: false
        });
    },
    bids (auctionId) {
        return apiFetch(`/auctions/${auctionId}/bids`, {
            auth: false
        });
    },
    eligibility (auctionId) {
        return apiFetch(`/auctions/${auctionId}/eligibility`);
    },
    /** Bid cao nhất của CHÍNH người gọi — luôn xem được, kể cả phiên giá kín. */ myBid (auctionId) {
        return apiFetch(`/auctions/${auctionId}/my-bid`);
    },
    placeBid (auctionId, bidAmount) {
        return apiFetch(`/auctions/${auctionId}/bid`, {
            method: "POST",
            body: JSON.stringify({
                bidAmount
            })
        });
    },
    pay (auctionId, address) {
        return apiFetch(`/auctions/${auctionId}/pay`, {
            method: "POST",
            body: JSON.stringify(address)
        });
    },
    purchaseContract (auctionId) {
        return apiFetch(`/auctions/${auctionId}/purchase-contract`);
    },
    signPurchaseContract (auctionId) {
        return apiFetch(`/auctions/${auctionId}/purchase-contract/sign`, {
            method: "POST"
        });
    },
    async purchaseContractPdf (auctionId) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/auctions/${auctionId}/purchase-contract/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    deposit (auctionId) {
        return apiFetch(`/deposits?auctionId=${auctionId}`, {
            method: "POST"
        });
    },
    rooms () {
        return apiFetch("/bidding/rooms");
    },
    chatMessages (auctionId) {
        return apiFetch(`/auctions/${auctionId}/chat/messages`, {
            auth: false
        });
    },
    myBids () {
        return apiFetch("/bids/my-bids");
    },
    wonAuctions () {
        return apiFetch("/bids/won");
    }
};
// ---------------------------------------------------------------------------
// WALLET — /api/wallet*
// ---------------------------------------------------------------------------
const walletGetCache = dedupedWithTtl(DEDUP_TTL_MS);
const walletApi = {
    get () {
        return walletGetCache.run(()=>apiFetch("/wallet"));
    },
    transactions () {
        return apiFetch("/wallet/transactions");
    },
    deposit (amount) {
        return apiFetch("/wallet/deposit", {
            method: "POST",
            body: JSON.stringify({
                amount
            })
        });
    },
    withdraw (data) {
        return apiFetch("/wallet/withdraw", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    withdrawals () {
        return apiFetch("/wallet/withdrawals");
    }
};
const userProfileCache = dedupedWithTtl(DEDUP_TTL_MS);
// CollectorSidebar (unread badge) and the /messages page both call this independently, and
// on the backend it's a genuinely slow query (batched, but still ~1s+ against the remote DB) —
// firing it 2-3x concurrently on one page load compounds into visible connection contention.
const myConversationsCache = dedupedWithTtl(DEDUP_TTL_MS);
const userApi = {
    profile () {
        return userProfileCache.run(()=>apiFetch("/users/me/profile"));
    },
    async updateProfile (fullName) {
        const result = await apiFetch("/users/me/profile", {
            method: "PUT",
            body: JSON.stringify({
                fullName
            })
        });
        userProfileCache.clear();
        return result;
    },
    changePassword (data) {
        return apiFetch("/users/me/change-password", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    notifications () {
        return apiFetch("/notifications");
    },
    unreadCount () {
        return apiFetch("/notifications/unread-count");
    },
    markNotificationRead (id) {
        return apiFetch(`/notifications/${id}/read`, {
            method: "POST"
        });
    },
    watchlist () {
        return apiFetch("/watchlist");
    },
    addToWatchlist (productId) {
        return apiFetch(`/watchlist/${productId}`, {
            method: "POST"
        });
    },
    removeFromWatchlist (productId) {
        return apiFetch(`/watchlist/${productId}`, {
            method: "DELETE"
        });
    },
    myKyc () {
        return apiFetch("/kyc/me");
    },
    submitKyc (formData) {
        return apiFetch("/kyc", {
            method: "POST",
            body: formData
        });
    },
    myConversations () {
        return myConversationsCache.run(()=>apiFetch("/v1/conversations/my"));
    },
    createConversation (data) {
        return apiFetch("/v1/conversations", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    conversationMessages (conversationId) {
        return apiFetch(`/v1/messages/conversation/${conversationId}`);
    },
    async markConversationRead (conversationId) {
        const result = await apiFetch(`/v1/messages/conversation/${conversationId}/read`, {
            method: "PATCH"
        });
        myConversationsCache.clear();
        return result;
    },
    async sendMessage (conversationId, content) {
        const result = await apiFetch("/v1/messages", {
            method: "POST",
            body: JSON.stringify({
                conversationId,
                content
            })
        });
        myConversationsCache.clear();
        return result;
    },
    // --- Staff support inbox ---
    assignedConversations () {
        return apiFetch("/v1/conversations/assigned");
    },
    unassignedConversations () {
        return apiFetch("/v1/conversations/unassigned");
    },
    assignConversation (conversationId) {
        return apiFetch(`/v1/conversations/${conversationId}/assign`, {
            method: "PATCH"
        });
    },
    closeConversation (conversationId) {
        return apiFetch(`/v1/conversations/${conversationId}/close`, {
            method: "PATCH"
        });
    }
};
async function fetchAccountSummary() {
    const [profile, wallet] = await Promise.all([
        userApi.profile(),
        walletApi.get()
    ]);
    return {
        profile: profile.data,
        wallet
    };
}
async function fetchPublicStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/public/stats`, {
            cache: "no-store",
            signal: AbortSignal.timeout(5000)
        });
        if (!response.ok) return [];
        const stats = await response.json();
        return [
            {
                id: "products",
                value: stats.totalProducts.toLocaleString("vi-VN")
            },
            {
                id: "members",
                value: stats.totalUsers.toLocaleString("vi-VN")
            },
            {
                id: "active-auctions",
                value: stats.activeAuctions.toLocaleString("vi-VN")
            },
            {
                id: "completed-auctions",
                value: stats.completedAuctions.toLocaleString("vi-VN")
            }
        ];
    } catch  {
        return [];
    }
}
const adminApi = {
    summary () {
        return apiFetch("/admin/dashboard/summary");
    },
    revenue () {
        return apiFetch("/admin/dashboard/revenue");
    },
    salesHistory () {
        return apiFetch("/admin/dashboard/sales-history");
    },
    auctionSessions (payment = "ALL") {
        return apiFetch(`/admin/dashboard/auction-sessions?payment=${payment}`);
    },
    categories () {
        return apiFetch("/admin/categories");
    },
    createCategory (categoryName, description) {
        return apiFetch("/admin/categories", {
            method: "POST",
            body: JSON.stringify({
                categoryName,
                description,
                isActive: true
            })
        });
    },
    deleteCategory (categoryId) {
        return apiFetch(`/admin/categories/${categoryId}`, {
            method: "DELETE"
        });
    },
    events () {
        return apiFetch("/admin/events");
    },
    createEvent (payload) {
        return apiFetch("/admin/events", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    updateEvent (eventId, payload) {
        return apiFetch(`/admin/events/${eventId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
        });
    },
    deleteEvent (eventId) {
        return apiFetch(`/admin/events/${eventId}`, {
            method: "DELETE"
        });
    },
    eventProducts (eventId) {
        return apiFetch(`/admin/events/${eventId}/products`);
    },
    assignExistingProductToEvent (eventId, productId) {
        return apiFetch(`/admin/events/${eventId}/products/existing/${productId}`, {
            method: "POST"
        });
    },
    approveEventProduct (eventProductId) {
        return apiFetch(`/admin/events/products/${eventProductId}/approve`, {
            method: "POST"
        });
    },
    rejectEventProduct (eventProductId, reason) {
        return apiFetch(`/admin/events/products/${eventProductId}/reject`, {
            method: "POST",
            body: JSON.stringify({
                reason
            })
        });
    },
    removeEventProduct (eventProductId) {
        return apiFetch(`/admin/events/products/${eventProductId}`, {
            method: "DELETE"
        });
    },
    availableProducts () {
        return apiFetch("/admin/events/available-products");
    },
    pendingProducts () {
        return apiFetch("/admin/products/pending");
    },
    approveProduct (productId, payload) {
        return apiFetch(`/admin/products/${productId}/approve`, {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    rejectProduct (productId, reason = "") {
        return apiFetch(`/admin/products/${productId}/reject`, {
            method: "POST",
            body: JSON.stringify({
                reason
            })
        });
    },
    // KYC review — backend returns a raw List (not an ApiEnvelope) for /kyc/list.
    kycList (status = "PENDING") {
        return apiFetch(`/kyc/list?status=${encodeURIComponent(status)}`);
    },
    approveKyc (kycId) {
        return apiFetch(`/kyc/${kycId}/approve`, {
            method: "POST"
        });
    },
    // reason is a @RequestParam on the backend, so it goes in the query string.
    rejectKyc (kycId, reason) {
        return apiFetch(`/kyc/${kycId}/reject?reason=${encodeURIComponent(reason)}`, {
            method: "POST"
        });
    },
    requestInfoKyc (kycId, reason) {
        return apiFetch(`/kyc/${kycId}/request-info?reason=${encodeURIComponent(reason)}`, {
            method: "POST"
        });
    },
    // --- Users & roles (Admin only) ---
    users (q = "") {
        const qs = q ? `?q=${encodeURIComponent(q)}` : "";
        return apiFetch(`/admin/users${qs}`);
    },
    userStats () {
        return apiFetch("/admin/users/stats");
    },
    updateUserRole (userId, roleName) {
        return apiFetch(`/admin/users/${userId}/role`, {
            method: "PATCH",
            body: JSON.stringify({
                roleName
            })
        });
    },
    updateUserStatus (userId, active) {
        return apiFetch(`/admin/users/${userId}/status`, {
            method: "PATCH",
            body: JSON.stringify({
                active
            })
        });
    },
    // --- Withdrawals (Staff/Admin) — backend returns raw lists, no envelope ---
    withdrawals (status = "") {
        const qs = status ? `?status=${encodeURIComponent(status)}` : "";
        return apiFetch(`/staff/withdrawals${qs}`);
    },
    updateWithdrawal (id, status, staffNote = "") {
        return apiFetch(`/staff/withdrawals/${id}/status`, {
            method: "PUT",
            body: JSON.stringify({
                status,
                staffNote
            })
        });
    },
    // --- Contracts & ledger (Admin/Staff dashboard) ---
    contracts (cccd = "") {
        const qs = cccd ? `?cccd=${encodeURIComponent(cccd)}` : "";
        return apiFetch(`/admin/dashboard/contracts${qs}`);
    },
    async contractPdfBlob (contractId) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/admin/dashboard/contracts/${contractId}/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    balanceLedger (params = {}) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(params)){
            if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
        }
        const qs = q.toString() ? `?${q}` : "";
        return apiFetch(`/admin/dashboard/balance-ledger${qs}`);
    },
    fraudSettings () {
        return apiFetch("/admin/settings/fraud-detection");
    },
    updateFraudSettings (payload) {
        return apiFetch("/admin/settings/fraud-detection", {
            method: "PATCH",
            body: JSON.stringify(payload)
        });
    },
    fraudAlerts (params = {}) {
        const q = new URLSearchParams();
        for (const [key, value] of Object.entries(params)){
            if (value !== undefined && value !== null && value !== "") q.set(key, String(value));
        }
        const qs = q.toString() ? `?${q}` : "";
        return apiFetch(`/admin/fraud-alerts${qs}`);
    },
    reviewFraudAlert (id, note = "") {
        return fraudAlertAction(id, "review", note);
    },
    confirmFraudAlert (id, note = "") {
        return fraudAlertAction(id, "confirm", note);
    },
    dismissFraudAlert (id, note = "") {
        return fraudAlertAction(id, "dismiss", note);
    },
    restoreFraudUser (id, note = "") {
        return fraudAlertAction(id, "restore-user", note);
    }
};
const sellerApi = {
    openEvents () {
        return apiFetch("/seller/events");
    },
    submitExistingProductToEvent (eventId, productId) {
        return apiFetch(`/seller/events/${eventId}/products/existing`, {
            method: "POST",
            body: JSON.stringify({
                productId
            })
        });
    },
    mySubmissions (eventId) {
        return apiFetch(`/seller/events/${eventId}/my-submissions`);
    },
    withdrawSubmission (eventProductId) {
        return apiFetch(`/seller/events/products/${eventProductId}`, {
            method: "DELETE"
        });
    }
};
function fraudAlertAction(id, action, note) {
    return apiFetch(`/admin/fraud-alerts/${id}/${action}`, {
        method: "POST",
        body: JSON.stringify({
            note
        })
    });
}
const chatbotApi = {
    reply (message) {
        return apiFetch("/public/chatbot", {
            method: "POST",
            body: JSON.stringify({
                message
            }),
            auth: false
        });
    }
};
// ---------------------------------------------------------------------------
// HOME — dữ liệu trang chủ (server component dùng được, không cần token)
// ---------------------------------------------------------------------------
const VND = new Intl.NumberFormat("vi-VN");
function toImageSrc(imageUrl) {
    if (!imageUrl) return "/images/auction-products/placeholder.png";
    if (imageUrl.startsWith("http")) return imageUrl;
    // Backend trả đường dẫn tương đối (/uploads/...) — đi qua rewrite trong next.config.ts
    return imageUrl.startsWith("/") ? imageUrl : `/${imageUrl}`;
}
function toLiveAuctionItem(p) {
    const price = p.currentBid && p.currentBid > 0 ? p.currentBid : p.startingPrice;
    return {
        id: String(p.auctionId ?? p.productId),
        status: p.auctionStatus?.toUpperCase() === "UPCOMING" ? "UPCOMING" : "ACTIVE",
        title: p.productName,
        subtitle: p.categoryName ?? "",
        currentPrice: `${VND.format(price)} ₫`,
        estimatedPrice: `${VND.format(p.startingPrice)} ₫`,
        bidCount: p.totalBids ?? 0,
        startsAt: p.auctionStartTime ? new Date(p.auctionStartTime).getTime() : Date.now(),
        endsAt: p.auctionEndTime ? new Date(p.auctionEndTime).getTime() : Date.now(),
        imageSrc: toImageSrc(p.imageUrl)
    };
}
async function fetchLiveAuctions(limit = 5) {
    try {
        const loadByStatus = async (auctionStatus)=>{
            const res = await fetch(`${API_BASE_URL}/products?auctionStatus=${auctionStatus}&size=${limit}`, {
                cache: "no-store",
                signal: AbortSignal.timeout(15000)
            });
            if (!res.ok) return [];
            const page = await res.json();
            return page.content ?? [];
        };
        const [active, upcoming] = await Promise.all([
            loadByStatus("ACTIVE"),
            loadByStatus("UPCOMING")
        ]);
        const uniqueAuctions = new Map();
        for (const product of [
            ...active,
            ...upcoming
        ]){
            if (product.auctionId != null && !uniqueAuctions.has(product.auctionId)) {
                uniqueAuctions.set(product.auctionId, product);
            }
        }
        return [
            ...uniqueAuctions.values()
        ].slice(0, limit).map(toLiveAuctionItem);
    } catch  {
        return [];
    }
}
function slugify(name) {
    return name.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
const CATEGORY_ICONS = {
    "luxury-watch": "watch",
    "dong-ho": "watch",
    art: "palette",
    "tranh-nghe-thuat": "palette",
    jewelry: "diamond",
    "trang-suc": "diamond",
    automotive: "directions_car",
    furniture: "chair",
    ceramics: "emoji_food_beverage",
    "do-co": "museum"
};
const CATEGORY_IMAGES = {
    art: "/images/categories/art.jpg",
    "tranh-nghe-thuat": "/images/categories/art.jpg",
    "luxury-watch": "/images/categories/watch.jpg",
    "dong-ho": "/images/categories/watch.jpg",
    jewelry: "/images/categories/jewelry.jpg",
    "trang-suc": "/images/categories/jewelry.jpg",
    automotive: "/images/categories/automotive.jpg",
    furniture: "/images/categories/furniture.jpg",
    ceramics: "/images/categories/ceramics.jpg",
    "do-co": "/images/categories/antiques.jpg",
    khac: "/images/categories/collectibles.jpg"
};
function formatTimeLeft(endTime) {
    if (!endTime) return "—";
    const ms = new Date(endTime).getTime() - Date.now();
    if (ms <= 0) return "00:00:00";
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor(totalSec % 3600 / 60);
    const s = totalSec % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function toStorefrontLot(p) {
    return {
        id: String(p.auctionId),
        lotNumber: `LOT ${String(p.productId).padStart(3, "0")}`,
        title: p.productName,
        categoryId: slugify(p.categoryName ?? "khac"),
        categoryLabel: p.categoryName ?? "",
        currentBid: p.currentBid && p.currentBid > 0 ? p.currentBid : p.startingPrice,
        timeLeft: formatTimeLeft(p.auctionEndTime),
        endsAt: p.auctionEndTime ? new Date(p.auctionEndTime).getTime() : null,
        isLive: p.auctionStatus === "ACTIVE",
        auctionStatus: p.auctionStatus,
        image: toImageSrc(p.imageUrl)
    };
}
async function fetchStorefrontLots(limit = 60) {
    try {
        const res = await fetch(`${API_BASE_URL}/products?size=${limit}`, {
            cache: "no-store",
            signal: AbortSignal.timeout(15000)
        });
        if (!res.ok) return [];
        const page = await res.json();
        return (page.content ?? []).filter((p)=>p.auctionId != null).map(toStorefrontLot);
    } catch  {
        return [];
    }
}
async function fetchStorefrontCategories(lots) {
    try {
        const res = await fetch(`${API_BASE_URL}/categories`, {
            cache: "no-store",
            signal: AbortSignal.timeout(15000)
        });
        if (!res.ok) return [];
        const body = await res.json();
        const allLots = lots ?? await fetchStorefrontLots();
        return (body.data ?? []).filter((c)=>c.isActive).map((c)=>{
            const slug = slugify(c.categoryName);
            const inCategory = allLots.filter((lot)=>lot.categoryId === slug);
            return {
                id: slug,
                label: c.categoryName,
                icon: CATEGORY_ICONS[slug] ?? "category",
                count: String(inCategory.length),
                description: c.description ?? "",
                imageSrc: CATEGORY_IMAGES[slug] ?? "/images/categories/collectibles.jpg"
            };
        });
    } catch  {
        return [];
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/use-api-data.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useApiData",
    ()=>useApiData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function useApiData(load, initialValue) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialValue);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const reload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useApiData.useCallback[reload]": async ()=>{
            setLoading(true);
            setError(null);
            try {
                setData(await load());
            } catch (cause) {
                setError(cause instanceof Error ? cause.message : t("error"));
            } finally{
                setLoading(false);
            }
        }
    }["useApiData.useCallback[reload]"], [
        load,
        t
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useApiData.useEffect": ()=>{
            const timeout = window.setTimeout({
                "useApiData.useEffect.timeout": ()=>void reload()
            }["useApiData.useEffect.timeout"], 0);
            return ({
                "useApiData.useEffect": ()=>window.clearTimeout(timeout)
            })["useApiData.useEffect"];
        }
    }["useApiData.useEffect"], [
        reload
    ]);
    return {
        data,
        setData,
        loading,
        error,
        reload
    };
}
_s(useApiData, "9T5RUiTPUiRS728/pjx8MD8vS08=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/shells/CollectorSidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "UNREAD_REFRESH_EVENT",
    ()=>UNREAD_REFRESH_EVENT,
    "default",
    ()=>CollectorSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$i18n$2f$LanguageSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/i18n/LanguageSwitcher.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/use-api-data.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
const STORAGE_KEY = "bidzone-sidebar-collapsed";
const UNREAD_REFRESH_EVENT = "bidzone:unread-refresh";
const NAV_GROUPS = [
    {
        titleKey: "auction",
        items: [
            {
                labelKey: "dashboard",
                href: "/dashboard",
                icon: "dashboard"
            },
            {
                labelKey: "watchlist",
                href: "/watchlist",
                icon: "visibility"
            },
            {
                labelKey: "wonItems",
                href: "/won-items",
                icon: "emoji_events"
            },
            {
                labelKey: "orders",
                href: "/orders",
                icon: "local_shipping"
            },
            {
                labelKey: "messages",
                href: "/messages",
                icon: "chat"
            }
        ]
    },
    {
        titleKey: "account",
        items: [
            {
                labelKey: "profile",
                href: "/profile",
                icon: "account_circle"
            },
            {
                labelKey: "security",
                href: "/security",
                icon: "shield_lock"
            },
            {
                labelKey: "premium",
                href: "/premium",
                icon: "workspace_premium",
                badge: "VIP"
            }
        ]
    },
    {
        titleKey: "consignment",
        sellerOnly: true,
        items: [
            {
                labelKey: "inventory",
                href: "/inventory",
                icon: "inventory_2"
            },
            {
                labelKey: "postItem",
                href: "/post-item",
                icon: "add_box"
            },
            {
                labelKey: "earnings",
                href: "/earnings",
                icon: "payments"
            }
        ]
    }
];
function CollectorSidebar() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("sidebar.collector");
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const [collapsed, setCollapsed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { data: account } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApiData"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchAccountSummary"], null);
    const role = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toFrontendRole"])(account?.profile.roleName ?? null);
    const navGroups = NAV_GROUPS.filter((group)=>!group.sellerOnly || role === "seller");
    const initials = account?.profile.fullName.split(/\s+/).filter(Boolean).slice(-2).map((part)=>part[0]).join("").toUpperCase();
    const [unreadMessages, setUnreadMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CollectorSidebar.useEffect": ()=>{
            const timeout = setTimeout({
                "CollectorSidebar.useEffect.timeout": ()=>{
                    setCollapsed(localStorage.getItem(STORAGE_KEY) === "true");
                }
            }["CollectorSidebar.useEffect.timeout"], 0);
            return ({
                "CollectorSidebar.useEffect": ()=>clearTimeout(timeout)
            })["CollectorSidebar.useEffect"];
        }
    }["CollectorSidebar.useEffect"], []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CollectorSidebar.useEffect": ()=>{
            let cancelled = false;
            async function refreshUnread() {
                try {
                    const conversations = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userApi"].myConversations();
                    if (!cancelled) {
                        setUnreadMessages(conversations.reduce({
                            "CollectorSidebar.useEffect.refreshUnread": (sum, c)=>sum + (c.unreadCount ?? 0)
                        }["CollectorSidebar.useEffect.refreshUnread"], 0));
                    }
                } catch  {
                /* No signed-in user or backend is unavailable. */ }
            }
            void refreshUnread();
            const interval = setInterval({
                "CollectorSidebar.useEffect.interval": ()=>void refreshUnread()
            }["CollectorSidebar.useEffect.interval"], 30_000);
            window.addEventListener(UNREAD_REFRESH_EVENT, refreshUnread);
            return ({
                "CollectorSidebar.useEffect": ()=>{
                    cancelled = true;
                    clearInterval(interval);
                    window.removeEventListener(UNREAD_REFRESH_EVENT, refreshUnread);
                }
            })["CollectorSidebar.useEffect"];
        // Mount-only: the 30s interval and UNREAD_REFRESH_EVENT already keep this fresh.
        // Depending on `pathname` here used to re-fetch on every single navigation, firing a
        // GET /v1/conversations/my the sidebar didn't need just to render an unrelated page.
        }
    }["CollectorSidebar.useEffect"], []);
    function toggleCollapsed() {
        setCollapsed((prev)=>{
            const next = !prev;
            localStorage.setItem(STORAGE_KEY, String(next));
            return next;
        });
    }
    function isItemActive(href) {
        return pathname === href || href === "/profile" && pathname === "/wallet" || href === "/security" && pathname === "/kyc";
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        className: `sticky top-0 hidden h-screen shrink-0 flex-col overflow-x-hidden border-r border-white/10 bg-[var(--luxora-bg-elevated)] transition-[width] duration-200 md:flex ${collapsed ? "w-[72px]" : "w-64"}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `flex items-center px-4 py-5 ${collapsed ? "justify-center" : "justify-between"}`,
                children: [
                    !collapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: "flex items-center gap-2 overflow-hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            className: "h-9 w-auto"
                        }, void 0, false, {
                            fileName: "[project]/components/shells/CollectorSidebar.tsx",
                            lineNumber: 132,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: toggleCollapsed,
                        "aria-label": collapsed ? t("expandMenu") : t("collapseMenu"),
                        className: "grid size-10 shrink-0 place-items-center rounded-xl text-white/40 transition hover:bg-white/5 hover:text-white",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "material-symbols-outlined text-lg",
                            children: collapsed ? "chevron_right" : "chevron_left"
                        }, void 0, false, {
                            fileName: "[project]/components/shells/CollectorSidebar.tsx",
                            lineNumber: 141,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                        lineNumber: 135,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                lineNumber: 125,
                columnNumber: 7
            }, this),
            !collapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-4 mb-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-[var(--luxora-gold)]/15 text-xs font-bold text-[var(--luxora-gold-light)]",
                                children: initials || "?"
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 150,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "min-w-0",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "truncate text-sm font-semibold",
                                        children: account?.profile.fullName ?? t("loading")
                                    }, void 0, false, {
                                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                        lineNumber: 154,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[11px] capitalize text-white/40",
                                        children: account?.profile.roleName ?? ""
                                    }, void 0, false, {
                                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                        lineNumber: 157,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 153,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                        lineNumber: 149,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 grid grid-cols-2 gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg bg-white/5 px-2.5 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] text-white/40",
                                        children: t("balance")
                                    }, void 0, false, {
                                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                        lineNumber: 164,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs font-semibold text-[var(--luxora-gold-light)]",
                                        children: [
                                            (account?.wallet.availableBalance ?? 0).toLocaleString("vi-VN"),
                                            " ₫"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                        lineNumber: 165,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 163,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "rounded-lg bg-white/5 px-2.5 py-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-[10px] text-white/40",
                                        children: t("deposit")
                                    }, void 0, false, {
                                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                        lineNumber: 170,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs font-semibold",
                                        children: [
                                            (account?.wallet.holdBalance ?? 0).toLocaleString("vi-VN"),
                                            " ₫"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                        lineNumber: 171,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 169,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                        lineNumber: 162,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                lineNumber: 148,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: `custom-scrollbar flex-1 overflow-y-auto pb-4 ${collapsed ? "px-2" : "px-3"}`,
                children: navGroups.map((group)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: collapsed ? "mb-3" : "mb-5",
                        children: [
                            !collapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mb-1.5 px-2 text-[10px] font-semibold uppercase tracking-wider text-white/30",
                                children: t(`groups.${group.titleKey}`)
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 187,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-0.5",
                                children: group.items.map((item)=>{
                                    const active = isItemActive(item.href);
                                    const badge = item.href === "/messages" && unreadMessages > 0 ? unreadMessages > 99 ? "99+" : String(unreadMessages) : item.badge;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: item.href,
                                        title: collapsed ? t(`items.${item.labelKey}`) : undefined,
                                        "aria-label": collapsed ? t(`items.${item.labelKey}`) : undefined,
                                        className: `relative flex items-center rounded-xl text-sm transition-colors ${collapsed ? "mx-auto size-11 justify-center p-0" : "gap-3 px-3 py-2.5"} ${active ? "bg-[var(--luxora-gold)]/10 text-[var(--luxora-gold-light)]" : "text-white/60 hover:bg-white/5 hover:text-white"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "material-symbols-outlined block text-xl leading-none",
                                                children: item.icon
                                            }, void 0, false, {
                                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                                lineNumber: 216,
                                                columnNumber: 21
                                            }, this),
                                            collapsed && badge && badge !== "VIP" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "absolute right-1 top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-[#d89716] px-1 font-sans text-[9px] font-bold leading-none text-[#211500] ring-2 ring-[var(--luxora-bg-elevated)]",
                                                children: badge
                                            }, void 0, false, {
                                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                                lineNumber: 220,
                                                columnNumber: 23
                                            }, this),
                                            collapsed && badge === "VIP" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                "aria-hidden": "true",
                                                className: "absolute right-1.5 top-1.5 size-2.5 rounded-full bg-[#d89716] ring-2 ring-[var(--luxora-bg-elevated)]"
                                            }, void 0, false, {
                                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                                lineNumber: 225,
                                                columnNumber: 23
                                            }, this),
                                            !collapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "flex-1 truncate",
                                                children: t(`items.${item.labelKey}`)
                                            }, void 0, false, {
                                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                                lineNumber: 231,
                                                columnNumber: 23
                                            }, this),
                                            !collapsed && badge && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded-full bg-[var(--luxora-gold)] px-1.5 py-0.5 text-[10px] font-semibold text-black",
                                                children: badge
                                            }, void 0, false, {
                                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                                lineNumber: 234,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, item.href, true, {
                                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                        lineNumber: 201,
                                        columnNumber: 19
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 191,
                                columnNumber: 13
                            }, this)
                        ]
                    }, group.titleKey, true, {
                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                        lineNumber: 185,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                lineNumber: 179,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: `flex flex-col gap-1 border-t border-white/10 py-4 ${collapsed ? "items-center px-2" : "px-3"}`,
                children: [
                    !collapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "px-3 pb-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$i18n$2f$LanguageSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/components/shells/CollectorSidebar.tsx",
                            lineNumber: 251,
                            columnNumber: 51
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                        lineNumber: 251,
                        columnNumber: 24
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/wallet",
                        title: collapsed ? t("topUp") : undefined,
                        "aria-label": collapsed ? t("topUp") : undefined,
                        className: `flex items-center rounded-xl text-sm text-white/60 transition hover:bg-white/5 hover:text-white ${collapsed ? "size-11 justify-center p-0" : "gap-3 px-3 py-2.5"}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "material-symbols-outlined text-xl",
                                children: "add_circle"
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 260,
                                columnNumber: 11
                            }, this),
                            !collapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: t("topUp")
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 263,
                                columnNumber: 26
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                        lineNumber: 252,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/auth",
                        onClick: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authApi"].logout(),
                        title: collapsed ? t("logout") : undefined,
                        "aria-label": collapsed ? t("logout") : undefined,
                        className: `flex items-center rounded-xl text-sm text-white/60 transition hover:bg-white/5 hover:text-white ${collapsed ? "size-11 justify-center p-0" : "gap-3 px-3 py-2.5"}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "material-symbols-outlined text-xl",
                                children: "logout"
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 274,
                                columnNumber: 11
                            }, this),
                            !collapsed && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: t("logout")
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                                lineNumber: 275,
                                columnNumber: 26
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/shells/CollectorSidebar.tsx",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shells/CollectorSidebar.tsx",
                lineNumber: 246,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/shells/CollectorSidebar.tsx",
        lineNumber: 120,
        columnNumber: 5
    }, this);
}
_s(CollectorSidebar, "B959rAbXPzZgOgUfKPQ5EGA51ac=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApiData"]
    ];
});
_c = CollectorSidebar;
var _c;
__turbopack_context__.k.register(_c, "CollectorSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/feature/LiveChat.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LiveChat
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function LiveChat() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("liveChat");
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const [open, setOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [messages, setMessages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "LiveChat.useState": ()=>[
                {
                    id: "1",
                    from: "agent",
                    text: t("hello")
                }
            ]
    }["LiveChat.useState"]);
    const [input, setInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [sending, setSending] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const messagesEndRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LiveChat.useEffect": ()=>{
            messagesEndRef.current?.scrollIntoView({
                behavior: "smooth"
            });
        }
    }["LiveChat.useEffect"], [
        messages,
        sending
    ]);
    // Messages has its own chat surface, so the floating button is hidden there.
    if (pathname === "/messages" || pathname.startsWith("/messages/")) {
        return null;
    }
    async function sendMessage() {
        const text = input.trim();
        if (!text || sending) return;
        setMessages((prev)=>[
                ...prev,
                {
                    id: crypto.randomUUID(),
                    from: "user",
                    text
                }
            ]);
        setInput("");
        setSending(true);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chatbotApi"].reply(text);
            setMessages((prev)=>[
                    ...prev,
                    {
                        id: crypto.randomUUID(),
                        from: "agent",
                        text: response.reply
                    }
                ]);
        } catch  {
            setMessages((prev)=>[
                    ...prev,
                    {
                        id: crypto.randomUUID(),
                        from: "agent",
                        text: t("fallback")
                    }
                ]);
        } finally{
            setSending(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed bottom-6 right-6 z-40",
        children: [
            open && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "glass-panel mb-3 flex h-96 w-80 flex-col overflow-hidden rounded-2xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between border-b border-white/10 px-4 py-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm font-semibold",
                                children: t("title")
                            }, void 0, false, {
                                fileName: "[project]/components/feature/LiveChat.tsx",
                                lineNumber: 65,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setOpen(false),
                                className: "text-white/40 hover:text-white",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "material-symbols-outlined text-lg",
                                    children: "close"
                                }, void 0, false, {
                                    fileName: "[project]/components/feature/LiveChat.tsx",
                                    lineNumber: 71,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/feature/LiveChat.tsx",
                                lineNumber: 66,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/feature/LiveChat.tsx",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "custom-scrollbar flex-1 space-y-3 overflow-y-auto p-4",
                        children: [
                            messages.map((m)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `max-w-[85%] rounded-2xl px-3.5 py-2 text-xs ${m.from === "user" ? "ml-auto bg-[var(--luxora-gold)] text-black" : "bg-white/10 text-white/80"}`,
                                    children: m.text
                                }, m.id, false, {
                                    fileName: "[project]/components/feature/LiveChat.tsx",
                                    lineNumber: 77,
                                    columnNumber: 15
                                }, this)),
                            sending && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "max-w-[85%] rounded-2xl bg-white/10 px-3.5 py-2 text-xs text-white/60",
                                children: t("replying")
                            }, void 0, false, {
                                fileName: "[project]/components/feature/LiveChat.tsx",
                                lineNumber: 89,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                ref: messagesEndRef
                            }, void 0, false, {
                                fileName: "[project]/components/feature/LiveChat.tsx",
                                lineNumber: 93,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/feature/LiveChat.tsx",
                        lineNumber: 75,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2 border-t border-white/10 p-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                value: input,
                                disabled: sending,
                                onChange: (e)=>setInput(e.target.value),
                                onKeyDown: (e)=>e.key === "Enter" && void sendMessage(),
                                placeholder: t("placeholder"),
                                className: "flex-1 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-xs outline-none placeholder:text-white/30 focus:border-[var(--luxora-gold)]"
                            }, void 0, false, {
                                fileName: "[project]/components/feature/LiveChat.tsx",
                                lineNumber: 97,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>void sendMessage(),
                                disabled: sending || !input.trim(),
                                "aria-label": t("send"),
                                className: "flex h-8 w-8 items-center justify-center rounded-full bg-[var(--luxora-gold)] text-black disabled:cursor-not-allowed disabled:opacity-40",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "material-symbols-outlined text-base",
                                    children: "send"
                                }, void 0, false, {
                                    fileName: "[project]/components/feature/LiveChat.tsx",
                                    lineNumber: 113,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/feature/LiveChat.tsx",
                                lineNumber: 106,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/feature/LiveChat.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/feature/LiveChat.tsx",
                lineNumber: 63,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                type: "button",
                onClick: ()=>setOpen((o)=>!o),
                className: "glow-accent flex h-14 w-14 items-center justify-center rounded-full bg-[var(--luxora-gold)] text-black shadow-lg",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "material-symbols-outlined text-2xl",
                    children: open ? "close" : "chat"
                }, void 0, false, {
                    fileName: "[project]/components/feature/LiveChat.tsx",
                    lineNumber: 126,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/feature/LiveChat.tsx",
                lineNumber: 121,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/feature/LiveChat.tsx",
        lineNumber: 61,
        columnNumber: 5
    }, this);
}
_s(LiveChat, "IqtuO8TZ0L77zKWBDY1TPfu2Mqc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = LiveChat;
var _c;
__turbopack_context__.k.register(_c, "LiveChat");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/shells/CollectorShell.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>CollectorShell
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shells$2f$CollectorSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/shells/CollectorSidebar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$feature$2f$LiveChat$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/feature/LiveChat.tsx [app-client] (ecmascript)");
;
;
;
;
;
function CollectorShell({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "luxora-app flex min-h-screen",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shells$2f$CollectorSidebar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/shells/CollectorShell.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex min-h-screen flex-1 flex-col",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "flex items-center justify-between border-b border-white/10 px-4 py-3 md:hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                href: "/",
                                className: "flex items-center",
                                "aria-label": "BidZone",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    className: "h-9 w-auto"
                                }, void 0, false, {
                                    fileName: "[project]/components/shells/CollectorShell.tsx",
                                    lineNumber: 18,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorShell.tsx",
                                lineNumber: 17,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "material-symbols-outlined flex h-8 w-8 items-center justify-center rounded-full bg-white/10 text-lg text-white/70",
                                children: "person"
                            }, void 0, false, {
                                fileName: "[project]/components/shells/CollectorShell.tsx",
                                lineNumber: 20,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/shells/CollectorShell.tsx",
                        lineNumber: 16,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                        className: "flex-1",
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/components/shells/CollectorShell.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shells/CollectorShell.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$feature$2f$LiveChat$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/shells/CollectorShell.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/shells/CollectorShell.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
_c = CollectorShell;
var _c;
__turbopack_context__.k.register(_c, "CollectorShell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/wallet/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>WalletPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shells$2f$CollectorShell$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/shells/CollectorShell.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/use-api-data.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
async function loadWallet() {
    const [wallet, transactions] = await Promise.all([
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walletApi"].get(),
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walletApi"].transactions()
    ]);
    return {
        wallet,
        transactions
    };
}
const EMPTY_WALLET = {
    wallet: {
        walletId: 0,
        userId: 0,
        balance: 0,
        holdBalance: 0,
        availableBalance: 0,
        status: ""
    },
    transactions: []
};
const DEPOSIT_PRESETS = [
    100_000,
    500_000,
    1_000_000,
    5_000_000
];
function formatVnd(value) {
    return `${value.toLocaleString("vi-VN")} ₫`;
}
function WalletPage() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("walletPage");
    const { data, setData, loading, error } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApiData"])(loadWallet, EMPTY_WALLET);
    const [showDeposit, setShowDeposit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showWithdraw, setShowWithdraw] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [withdrawAmount, setWithdrawAmount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [bankName, setBankName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [accountNumber, setAccountNumber] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [accountName, setAccountName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [withdrawing, setWithdrawing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [withdrawError, setWithdrawError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [withdrawSuccess, setWithdrawSuccess] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [amount, setAmount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("100000");
    const [depositQr, setDepositQr] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [balanceBeforeDeposit, setBalanceBeforeDeposit] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [submitting, setSubmitting] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [checking, setChecking] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [actionError, setActionError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [depositStatus, setDepositStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [copiedField, setCopiedField] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [qrImageError, setQrImageError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const numericAmount = Number(amount.replace(/\D/g, ""));
    function openDeposit() {
        setShowDeposit(true);
        setDepositQr(null);
        setActionError("");
        setDepositStatus("");
        setCopiedField("");
        setQrImageError(false);
    }
    function closeDeposit() {
        setShowDeposit(false);
        setDepositQr(null);
        setActionError("");
        setDepositStatus("");
        setQrImageError(false);
    }
    async function createDepositQr(event) {
        event.preventDefault();
        if (!Number.isSafeInteger(numericAmount) || numericAmount < 1_000) {
            setActionError(t("depositMinError"));
            return;
        }
        setSubmitting(true);
        setActionError("");
        setDepositStatus("");
        try {
            const qr = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walletApi"].deposit(numericAmount);
            setBalanceBeforeDeposit(data.wallet.balance);
            setDepositQr(qr);
            setQrImageError(false);
        } catch (cause) {
            setActionError(cause instanceof __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"] ? cause.message : t("depositError"));
        } finally{
            setSubmitting(false);
        }
    }
    const numericWithdrawAmount = Number(withdrawAmount.replace(/\D/g, ""));
    function openWithdraw() {
        setShowWithdraw(true);
        setWithdrawError("");
        setWithdrawSuccess("");
    }
    async function submitWithdraw(event) {
        event.preventDefault();
        setWithdrawError("");
        setWithdrawSuccess("");
        if (!Number.isSafeInteger(numericWithdrawAmount) || numericWithdrawAmount < 10_000) {
            setWithdrawError(t("withdrawMinError"));
            return;
        }
        if (numericWithdrawAmount > data.wallet.availableBalance) {
            setWithdrawError(t("withdrawExceedError"));
            return;
        }
        setWithdrawing(true);
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["walletApi"].withdraw({
                amount: numericWithdrawAmount,
                bankName: bankName.trim(),
                accountNumber: accountNumber.trim(),
                accountName: accountName.trim()
            });
            setWithdrawSuccess(t("withdrawSuccess"));
            setWithdrawAmount("");
            const nextData = await loadWallet();
            setData(nextData);
        } catch (cause) {
            setWithdrawError(cause instanceof __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"] ? cause.message : t("withdrawError"));
        } finally{
            setWithdrawing(false);
        }
    }
    async function copyValue(field, value) {
        try {
            await navigator.clipboard.writeText(value);
            setCopiedField(field);
            window.setTimeout(()=>setCopiedField(""), 1500);
        } catch  {
            setActionError(t("depositCopyError"));
        }
    }
    async function checkDeposit() {
        setChecking(true);
        setActionError("");
        try {
            const nextData = await loadWallet();
            setData(nextData);
            if (nextData.wallet.balance > balanceBeforeDeposit) {
                setDepositStatus(t("depositReceived", {
                    amount: formatVnd(nextData.wallet.balance - balanceBeforeDeposit)
                }));
            } else {
                setDepositStatus(t("depositPending"));
            }
        } catch (cause) {
            setActionError(cause instanceof Error ? cause.message : t("depositCheckError"));
        } finally{
            setChecking(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shells$2f$CollectorShell$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto max-w-7xl px-6 py-10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "font-display-lg text-3xl",
                        children: t("title")
                    }, void 0, false, {
                        fileName: "[project]/app/wallet/page.tsx",
                        lineNumber: 196,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "glass-panel rounded-2xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-white/40",
                                        children: t("availableBalance")
                                    }, void 0, false, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 200,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-2 text-2xl font-bold text-[var(--luxora-gold-light)]",
                                        children: [
                                            data.wallet.availableBalance.toLocaleString("vi-VN"),
                                            " ₫"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 201,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: openDeposit,
                                        className: "gradient-cta mt-4 w-full rounded-full py-2.5 text-xs font-semibold text-black",
                                        children: t("depositBtn")
                                    }, void 0, false, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 204,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/wallet/page.tsx",
                                lineNumber: 199,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "glass-panel rounded-2xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-white/40",
                                        children: t("holdBalance")
                                    }, void 0, false, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 213,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-2 text-2xl font-bold",
                                        children: [
                                            data.wallet.holdBalance.toLocaleString("vi-VN"),
                                            " ₫"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 214,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: openWithdraw,
                                        className: "mt-4 w-full rounded-full border border-white/15 py-2.5 text-xs font-semibold hover:border-[var(--luxora-gold)]",
                                        children: t("withdrawBtn")
                                    }, void 0, false, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 217,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/wallet/page.tsx",
                                lineNumber: 212,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "glass-panel rounded-2xl p-6",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-xs text-white/40",
                                        children: t("totalAssets")
                                    }, void 0, false, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 226,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-2 text-2xl font-bold",
                                        children: [
                                            data.wallet.balance.toLocaleString("vi-VN"),
                                            " ₫"
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 227,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/wallet/page.tsx",
                                lineNumber: 225,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/wallet/page.tsx",
                        lineNumber: 198,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "font-headline-md mt-10 mb-4 text-lg",
                        children: t("transactionHistory")
                    }, void 0, false, {
                        fileName: "[project]/app/wallet/page.tsx",
                        lineNumber: 233,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "overflow-x-auto rounded-2xl border border-white/10",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                            className: "w-full min-w-[640px] text-left text-sm",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                        className: "border-b border-white/10 text-xs uppercase tracking-wider text-white/40",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-5 py-3 font-medium",
                                                children: t("colDate")
                                            }, void 0, false, {
                                                fileName: "[project]/app/wallet/page.tsx",
                                                lineNumber: 240,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-5 py-3 font-medium",
                                                children: t("colType")
                                            }, void 0, false, {
                                                fileName: "[project]/app/wallet/page.tsx",
                                                lineNumber: 241,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-5 py-3 font-medium",
                                                children: t("colDesc")
                                            }, void 0, false, {
                                                fileName: "[project]/app/wallet/page.tsx",
                                                lineNumber: 242,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-5 py-3 font-medium",
                                                children: t("colAmount")
                                            }, void 0, false, {
                                                fileName: "[project]/app/wallet/page.tsx",
                                                lineNumber: 243,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
                                                className: "px-5 py-3 font-medium",
                                                children: t("colStatus")
                                            }, void 0, false, {
                                                fileName: "[project]/app/wallet/page.tsx",
                                                lineNumber: 244,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 239,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 238,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
                                    children: [
                                        data.transactions.map((tx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                                className: "border-b border-white/5",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-5 py-4 text-white/60",
                                                        children: new Intl.DateTimeFormat("vi-VN").format(new Date(tx.createdAt))
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/wallet/page.tsx",
                                                        lineNumber: 250,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-5 py-4",
                                                        children: tx.transactionTypeLabel
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/wallet/page.tsx",
                                                        lineNumber: 255,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-5 py-4 text-white/60",
                                                        children: tx.description
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/wallet/page.tsx",
                                                        lineNumber: 256,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: `px-5 py-4 font-semibold ${tx.signedAmount >= 0 ? "text-green-300" : "text-red-300"}`,
                                                        children: [
                                                            tx.signedAmount >= 0 ? "+" : "",
                                                            tx.signedAmount.toLocaleString("vi-VN"),
                                                            " ₫"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/wallet/page.tsx",
                                                        lineNumber: 257,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                        className: "px-5 py-4",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: `rounded-full px-3 py-1 text-[11px] font-semibold ${tx.status.toUpperCase() === "COMPLETED" ? "bg-green-500/10 text-green-300" : "bg-yellow-500/10 text-yellow-300"}`,
                                                            children: tx.status
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/wallet/page.tsx",
                                                            lineNumber: 266,
                                                            columnNumber: 21
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/wallet/page.tsx",
                                                        lineNumber: 265,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, tx.transactionId, true, {
                                                fileName: "[project]/app/wallet/page.tsx",
                                                lineNumber: 249,
                                                columnNumber: 17
                                            }, this)),
                                        !loading && data.transactions.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
                                                colSpan: 5,
                                                className: "px-5 py-10 text-center text-white/45",
                                                children: error ?? t("noTransactions")
                                            }, void 0, false, {
                                                fileName: "[project]/app/wallet/page.tsx",
                                                lineNumber: 280,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 279,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 247,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 237,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/wallet/page.tsx",
                        lineNumber: 236,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/wallet/page.tsx",
                lineNumber: 195,
                columnNumber: 7
            }, this),
            showDeposit ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm",
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": "deposit-title",
                onMouseDown: (event)=>{
                    if (event.target === event.currentTarget) closeDeposit();
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative max-h-[calc(100vh-2rem)] w-full max-w-lg overflow-y-auto rounded-lg border border-white/15 bg-[var(--luxora-bg-elevated)] p-5 text-[var(--luxora-text)] shadow-2xl sm:p-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: closeDeposit,
                            title: t("closeBtn"),
                            "aria-label": t("closeBtn"),
                            className: "absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full text-[var(--luxora-text)]/50 transition-colors hover:bg-white/10 hover:text-[var(--luxora-text)]",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "material-symbols-outlined",
                                children: "close"
                            }, void 0, false, {
                                fileName: "[project]/app/wallet/page.tsx",
                                lineNumber: 308,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 301,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "deposit-title",
                            className: "font-headline-md pr-12 text-xl text-[var(--luxora-text)]",
                            children: t("depositModalTitle")
                        }, void 0, false, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 311,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-1 text-sm text-[var(--luxora-text)]/60",
                            children: t("depositModalSubtitle")
                        }, void 0, false, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 314,
                            columnNumber: 13
                        }, this),
                        !depositQr ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: createDepositQr,
                            className: "mt-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "deposit-amount",
                                    className: "text-xs font-semibold uppercase tracking-wider text-[var(--luxora-text)]/60",
                                    children: t("depositAmountLabel")
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 320,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-2 flex h-12 items-center rounded-lg border border-white/15 bg-[var(--luxora-bg-soft)] px-4 focus-within:border-[var(--luxora-gold)]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            id: "deposit-amount",
                                            type: "text",
                                            inputMode: "numeric",
                                            autoFocus: true,
                                            value: numericAmount ? numericAmount.toLocaleString("vi-VN") : "",
                                            onChange: (event)=>setAmount(event.target.value.replace(/\D/g, "")),
                                            placeholder: t("depositMinPlaceholder"),
                                            className: "min-w-0 flex-1 bg-transparent text-lg font-semibold text-[var(--luxora-text)] outline-none placeholder:text-[var(--luxora-text)]/40"
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 327,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-sm text-[var(--luxora-text)]/45",
                                            children: "₫"
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 339,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 326,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4",
                                    children: DEPOSIT_PRESETS.map((preset)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>setAmount(String(preset)),
                                            className: `h-10 rounded-lg border text-xs font-semibold transition-colors ${numericAmount === preset ? "border-[var(--luxora-gold)] bg-[var(--luxora-gold)]/10 text-[var(--luxora-gold-light)]" : "border-white/10 text-[var(--luxora-text)]/65 hover:border-white/25"}`,
                                            children: preset.toLocaleString("vi-VN")
                                        }, preset, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 344,
                                            columnNumber: 21
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 342,
                                    columnNumber: 17
                                }, this),
                                actionError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-4 text-sm text-red-500",
                                    children: actionError
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 360,
                                    columnNumber: 19
                                }, this) : null,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "submit",
                                    disabled: submitting,
                                    className: "gradient-cta mt-6 h-11 w-full rounded-full text-sm font-bold text-black disabled:cursor-not-allowed disabled:opacity-50",
                                    children: submitting ? t("depositCreatingBtn") : t("depositCreateBtn")
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 363,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 319,
                            columnNumber: 15
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mx-auto w-fit overflow-hidden rounded-lg bg-white p-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: depositQr.qrUrl,
                                        alt: `VietQR ${formatVnd(depositQr.amount)}`,
                                        width: 280,
                                        height: 280,
                                        unoptimized: true,
                                        priority: true,
                                        onError: ()=>setQrImageError(true),
                                        className: "h-auto w-[260px] sm:w-[280px]"
                                    }, void 0, false, {
                                        fileName: "[project]/app/wallet/page.tsx",
                                        lineNumber: 374,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 373,
                                    columnNumber: 17
                                }, this),
                                qrImageError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-3 rounded-lg border border-yellow-400/25 bg-yellow-500/10 px-3 py-2 text-sm text-yellow-100",
                                    children: t.rich("depositQrError", {
                                        link: (chunks)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: depositQr.qrUrl,
                                                target: "_blank",
                                                rel: "noreferrer",
                                                className: "font-semibold text-[var(--luxora-gold-light)] underline",
                                                children: chunks
                                            }, void 0, false, {
                                                fileName: "[project]/app/wallet/page.tsx",
                                                lineNumber: 390,
                                                columnNumber: 25
                                            }, this)
                                    })
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 387,
                                    columnNumber: 19
                                }, this) : null,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dl", {
                                    className: "mt-5 divide-y divide-white/10 border-y border-white/10 text-sm",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DepositDetail, {
                                            label: t("depositDetailAmount"),
                                            value: formatVnd(depositQr.amount)
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 404,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DepositDetail, {
                                            label: t("depositDetailAccount"),
                                            value: depositQr.bankAccount,
                                            onCopy: ()=>void copyValue("account", depositQr.bankAccount),
                                            copied: copiedField === "account",
                                            copiedLabel: t("copiedBtn"),
                                            copyLabel: t("copyBtn", {
                                                label: t("depositDetailAccount").toLowerCase()
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 405,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DepositDetail, {
                                            label: t("depositDetailHolder"),
                                            value: depositQr.accountName
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 415,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DepositDetail, {
                                            label: t("depositDetailContent"),
                                            value: depositQr.content,
                                            emphasize: true,
                                            onCopy: ()=>void copyValue("content", depositQr.content),
                                            copied: copiedField === "content",
                                            copiedLabel: t("copiedBtn"),
                                            copyLabel: t("copyBtn", {
                                                label: t("depositDetailContent").toLowerCase()
                                            })
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 419,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 403,
                                    columnNumber: 17
                                }, this),
                                actionError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-4 text-sm text-red-500",
                                    children: actionError
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 431,
                                    columnNumber: 19
                                }, this) : null,
                                depositStatus ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: `mt-4 text-sm ${depositStatus.startsWith(t("depositReceived", {
                                        amount: ""
                                    }).slice(0, 5)) ? "text-green-600" : "text-yellow-600"}`,
                                    children: depositStatus
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 434,
                                    columnNumber: 19
                                }, this) : null,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-5 flex gap-3",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>{
                                                setDepositQr(null);
                                                setDepositStatus("");
                                                setQrImageError(false);
                                            },
                                            className: "h-11 flex-1 rounded-full border border-white/15 text-[var(--luxora-text)] text-sm font-semibold hover:border-white/30",
                                            children: t("depositChangeAmount")
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 446,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>void checkDeposit(),
                                            disabled: checking,
                                            className: "gradient-cta h-11 flex-1 rounded-full text-sm font-bold text-black disabled:opacity-50",
                                            children: checking ? t("depositChecking") : t("depositCheckBalance")
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 457,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 445,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 372,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/wallet/page.tsx",
                    lineNumber: 300,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/wallet/page.tsx",
                lineNumber: 291,
                columnNumber: 9
            }, this) : null,
            showWithdraw ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm",
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": "withdraw-title",
                onMouseDown: (event)=>{
                    if (event.target === event.currentTarget) setShowWithdraw(false);
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative max-h-[calc(100vh-2rem)] w-full max-w-lg overflow-y-auto rounded-lg border border-white/15 bg-[var(--luxora-bg-elevated)] p-5 text-[var(--luxora-text)] shadow-2xl sm:p-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>setShowWithdraw(false),
                            title: t("closeBtn"),
                            "aria-label": t("closeBtn"),
                            className: "absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full text-[var(--luxora-text)]/50 transition-colors hover:bg-white/10 hover:text-[var(--luxora-text)]",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "material-symbols-outlined",
                                children: "close"
                            }, void 0, false, {
                                fileName: "[project]/app/wallet/page.tsx",
                                lineNumber: 489,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 482,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            id: "withdraw-title",
                            className: "font-headline-md pr-12 text-xl text-[var(--luxora-text)]",
                            children: t("withdrawModalTitle")
                        }, void 0, false, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 492,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "mt-1 text-sm text-[var(--luxora-text)]/60",
                            children: t("withdrawModalSubtitle", {
                                balance: formatVnd(data.wallet.availableBalance)
                            })
                        }, void 0, false, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 495,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                            onSubmit: submitWithdraw,
                            className: "mt-6 flex flex-col gap-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-semibold uppercase tracking-wider text-[var(--luxora-text)]/60",
                                            children: t("withdrawAmountLabel")
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 501,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-2 flex h-12 items-center rounded-lg border border-white/15 bg-[var(--luxora-bg-soft)] px-4 focus-within:border-[var(--luxora-gold)]",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    type: "text",
                                                    inputMode: "numeric",
                                                    autoFocus: true,
                                                    value: numericWithdrawAmount ? numericWithdrawAmount.toLocaleString("vi-VN") : "",
                                                    onChange: (event)=>setWithdrawAmount(event.target.value.replace(/\D/g, "")),
                                                    placeholder: t("withdrawMinPlaceholder"),
                                                    className: "min-w-0 flex-1 bg-transparent text-lg font-semibold text-[var(--luxora-text)] outline-none placeholder:text-[var(--luxora-text)]/40"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/wallet/page.tsx",
                                                    lineNumber: 505,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "text-sm text-[var(--luxora-text)]/45",
                                                    children: "₫"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/wallet/page.tsx",
                                                    lineNumber: 520,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 504,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 500,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-semibold uppercase tracking-wider text-[var(--luxora-text)]/60",
                                            children: t("withdrawBankLabel")
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 525,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            required: true,
                                            value: bankName,
                                            onChange: (event)=>setBankName(event.target.value),
                                            placeholder: t("withdrawBankExample"),
                                            className: "mt-2 h-12 w-full rounded-lg border border-white/15 bg-[var(--luxora-bg-soft)] px-4 text-sm text-[var(--luxora-text)] outline-none placeholder:text-[var(--luxora-text)]/40 focus:border-[var(--luxora-gold)]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 528,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 524,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-semibold uppercase tracking-wider text-[var(--luxora-text)]/60",
                                            children: t("withdrawAccountLabel")
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 539,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            required: true,
                                            inputMode: "numeric",
                                            value: accountNumber,
                                            onChange: (event)=>setAccountNumber(event.target.value.replace(/\D/g, "")),
                                            placeholder: t("withdrawAccountPlaceholder"),
                                            className: "mt-2 h-12 w-full rounded-lg border border-white/15 bg-[var(--luxora-bg-soft)] px-4 text-sm text-[var(--luxora-text)] outline-none placeholder:text-[var(--luxora-text)]/40 focus:border-[var(--luxora-gold)]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 542,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 538,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "block",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs font-semibold uppercase tracking-wider text-[var(--luxora-text)]/60",
                                            children: t("withdrawHolderLabel")
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 556,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                            type: "text",
                                            required: true,
                                            value: accountName,
                                            onChange: (event)=>setAccountName(event.target.value),
                                            placeholder: t("withdrawHolderPlaceholder"),
                                            className: "mt-2 h-12 w-full rounded-lg border border-white/15 bg-[var(--luxora-bg-soft)] px-4 text-sm text-[var(--luxora-text)] outline-none placeholder:text-[var(--luxora-text)]/40 focus:border-[var(--luxora-gold)]"
                                        }, void 0, false, {
                                            fileName: "[project]/app/wallet/page.tsx",
                                            lineNumber: 559,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 555,
                                    columnNumber: 15
                                }, this),
                                withdrawError ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-red-500",
                                    children: withdrawError
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 570,
                                    columnNumber: 17
                                }, this) : null,
                                withdrawSuccess ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm text-green-600",
                                    children: withdrawSuccess
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 573,
                                    columnNumber: 17
                                }, this) : null,
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "submit",
                                    disabled: withdrawing,
                                    className: "gradient-cta h-11 w-full rounded-full text-sm font-bold text-black disabled:cursor-not-allowed disabled:opacity-50",
                                    children: withdrawing ? t("withdrawSubmitting") : t("withdrawSubmitBtn")
                                }, void 0, false, {
                                    fileName: "[project]/app/wallet/page.tsx",
                                    lineNumber: 576,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 499,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/wallet/page.tsx",
                    lineNumber: 481,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/wallet/page.tsx",
                lineNumber: 472,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true, {
        fileName: "[project]/app/wallet/page.tsx",
        lineNumber: 194,
        columnNumber: 5
    }, this);
}
_s(WalletPage, "k3RKWP/x8vN9aVZlZhAkmuB2lAk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApiData"]
    ];
});
_c = WalletPage;
function DepositDetail({ label, value, emphasize = false, onCopy, copied = false, copyLabel, copiedLabel }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex min-h-12 items-center justify-between gap-4 py-2.5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dt", {
                className: "shrink-0 text-[var(--luxora-text)]/45",
                children: label
            }, void 0, false, {
                fileName: "[project]/app/wallet/page.tsx",
                lineNumber: 610,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("dd", {
                className: "flex min-w-0 items-center justify-end gap-2 text-right",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `break-all font-semibold ${emphasize ? "text-[var(--luxora-gold-light)]" : "text-[var(--luxora-text)]"}`,
                        children: value
                    }, void 0, false, {
                        fileName: "[project]/app/wallet/page.tsx",
                        lineNumber: 612,
                        columnNumber: 9
                    }, this),
                    onCopy ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: onCopy,
                        title: copied ? copiedLabel : copyLabel,
                        "aria-label": copied ? copiedLabel : copyLabel,
                        className: "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-[var(--luxora-text)]/50 hover:bg-white/10 hover:text-[var(--luxora-text)]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "material-symbols-outlined text-lg",
                            children: copied ? "check" : "content_copy"
                        }, void 0, false, {
                            fileName: "[project]/app/wallet/page.tsx",
                            lineNumber: 627,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/wallet/page.tsx",
                        lineNumber: 620,
                        columnNumber: 11
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/app/wallet/page.tsx",
                lineNumber: 611,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/wallet/page.tsx",
        lineNumber: 609,
        columnNumber: 5
    }, this);
}
_c1 = DepositDetail;
var _c, _c1;
__turbopack_context__.k.register(_c, "WalletPage");
__turbopack_context__.k.register(_c1, "DepositDetail");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_171flaj._.js.map