(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_1y_djgf._.js","static/chunks/node_modules_0zvmcp3._.js"],
    source: "dynamic"
});
