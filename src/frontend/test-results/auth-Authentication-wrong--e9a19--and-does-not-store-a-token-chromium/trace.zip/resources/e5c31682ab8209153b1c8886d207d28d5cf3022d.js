(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules_0go6obc._.js","static/chunks/components_performance_MaterialSymbolsLoader_tsx_0tj1ug1._.js","static/chunks/app_globals_0yg4wg8.css"],
    source: "dynamic"
});
