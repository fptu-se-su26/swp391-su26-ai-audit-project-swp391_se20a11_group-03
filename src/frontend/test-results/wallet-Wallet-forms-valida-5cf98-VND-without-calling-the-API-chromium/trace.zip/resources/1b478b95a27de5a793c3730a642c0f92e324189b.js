(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_171flaj._.js","static/chunks/node_modules_0zvbupp._.js"],
    source: "dynamic"
});
