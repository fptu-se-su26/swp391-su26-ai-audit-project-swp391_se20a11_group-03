(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_1densh7._.js","static/chunks/node_modules_next_11ftsbe._.js","static/chunks/node_modules_react-icons_fc_index_mjs_1k7lkbz._.js","static/chunks/node_modules_react-icons_fi_index_mjs_0365wp-._.js","static/chunks/node_modules_react-icons_lib_11_gx9i._.js","static/chunks/node_modules_next-intl_dist_esm_development_react-client_index_1hk545v.js"],
    source: "dynamic"
});
