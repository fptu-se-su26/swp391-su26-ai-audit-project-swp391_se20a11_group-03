(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BidZoneLogo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
function BidZoneLogo({ className = "h-10 w-auto", priority = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `inline-flex items-center gap-2.5 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "relative aspect-square h-full shrink-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: "/bidzone-logo.png",
                    alt: "",
                    fill: true,
                    sizes: "64px",
                    priority: priority,
                    className: "object-contain"
                }, void 0, false, {
                    fileName: "[project]/components/brand/BidZoneLogo.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/brand/BidZoneLogo.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[1.35rem] font-black leading-none tracking-[-0.055em]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-white",
                        children: "Bid"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/BidZoneLogo.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[#d5b15d]",
                        children: "Zone"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/BidZoneLogo.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/brand/BidZoneLogo.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/brand/BidZoneLogo.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = BidZoneLogo;
var _c;
__turbopack_context__.k.register(_c, "BidZoneLogo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/i18n/LanguageSwitcher.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LanguageSwitcher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
/**
 * Persist the locale in NEXT_LOCALE and refresh without changing URL structure.
 */ function setLocaleCookie(locale) {
    document.cookie = `NEXT_LOCALE=${locale}; path=/; max-age=31536000; SameSite=Lax`;
}
function LanguageSwitcher({ compactOnMobile = false }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("language");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isPending, startTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])();
    function handleSwitch() {
        // Read the active locale from the cookie.
        const current = document.cookie.split("; ").find((row)=>row.startsWith("NEXT_LOCALE="))?.split("=")[1] ?? "vi";
        const next = current === "vi" ? "en" : "vi";
        setLocaleCookie(next);
        startTransition(()=>{
            router.refresh();
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        onClick: handleSwitch,
        disabled: isPending,
        "aria-label": t("switchTo"),
        className: `language-switcher${compactOnMobile ? " language-switcher--compact" : ""}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiGlobe"], {
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: compactOnMobile ? "hidden sm:inline" : undefined,
                children: t("current")
            }, void 0, false, {
                fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
_s(LanguageSwitcher, "IQNdCJE7xrs4v6E4HoZyj8QB7U4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"]
    ];
});
_c = LanguageSwitcher;
var _c;
__turbopack_context__.k.register(_c, "LanguageSwitcher");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/theme/ThemeToggle.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThemeToggle
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const THEME_STORAGE_KEY = "bidzone-theme";
const THEME_CHANGE_EVENT = "bidzone:theme-change";
function getThemeSnapshot() {
    return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
}
function getServerThemeSnapshot() {
    return "light";
}
function subscribeToTheme(onStoreChange) {
    function handleStorage(event) {
        if (event.key !== THEME_STORAGE_KEY) return;
        const theme = event.newValue === "dark" ? "dark" : "light";
        document.documentElement.dataset.theme = theme;
        onStoreChange();
    }
    window.addEventListener(THEME_CHANGE_EVENT, onStoreChange);
    window.addEventListener("storage", handleStorage);
    return ()=>{
        window.removeEventListener(THEME_CHANGE_EVENT, onStoreChange);
        window.removeEventListener("storage", handleStorage);
    };
}
function ThemeToggle() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("themeToggle");
    const theme = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeToTheme, getThemeSnapshot, getServerThemeSnapshot);
    const isDark = theme === "dark";
    function toggleTheme() {
        const nextTheme = isDark ? "light" : "dark";
        document.documentElement.dataset.theme = nextTheme;
        localStorage.setItem(THEME_STORAGE_KEY, nextTheme);
        window.dispatchEvent(new Event(THEME_CHANGE_EVENT));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        onClick: toggleTheme,
        "aria-label": isDark ? t("switchToLight") : t("switchToDark"),
        "aria-pressed": isDark,
        title: isDark ? t("lightTheme") : t("darkTheme"),
        suppressHydrationWarning: true,
        className: "theme-toggle",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiSun"], {
                className: "theme-toggle__sun",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/theme/ThemeToggle.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiMoon"], {
                className: "theme-toggle__moon",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/theme/ThemeToggle.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "theme-toggle__light-label hidden sm:inline",
                children: t("light")
            }, void 0, false, {
                fileName: "[project]/components/theme/ThemeToggle.tsx",
                lineNumber: 65,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "theme-toggle__dark-label hidden sm:inline",
                children: t("dark")
            }, void 0, false, {
                fileName: "[project]/components/theme/ThemeToggle.tsx",
                lineNumber: 66,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/theme/ThemeToggle.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_s(ThemeToggle, "hBzuaQ8mUE/GN7MwAvgwGKXI14k=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
_c = ThemeToggle;
var _c;
__turbopack_context__.k.register(_c, "ThemeToggle");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_BASE_URL",
    ()=>API_BASE_URL,
    "AUTH_STATE_EVENT",
    ()=>AUTH_STATE_EVENT,
    "ApiError",
    ()=>ApiError,
    "adminApi",
    ()=>adminApi,
    "aiApi",
    ()=>aiApi,
    "auctionApi",
    ()=>auctionApi,
    "authApi",
    ()=>authApi,
    "autoBidApi",
    ()=>autoBidApi,
    "chatbotApi",
    ()=>chatbotApi,
    "fetchAccountSummary",
    ()=>fetchAccountSummary,
    "fetchLiveAuctions",
    ()=>fetchLiveAuctions,
    "fetchPublicStats",
    ()=>fetchPublicStats,
    "fetchStorefrontCategories",
    ()=>fetchStorefrontCategories,
    "fetchStorefrontLots",
    ()=>fetchStorefrontLots,
    "getOrCreateDeviceId",
    ()=>getOrCreateDeviceId,
    "getToken",
    ()=>getToken,
    "kycApi",
    ()=>kycApi,
    "orderApi",
    ()=>orderApi,
    "premiumApi",
    ()=>premiumApi,
    "productApi",
    ()=>productApi,
    "sellerApi",
    ()=>sellerApi,
    "sellerContractApi",
    ()=>sellerContractApi,
    "setToken",
    ()=>setToken,
    "toFrontendRole",
    ()=>toFrontendRole,
    "toImageSrc",
    ()=>toImageSrc,
    "updateRoleCookie",
    ()=>updateRoleCookie,
    "uploadImages",
    ()=>uploadImages,
    "userApi",
    ()=>userApi,
    "walletApi",
    ()=>walletApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const LOCAL_API_BASE_URL = "http://localhost:8096/api";
const PRODUCTION_API_BASE_URL = "https://api.bidzone.io.vn/api";
const configuredApiBaseUrl = ("TURBOPACK compile-time value", "http://localhost:8096/api")?.trim();
const configuredForLocalhost = configuredApiBaseUrl?.startsWith("http://localhost") || configuredApiBaseUrl?.startsWith("http://127.0.0.1");
const API_BASE_URL = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : configuredApiBaseUrl || LOCAL_API_BASE_URL;
const orderApi = {
    mine: ()=>apiFetch("/orders"),
    one: (id)=>apiFetch(`/orders/${id}`),
    confirmReceived: (id)=>apiFetch(`/orders/${id}/confirm-received`, {
            method: "POST"
        }),
    shippingFee: ()=>apiFetch("/orders/shipping-fee"),
    staffOrders: (status)=>apiFetch(`/staff/orders${status ? `?status=${encodeURIComponent(status)}` : ""}`),
    shippers: ()=>apiFetch("/staff/shippers"),
    assign: (id, shipperId, note)=>apiFetch(`/staff/orders/${id}/assign`, {
            method: "POST",
            body: JSON.stringify({
                shipperId,
                note
            })
        }),
    failedAction: (id, action, shipperId, note)=>apiFetch(`/staff/orders/${id}/failed-action`, {
            method: "POST",
            body: JSON.stringify({
                action,
                shipperId,
                note
            })
        }),
    shipperMine: ()=>apiFetch("/shipper/orders"),
    shipperStatus: (id, status, note)=>apiFetch(`/shipper/orders/${id}/status`, {
            method: "POST",
            body: JSON.stringify({
                status,
                note
            })
        })
};
// ---------------------------------------------------------------------------
// Core fetch helper — tự gắn JWT (lưu ở localStorage sau khi login)
// ---------------------------------------------------------------------------
const TOKEN_KEY = "bidzone_token";
const DEVICE_ID_KEY = "bidzone_device_id";
const AUTH_ROLE_COOKIE = "bidzone_role";
const AUTH_STATE_EVENT = "bidzone-auth-change";
function getToken() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return window.localStorage.getItem(TOKEN_KEY);
}
// ---------------------------------------------------------------------------
// Request de-duplication — several independent components (Header, sidebar,
// dashboard page) fetch the same "current user" data (profile, wallet) on
// every mount with no shared cache, so a single page load fires the same
// request 2-3x. This coalesces same-key calls made within a short window
// into a single in-flight request/result, without changing any call site's
// signature or return type.
// ---------------------------------------------------------------------------
const DEDUP_TTL_MS = 3000;
const clearDedupCaches = [];
function dedupedWithTtl(ttlMs) {
    let cache = null;
    const clear = ()=>{
        cache = null;
    };
    clearDedupCaches.push(clear);
    const run = (loader)=>{
        const now = Date.now();
        if (cache && now - cache.timestamp < ttlMs) {
            return cache.promise;
        }
        const promise = loader();
        cache = {
            promise,
            timestamp: now
        };
        promise.catch(clear);
        return promise;
    };
    return {
        run,
        clear
    };
}
function setToken(token) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    if (token) window.localStorage.setItem(TOKEN_KEY, token);
    else window.localStorage.removeItem(TOKEN_KEY);
    clearDedupCaches.forEach((clear)=>clear());
    window.dispatchEvent(new Event(AUTH_STATE_EVENT));
}
/**
 * Central 401 handling: previously only 2 of ~30+ call sites reacted to a 401 by logging
 * out, so an expired/invalid token surfaced everywhere else as a generic, unexplained error
 * instead of the app recognizing the session had ended. Called from every fetch helper below
 * whenever a request that DID send the stored token comes back 401 — clearing the session so
 * `isLoggedIn` (Header, route guards) reacts immediately, without forcing a redirect from
 * inside a data-fetching utility.
 *
 * Only fires when `sentToken` is truthy: a 401 on a request made without a token (e.g. login
 * with a wrong password, sent with `auth: false`) is a normal business-logic failure, not a
 * session expiry, and must not clear an unrelated already-logged-in session.
 */ function handleUnauthorizedResponse(status, sentToken) {
    if (status === 401 && sentToken) {
        setAuthRoleCookie(null);
        setToken(null);
    }
}
function getOrCreateDeviceId() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let deviceId = window.localStorage.getItem(DEVICE_ID_KEY);
    if (!deviceId) {
        deviceId = window.crypto.randomUUID();
        window.localStorage.setItem(DEVICE_ID_KEY, deviceId);
    }
    return deviceId;
}
function setAuthRoleCookie(role) {
    if (typeof document === "undefined") return;
    const secure = window.location.protocol === "https:" ? "; Secure" : "";
    document.cookie = role ? `${AUTH_ROLE_COOKIE}=${role}; path=/; max-age=604800; SameSite=Lax${secure}` : `${AUTH_ROLE_COOKIE}=; path=/; max-age=0; SameSite=Lax${secure}`;
}
function storeLoginResponse(response) {
    if (!response.token) return;
    setAuthRoleCookie(toFrontendRole(response.roleName));
    setToken(response.token);
}
class ApiError extends Error {
    status;
    constructor(status, message){
        super(message), this.status = status;
    }
}
async function apiFetch(path, options = {}) {
    const { auth = true, headers, ...rest } = options;
    const token = auth ? getToken() : null;
    const deviceId = auth ? getOrCreateDeviceId() : null;
    const res = await fetch(`${API_BASE_URL}${path}`, {
        ...rest,
        headers: {
            ...rest.body && !(rest.body instanceof FormData) ? {
                "Content-Type": "application/json"
            } : {},
            ...token ? {
                Authorization: `Bearer ${token}`
            } : {},
            ...deviceId ? {
                "X-Device-Id": deviceId
            } : {},
            ...headers
        }
    });
    if (!res.ok) {
        let message = `HTTP ${res.status}`;
        try {
            const body = await res.json();
            message = body.message ?? body.detail ?? body.error ?? message;
        } catch  {
        /* body không phải JSON */ }
        handleUnauthorizedResponse(res.status, token);
        throw new ApiError(res.status, message);
    }
    if (res.status === 204) return undefined;
    return await res.json();
}
/**
 * POST multipart/form-data (file uploads). Unlike {@link apiFetch} we must NOT
 * set Content-Type — the browser adds the multipart boundary itself.
 */ async function postMultipart(path, form) {
    const token = getToken();
    const res = await fetch(`${API_BASE_URL}${path}`, {
        method: "POST",
        headers: token ? {
            Authorization: `Bearer ${token}`
        } : {},
        body: form
    });
    if (!res.ok) {
        let message = `HTTP ${res.status}`;
        try {
            const body = await res.json();
            message = body.message ?? body.detail ?? body.error ?? message;
        } catch  {
        /* body không phải JSON */ }
        handleUnauthorizedResponse(res.status, token);
        throw new ApiError(res.status, message);
    }
    if (res.status === 204) return undefined;
    return await res.json();
}
async function uploadImages(files) {
    const form = new FormData();
    for (const file of files)form.append("files", file);
    const body = await postMultipart("/uploads", form);
    return body.data ?? [];
}
function toFrontendRole(roleName) {
    switch((roleName ?? "").toLowerCase()){
        case "admin":
            return "admin";
        case "staff":
            return "staff";
        case "seller":
            return "seller";
        case "shipper":
            return "shipper";
        default:
            return "collector";
    }
}
const authApi = {
    async login (usernameOrEmail, password) {
        const res = await apiFetch("/auth/login", {
            method: "POST",
            body: JSON.stringify({
                usernameOrEmail,
                password
            }),
            auth: false
        });
        storeLoginResponse(res);
        return res;
    },
    register (data) {
        return apiFetch("/auth/register", {
            method: "POST",
            body: JSON.stringify(data),
            auth: false
        });
    },
    sendRegistrationEmailCode (email) {
        return apiFetch("/auth/register/email/send-code", {
            method: "POST",
            body: JSON.stringify({
                email
            }),
            auth: false
        });
    },
    verifyRegistrationEmailCode (email, code) {
        return apiFetch("/auth/register/email/verify-code", {
            method: "POST",
            body: JSON.stringify({
                email,
                code
            }),
            auth: false
        });
    },
    verifyEmail (token) {
        return apiFetch(`/auth/verify-email?token=${encodeURIComponent(token)}`, {
            auth: false
        });
    },
    resendEmailVerification (email) {
        return apiFetch("/auth/email-verification/resend", {
            method: "POST",
            body: JSON.stringify({
                email
            }),
            auth: false
        });
    },
    async googleLogin (credential) {
        const res = await apiFetch("/auth/google", {
            method: "POST",
            body: JSON.stringify({
                credential
            }),
            auth: false
        });
        storeLoginResponse(res);
        return res;
    },
    logout () {
        setAuthRoleCookie(null);
        setToken(null);
    }
};
const productApi = {
    search (params) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(params)){
            if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
        }
        return apiFetch(`/products?${q}`, {
            auth: false
        });
    },
    detail (productId) {
        return apiFetch(`/products/${productId}`, {
            auth: false
        });
    },
    categories () {
        return apiFetch("/categories", {
            auth: false
        });
    },
    categoryAttributes (categoryId) {
        return apiFetch(`/categories/${categoryId}/attributes`, {
            auth: false
        });
    },
    featured () {
        return apiFetch("/featured-products", {
            auth: false
        });
    },
    mine () {
        return apiFetch("/seller/products/mine");
    },
    sellerDetail (productId) {
        return apiFetch(`/seller/products/${productId}`);
    },
    create (payload) {
        return apiFetch("/seller/products", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    update (productId, payload) {
        return apiFetch(`/seller/products/${productId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
        });
    }
};
const aiApi = {
    valuation (payload) {
        return apiFetch("/ai/valuation", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    valuationQuota () {
        return apiFetch("/ai/valuation/quota");
    }
};
const kycApi = {
    ocr (frontImage, backImage) {
        const form = new FormData();
        form.append("frontImage", frontImage);
        form.append("backImage", backImage);
        return postMultipart("/kyc/ocr", form);
    },
    submit (payload) {
        const form = new FormData();
        form.append("fullName", payload.fullName);
        form.append("cccdNumber", payload.cccdNumber);
        form.append("dob", payload.dob);
        form.append("gender", payload.gender);
        form.append("issueDate", payload.issueDate);
        form.append("issuePlace", payload.issuePlace);
        form.append("frontImage", payload.frontImage);
        form.append("backImage", payload.backImage);
        form.append("selfieImage", payload.selfieImage);
        form.append("signSellerAgreement", String(payload.signSellerAgreement ?? false));
        return postMultipart("/kyc", form);
    },
    mine () {
        return apiFetch("/kyc/me");
    },
    /** Fetch a private KYC image (owner or staff only) as a blob for rendering. */ async imageBlob (kycId, which) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/kyc/${kycId}/image/${which}`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    }
};
const sellerContractApi = {
    /** Fetch the seller agreement preview PDF as a blob (needs JWT header). */ async previewPdf () {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/seller-contract/preview-pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    /** Fetch the persisted signed agreement PDF. */ async signedPdf () {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/seller-contract/me/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    /**
   * Sign the seller agreement and upgrade User -> Seller immediately.
   * Requires an APPROVED KYC (identityVerified) — enforced server-side.
   */ submit () {
        return apiFetch("/seller-contract/submit", {
            method: "POST"
        });
    },
    mine () {
        return apiFetch("/seller-contract/me");
    }
};
function updateRoleCookie(roleName) {
    setAuthRoleCookie(toFrontendRole(roleName));
    if ("TURBOPACK compile-time truthy", 1) {
        window.dispatchEvent(new Event(AUTH_STATE_EVENT));
    }
}
const premiumApi = {
    status () {
        return apiFetch("/premium/status");
    },
    purchase (plan) {
        return apiFetch("/premium/purchase", {
            method: "POST",
            body: JSON.stringify({
                plan
            })
        });
    }
};
const autoBidApi = {
    set (auctionId, maxBidAmount) {
        return apiFetch(`/bidding/auto/${auctionId}`, {
            method: "POST",
            body: JSON.stringify({
                maxBidAmount
            })
        });
    },
    cancel (auctionId) {
        return apiFetch(`/bidding/auto/${auctionId}`, {
            method: "DELETE"
        });
    },
    get (auctionId) {
        return apiFetch(`/bidding/auto/${auctionId}`);
    }
};
const auctionApi = {
    state (auctionId) {
        return apiFetch(`/auctions/${auctionId}/state`, {
            auth: false
        });
    },
    bids (auctionId) {
        return apiFetch(`/auctions/${auctionId}/bids`, {
            auth: false
        });
    },
    eligibility (auctionId) {
        return apiFetch(`/auctions/${auctionId}/eligibility`);
    },
    /** Bid cao nhất của CHÍNH người gọi — luôn xem được, kể cả phiên giá kín. */ myBid (auctionId) {
        return apiFetch(`/auctions/${auctionId}/my-bid`);
    },
    placeBid (auctionId, bidAmount) {
        return apiFetch(`/auctions/${auctionId}/bid`, {
            method: "POST",
            body: JSON.stringify({
                bidAmount
            })
        });
    },
    pay (auctionId, address) {
        return apiFetch(`/auctions/${auctionId}/pay`, {
            method: "POST",
            body: JSON.stringify(address)
        });
    },
    purchaseContract (auctionId) {
        return apiFetch(`/auctions/${auctionId}/purchase-contract`);
    },
    signPurchaseContract (auctionId) {
        return apiFetch(`/auctions/${auctionId}/purchase-contract/sign`, {
            method: "POST"
        });
    },
    async purchaseContractPdf (auctionId) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/auctions/${auctionId}/purchase-contract/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    deposit (auctionId) {
        return apiFetch(`/deposits?auctionId=${auctionId}`, {
            method: "POST"
        });
    },
    rooms () {
        return apiFetch("/bidding/rooms");
    },
    chatMessages (auctionId) {
        return apiFetch(`/auctions/${auctionId}/chat/messages`, {
            auth: false
        });
    },
    myBids () {
        return apiFetch("/bids/my-bids");
    },
    wonAuctions () {
        return apiFetch("/bids/won");
    }
};
// ---------------------------------------------------------------------------
// WALLET — /api/wallet*
// ---------------------------------------------------------------------------
const walletGetCache = dedupedWithTtl(DEDUP_TTL_MS);
const walletApi = {
    get () {
        return walletGetCache.run(()=>apiFetch("/wallet"));
    },
    transactions () {
        return apiFetch("/wallet/transactions");
    },
    deposit (amount) {
        return apiFetch("/wallet/deposit", {
            method: "POST",
            body: JSON.stringify({
                amount
            })
        });
    },
    withdraw (data) {
        return apiFetch("/wallet/withdraw", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    withdrawals () {
        return apiFetch("/wallet/withdrawals");
    }
};
const userProfileCache = dedupedWithTtl(DEDUP_TTL_MS);
// CollectorSidebar (unread badge) and the /messages page both call this independently, and
// on the backend it's a genuinely slow query (batched, but still ~1s+ against the remote DB) —
// firing it 2-3x concurrently on one page load compounds into visible connection contention.
const myConversationsCache = dedupedWithTtl(DEDUP_TTL_MS);
const userApi = {
    profile () {
        return userProfileCache.run(()=>apiFetch("/users/me/profile"));
    },
    async updateProfile (fullName) {
        const result = await apiFetch("/users/me/profile", {
            method: "PUT",
            body: JSON.stringify({
                fullName
            })
        });
        userProfileCache.clear();
        return result;
    },
    changePassword (data) {
        return apiFetch("/users/me/change-password", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    notifications () {
        return apiFetch("/notifications");
    },
    unreadCount () {
        return apiFetch("/notifications/unread-count");
    },
    markNotificationRead (id) {
        return apiFetch(`/notifications/${id}/read`, {
            method: "POST"
        });
    },
    watchlist () {
        return apiFetch("/watchlist");
    },
    addToWatchlist (productId) {
        return apiFetch(`/watchlist/${productId}`, {
            method: "POST"
        });
    },
    removeFromWatchlist (productId) {
        return apiFetch(`/watchlist/${productId}`, {
            method: "DELETE"
        });
    },
    myKyc () {
        return apiFetch("/kyc/me");
    },
    submitKyc (formData) {
        return apiFetch("/kyc", {
            method: "POST",
            body: formData
        });
    },
    myConversations () {
        return myConversationsCache.run(()=>apiFetch("/v1/conversations/my"));
    },
    createConversation (data) {
        return apiFetch("/v1/conversations", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    conversationMessages (conversationId) {
        return apiFetch(`/v1/messages/conversation/${conversationId}`);
    },
    async markConversationRead (conversationId) {
        const result = await apiFetch(`/v1/messages/conversation/${conversationId}/read`, {
            method: "PATCH"
        });
        myConversationsCache.clear();
        return result;
    },
    async sendMessage (conversationId, content) {
        const result = await apiFetch("/v1/messages", {
            method: "POST",
            body: JSON.stringify({
                conversationId,
                content
            })
        });
        myConversationsCache.clear();
        return result;
    },
    // --- Staff support inbox ---
    assignedConversations () {
        return apiFetch("/v1/conversations/assigned");
    },
    unassignedConversations () {
        return apiFetch("/v1/conversations/unassigned");
    },
    assignConversation (conversationId) {
        return apiFetch(`/v1/conversations/${conversationId}/assign`, {
            method: "PATCH"
        });
    },
    closeConversation (conversationId) {
        return apiFetch(`/v1/conversations/${conversationId}/close`, {
            method: "PATCH"
        });
    }
};
async function fetchAccountSummary() {
    const [profile, wallet] = await Promise.all([
        userApi.profile(),
        walletApi.get()
    ]);
    return {
        profile: profile.data,
        wallet
    };
}
async function fetchPublicStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/public/stats`, {
            cache: "no-store",
            signal: AbortSignal.timeout(5000)
        });
        if (!response.ok) return [];
        const stats = await response.json();
        return [
            {
                id: "products",
                value: stats.totalProducts.toLocaleString("vi-VN")
            },
            {
                id: "members",
                value: stats.totalUsers.toLocaleString("vi-VN")
            },
            {
                id: "active-auctions",
                value: stats.activeAuctions.toLocaleString("vi-VN")
            },
            {
                id: "completed-auctions",
                value: stats.completedAuctions.toLocaleString("vi-VN")
            }
        ];
    } catch  {
        return [];
    }
}
const adminApi = {
    summary () {
        return apiFetch("/admin/dashboard/summary");
    },
    revenue () {
        return apiFetch("/admin/dashboard/revenue");
    },
    salesHistory () {
        return apiFetch("/admin/dashboard/sales-history");
    },
    auctionSessions (payment = "ALL") {
        return apiFetch(`/admin/dashboard/auction-sessions?payment=${payment}`);
    },
    categories () {
        return apiFetch("/admin/categories");
    },
    createCategory (categoryName, description) {
        return apiFetch("/admin/categories", {
            method: "POST",
            body: JSON.stringify({
                categoryName,
                description,
                isActive: true
            })
        });
    },
    deleteCategory (categoryId) {
        return apiFetch(`/admin/categories/${categoryId}`, {
            method: "DELETE"
        });
    },
    events () {
        return apiFetch("/admin/events");
    },
    createEvent (payload) {
        return apiFetch("/admin/events", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    updateEvent (eventId, payload) {
        return apiFetch(`/admin/events/${eventId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
        });
    },
    deleteEvent (eventId) {
        return apiFetch(`/admin/events/${eventId}`, {
            method: "DELETE"
        });
    },
    eventProducts (eventId) {
        return apiFetch(`/admin/events/${eventId}/products`);
    },
    assignExistingProductToEvent (eventId, productId) {
        return apiFetch(`/admin/events/${eventId}/products/existing/${productId}`, {
            method: "POST"
        });
    },
    approveEventProduct (eventProductId) {
        return apiFetch(`/admin/events/products/${eventProductId}/approve`, {
            method: "POST"
        });
    },
    rejectEventProduct (eventProductId, reason) {
        return apiFetch(`/admin/events/products/${eventProductId}/reject`, {
            method: "POST",
            body: JSON.stringify({
                reason
            })
        });
    },
    removeEventProduct (eventProductId) {
        return apiFetch(`/admin/events/products/${eventProductId}`, {
            method: "DELETE"
        });
    },
    availableProducts () {
        return apiFetch("/admin/events/available-products");
    },
    pendingProducts () {
        return apiFetch("/admin/products/pending");
    },
    approveProduct (productId, payload) {
        return apiFetch(`/admin/products/${productId}/approve`, {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    rejectProduct (productId, reason = "") {
        return apiFetch(`/admin/products/${productId}/reject`, {
            method: "POST",
            body: JSON.stringify({
                reason
            })
        });
    },
    // KYC review — backend returns a raw List (not an ApiEnvelope) for /kyc/list.
    kycList (status = "PENDING") {
        return apiFetch(`/kyc/list?status=${encodeURIComponent(status)}`);
    },
    approveKyc (kycId) {
        return apiFetch(`/kyc/${kycId}/approve`, {
            method: "POST"
        });
    },
    // reason is a @RequestParam on the backend, so it goes in the query string.
    rejectKyc (kycId, reason) {
        return apiFetch(`/kyc/${kycId}/reject?reason=${encodeURIComponent(reason)}`, {
            method: "POST"
        });
    },
    requestInfoKyc (kycId, reason) {
        return apiFetch(`/kyc/${kycId}/request-info?reason=${encodeURIComponent(reason)}`, {
            method: "POST"
        });
    },
    // --- Users & roles (Admin only) ---
    users (q = "") {
        const qs = q ? `?q=${encodeURIComponent(q)}` : "";
        return apiFetch(`/admin/users${qs}`);
    },
    userStats () {
        return apiFetch("/admin/users/stats");
    },
    updateUserRole (userId, roleName) {
        return apiFetch(`/admin/users/${userId}/role`, {
            method: "PATCH",
            body: JSON.stringify({
                roleName
            })
        });
    },
    updateUserStatus (userId, active) {
        return apiFetch(`/admin/users/${userId}/status`, {
            method: "PATCH",
            body: JSON.stringify({
                active
            })
        });
    },
    // --- Withdrawals (Staff/Admin) — backend returns raw lists, no envelope ---
    withdrawals (status = "") {
        const qs = status ? `?status=${encodeURIComponent(status)}` : "";
        return apiFetch(`/staff/withdrawals${qs}`);
    },
    updateWithdrawal (id, status, staffNote = "") {
        return apiFetch(`/staff/withdrawals/${id}/status`, {
            method: "PUT",
            body: JSON.stringify({
                status,
                staffNote
            })
        });
    },
    // --- Contracts & ledger (Admin/Staff dashboard) ---
    contracts (cccd = "") {
        const qs = cccd ? `?cccd=${encodeURIComponent(cccd)}` : "";
        return apiFetch(`/admin/dashboard/contracts${qs}`);
    },
    async contractPdfBlob (contractId) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/admin/dashboard/contracts/${contractId}/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    balanceLedger (params = {}) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(params)){
            if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
        }
        const qs = q.toString() ? `?${q}` : "";
        return apiFetch(`/admin/dashboard/balance-ledger${qs}`);
    },
    fraudSettings () {
        return apiFetch("/admin/settings/fraud-detection");
    },
    updateFraudSettings (payload) {
        return apiFetch("/admin/settings/fraud-detection", {
            method: "PATCH",
            body: JSON.stringify(payload)
        });
    },
    fraudAlerts (params = {}) {
        const q = new URLSearchParams();
        for (const [key, value] of Object.entries(params)){
            if (value !== undefined && value !== null && value !== "") q.set(key, String(value));
        }
        const qs = q.toString() ? `?${q}` : "";
        return apiFetch(`/admin/fraud-alerts${qs}`);
    },
    reviewFraudAlert (id, note = "") {
        return fraudAlertAction(id, "review", note);
    },
    confirmFraudAlert (id, note = "") {
        return fraudAlertAction(id, "confirm", note);
    },
    dismissFraudAlert (id, note = "") {
        return fraudAlertAction(id, "dismiss", note);
    },
    restoreFraudUser (id, note = "") {
        return fraudAlertAction(id, "restore-user", note);
    }
};
const sellerApi = {
    openEvents () {
        return apiFetch("/seller/events");
    },
    submitExistingProductToEvent (eventId, productId) {
        return apiFetch(`/seller/events/${eventId}/products/existing`, {
            method: "POST",
            body: JSON.stringify({
                productId
            })
        });
    },
    mySubmissions (eventId) {
        return apiFetch(`/seller/events/${eventId}/my-submissions`);
    },
    withdrawSubmission (eventProductId) {
        return apiFetch(`/seller/events/products/${eventProductId}`, {
            method: "DELETE"
        });
    }
};
function fraudAlertAction(id, action, note) {
    return apiFetch(`/admin/fraud-alerts/${id}/${action}`, {
        method: "POST",
        body: JSON.stringify({
            note
        })
    });
}
const chatbotApi = {
    reply (message) {
        return apiFetch("/public/chatbot", {
            method: "POST",
            body: JSON.stringify({
                message
            }),
            auth: false
        });
    }
};
// ---------------------------------------------------------------------------
// HOME — dữ liệu trang chủ (server component dùng được, không cần token)
// ---------------------------------------------------------------------------
const VND = new Intl.NumberFormat("vi-VN");
function toImageSrc(imageUrl) {
    if (!imageUrl) return "/images/auction-products/placeholder.png";
    if (imageUrl.startsWith("http")) return imageUrl;
    // Backend trả đường dẫn tương đối (/uploads/...) — đi qua rewrite trong next.config.ts
    return imageUrl.startsWith("/") ? imageUrl : `/${imageUrl}`;
}
function toLiveAuctionItem(p) {
    const price = p.currentBid && p.currentBid > 0 ? p.currentBid : p.startingPrice;
    return {
        id: String(p.auctionId ?? p.productId),
        status: p.auctionStatus?.toUpperCase() === "UPCOMING" ? "UPCOMING" : "ACTIVE",
        title: p.productName,
        subtitle: p.categoryName ?? "",
        currentPrice: `${VND.format(price)} ₫`,
        estimatedPrice: `${VND.format(p.startingPrice)} ₫`,
        bidCount: p.totalBids ?? 0,
        startsAt: p.auctionStartTime ? new Date(p.auctionStartTime).getTime() : Date.now(),
        endsAt: p.auctionEndTime ? new Date(p.auctionEndTime).getTime() : Date.now(),
        imageSrc: toImageSrc(p.imageUrl)
    };
}
async function fetchLiveAuctions(limit = 5) {
    try {
        const loadByStatus = async (auctionStatus)=>{
            const res = await fetch(`${API_BASE_URL}/products?auctionStatus=${auctionStatus}&size=${limit}`, {
                cache: "no-store",
                signal: AbortSignal.timeout(15000)
            });
            if (!res.ok) return [];
            const page = await res.json();
            return page.content ?? [];
        };
        const [active, upcoming] = await Promise.all([
            loadByStatus("ACTIVE"),
            loadByStatus("UPCOMING")
        ]);
        const uniqueAuctions = new Map();
        for (const product of [
            ...active,
            ...upcoming
        ]){
            if (product.auctionId != null && !uniqueAuctions.has(product.auctionId)) {
                uniqueAuctions.set(product.auctionId, product);
            }
        }
        return [
            ...uniqueAuctions.values()
        ].slice(0, limit).map(toLiveAuctionItem);
    } catch  {
        return [];
    }
}
function slugify(name) {
    return name.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
const CATEGORY_ICONS = {
    "luxury-watch": "watch",
    "dong-ho": "watch",
    art: "palette",
    "tranh-nghe-thuat": "palette",
    jewelry: "diamond",
    "trang-suc": "diamond",
    automotive: "directions_car",
    furniture: "chair",
    ceramics: "emoji_food_beverage",
    "do-co": "museum"
};
const CATEGORY_IMAGES = {
    art: "/images/categories/art.jpg",
    "tranh-nghe-thuat": "/images/categories/art.jpg",
    "luxury-watch": "/images/categories/watch.jpg",
    "dong-ho": "/images/categories/watch.jpg",
    jewelry: "/images/categories/jewelry.jpg",
    "trang-suc": "/images/categories/jewelry.jpg",
    automotive: "/images/categories/automotive.jpg",
    furniture: "/images/categories/furniture.jpg",
    ceramics: "/images/categories/ceramics.jpg",
    "do-co": "/images/categories/antiques.jpg",
    khac: "/images/categories/collectibles.jpg"
};
function formatTimeLeft(endTime) {
    if (!endTime) return "—";
    const ms = new Date(endTime).getTime() - Date.now();
    if (ms <= 0) return "00:00:00";
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor(totalSec % 3600 / 60);
    const s = totalSec % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function toStorefrontLot(p) {
    return {
        id: String(p.auctionId),
        lotNumber: `LOT ${String(p.productId).padStart(3, "0")}`,
        title: p.productName,
        categoryId: slugify(p.categoryName ?? "khac"),
        categoryLabel: p.categoryName ?? "",
        currentBid: p.currentBid && p.currentBid > 0 ? p.currentBid : p.startingPrice,
        timeLeft: formatTimeLeft(p.auctionEndTime),
        endsAt: p.auctionEndTime ? new Date(p.auctionEndTime).getTime() : null,
        isLive: p.auctionStatus === "ACTIVE",
        auctionStatus: p.auctionStatus,
        image: toImageSrc(p.imageUrl)
    };
}
async function fetchStorefrontLots(limit = 60) {
    try {
        const res = await fetch(`${API_BASE_URL}/products?size=${limit}`, {
            cache: "no-store",
            signal: AbortSignal.timeout(15000)
        });
        if (!res.ok) return [];
        const page = await res.json();
        return (page.content ?? []).filter((p)=>p.auctionId != null).map(toStorefrontLot);
    } catch  {
        return [];
    }
}
async function fetchStorefrontCategories(lots) {
    try {
        const res = await fetch(`${API_BASE_URL}/categories`, {
            cache: "no-store",
            signal: AbortSignal.timeout(15000)
        });
        if (!res.ok) return [];
        const body = await res.json();
        const allLots = lots ?? await fetchStorefrontLots();
        return (body.data ?? []).filter((c)=>c.isActive).map((c)=>{
            const slug = slugify(c.categoryName);
            const inCategory = allLots.filter((lot)=>lot.categoryId === slug);
            return {
                id: slug,
                label: c.categoryName,
                icon: CATEGORY_ICONS[slug] ?? "category",
                count: String(inCategory.length),
                description: c.description ?? "",
                imageSrc: CATEGORY_IMAGES[slug] ?? "/images/categories/collectibles.jpg"
            };
        });
    } catch  {
        return [];
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/home-data.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "AUCTION_PROCESS_STEPS",
    ()=>AUCTION_PROCESS_STEPS,
    "BRAND_ITEMS",
    ()=>BRAND_ITEMS,
    "DEFAULT_PUBLIC_STATS",
    ()=>DEFAULT_PUBLIC_STATS,
    "NAV_LINKS",
    ()=>NAV_LINKS,
    "WHY_CHOOSE_FEATURES",
    ()=>WHY_CHOOSE_FEATURES
]);
const DEFAULT_PUBLIC_STATS = [
    {
        id: "products",
        value: "500+"
    },
    {
        id: "members",
        value: "2K+"
    },
    {
        id: "active-auctions",
        value: "24/7"
    },
    {
        id: "completed-auctions",
        value: "1K+"
    }
];
const NAV_LINKS = [
    {
        key: "home",
        href: "/"
    },
    {
        key: "products",
        href: "/storefront"
    },
    {
        key: "brands",
        href: "/brands"
    },
    {
        key: "about",
        href: "/about"
    },
    {
        key: "events",
        href: "/events"
    }
];
const WHY_CHOOSE_FEATURES = [
    {
        id: "verified-sellers",
        icon: "verified_user"
    },
    {
        id: "transparent",
        icon: "workspace_premium"
    },
    {
        id: "secure-payment",
        icon: "encrypted"
    },
    {
        id: "support",
        icon: "diamond"
    }
];
const AUCTION_PROCESS_STEPS = [
    {
        id: "verify",
        icon: "person_check"
    },
    {
        id: "deposit",
        icon: "inventory_2"
    },
    {
        id: "bid",
        icon: "computer"
    },
    {
        id: "payment",
        icon: "local_shipping"
    }
];
const BRAND_ITEMS = [
    {
        id: "rolex",
        name: "ROLEX",
        mark: "ROLEX"
    },
    {
        id: "apple",
        name: "APPLE",
        mark: "APPLE"
    },
    {
        id: "patek",
        name: "PATEK PHILIPPE",
        mark: "PATEK"
    },
    {
        id: "louis-vuitton",
        name: "LOUIS VUITTON",
        mark: "LV"
    },
    {
        id: "leica",
        name: "LEICA",
        mark: "LEICA"
    },
    {
        id: "sony",
        name: "SONY",
        mark: "SONY"
    },
    {
        id: "dji",
        name: "DJI",
        mark: "DJI"
    },
    {
        id: "bose",
        name: "BOSE",
        mark: "BOSE"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/use-api-data.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useApiData",
    ()=>useApiData
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function useApiData(load, initialValue) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialValue);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const reload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useApiData.useCallback[reload]": async ()=>{
            setLoading(true);
            setError(null);
            try {
                setData(await load());
            } catch (cause) {
                setError(cause instanceof Error ? cause.message : t("error"));
            } finally{
                setLoading(false);
            }
        }
    }["useApiData.useCallback[reload]"], [
        load,
        t
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useApiData.useEffect": ()=>{
            const timeout = window.setTimeout({
                "useApiData.useEffect.timeout": ()=>void reload()
            }["useApiData.useEffect.timeout"], 0);
            return ({
                "useApiData.useEffect": ()=>window.clearTimeout(timeout)
            })["useApiData.useEffect"];
        }
    }["useApiData.useEffect"], [
        reload
    ]);
    return {
        data,
        setData,
        loading,
        error,
        reload
    };
}
_s(useApiData, "9T5RUiTPUiRS728/pjx8MD8vS08=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/home/Header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$i18n$2f$LanguageSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/i18n/LanguageSwitcher.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$theme$2f$ThemeToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/theme/ThemeToggle.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$home$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/home-data.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/use-api-data.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
const ROLE_HOME = {
    collector: "/dashboard",
    seller: "/inventory",
    staff: "/staff/approvals",
    admin: "/admin/dashboard",
    shipper: "/shipper/orders"
};
function subscribeToAuthState(onStoreChange) {
    window.addEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_STATE_EVENT"], onStoreChange);
    window.addEventListener("storage", onStoreChange);
    return ()=>{
        window.removeEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_STATE_EVENT"], onStoreChange);
        window.removeEventListener("storage", onStoreChange);
    };
}
function hasStoredToken() {
    return Boolean((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getToken"])());
}
function Header() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("header");
    const tNav = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("nav");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const accountMenuRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [accountMenuOpen, setAccountMenuOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const isLoggedIn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeToAuthState, hasStoredToken, {
        "Header.useSyncExternalStore[isLoggedIn]": ()=>false
    }["Header.useSyncExternalStore[isLoggedIn]"]);
    const loadProfile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "Header.useCallback[loadProfile]": async ()=>{
            if (!isLoggedIn) return null;
            try {
                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["userApi"].profile();
                return response.data;
            } catch (error) {
                if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"] && error.status === 401) {
                    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authApi"].logout();
                    return null;
                }
                throw error;
            }
        }
    }["Header.useCallback[loadProfile]"], [
        isLoggedIn
    ]);
    const { data: profile } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApiData"])(loadProfile, null);
    const role = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["toFrontendRole"])(profile?.roleName ?? null);
    const accountName = profile?.fullName || t("roles.collector");
    const initials = accountName.split(/\s+/).filter(Boolean).slice(-2).map((part)=>part[0]).join("").toUpperCase();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Header.useEffect": ()=>{
            if (!accountMenuOpen) return;
            function handlePointerDown(event) {
                if (!accountMenuRef.current?.contains(event.target)) {
                    setAccountMenuOpen(false);
                }
            }
            function handleKeyDown(event) {
                if (event.key === "Escape") setAccountMenuOpen(false);
            }
            document.addEventListener("pointerdown", handlePointerDown);
            document.addEventListener("keydown", handleKeyDown);
            return ({
                "Header.useEffect": ()=>{
                    document.removeEventListener("pointerdown", handlePointerDown);
                    document.removeEventListener("keydown", handleKeyDown);
                }
            })["Header.useEffect"];
        }
    }["Header.useEffect"], [
        accountMenuOpen
    ]);
    function handleLogout() {
        setAccountMenuOpen(false);
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authApi"].logout();
        router.replace("/");
        router.refresh();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "site-header sticky top-0 z-50 border-b border-white/10 bg-black/85 backdrop-blur-md",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex min-h-16 w-full items-center justify-between gap-3 px-4 py-3 sm:min-h-20 sm:px-6 lg:px-12",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: "/",
                    className: "flex shrink-0 items-center",
                    "aria-label": "BidZone",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        priority: true,
                        className: "h-10 w-auto sm:h-14"
                    }, void 0, false, {
                        fileName: "[project]/components/home/Header.tsx",
                        lineNumber: 122,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/home/Header.tsx",
                    lineNumber: 117,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: "hidden flex-1 items-center justify-center gap-14 text-xs font-medium tracking-widest text-white/80 lg:flex",
                    children: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$home$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NAV_LINKS"].map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: link.href,
                            className: "transition-colors hover:text-[#f0c982]",
                            children: tNav(link.key)
                        }, link.key, false, {
                            fileName: "[project]/components/home/Header.tsx",
                            lineNumber: 127,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/home/Header.tsx",
                    lineNumber: 125,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex min-w-0 shrink-0 items-center gap-1.5 sm:gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$i18n$2f$LanguageSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            compactOnMobile: true
                        }, void 0, false, {
                            fileName: "[project]/components/home/Header.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$theme$2f$ThemeToggle$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/components/home/Header.tsx",
                            lineNumber: 139,
                            columnNumber: 11
                        }, this),
                        isLoggedIn ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            ref: accountMenuRef,
                            className: "relative",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>setAccountMenuOpen((current)=>!current),
                                    "aria-expanded": accountMenuOpen,
                                    "aria-haspopup": "menu",
                                    "aria-label": t("openAccountMenu"),
                                    className: "flex h-11 min-w-11 items-center gap-2 rounded-lg border border-transparent px-1.5 text-left transition-colors hover:border-white/10 hover:bg-white/5 sm:min-w-44 sm:px-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-[#d7aa63]/70 bg-[#d7aa63]/10 text-[11px] font-bold text-[#f0c982]",
                                            children: initials || "?"
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/Header.tsx",
                                            lineNumber: 150,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "hidden min-w-0 flex-1 sm:block",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "block truncate text-xs font-semibold text-white",
                                                    children: accountName
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/Header.tsx",
                                                    lineNumber: 154,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "mt-0.5 block text-[10px] text-white/45",
                                                    children: t(`roles.${role}`)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/Header.tsx",
                                                    lineNumber: 157,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/Header.tsx",
                                            lineNumber: 153,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiChevronDown"], {
                                            "aria-hidden": "true",
                                            className: `hidden h-4 w-4 text-white/40 transition-transform sm:block ${accountMenuOpen ? "rotate-180" : ""}`
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/Header.tsx",
                                            lineNumber: 161,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/Header.tsx",
                                    lineNumber: 142,
                                    columnNumber: 15
                                }, this),
                                accountMenuOpen ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    role: "menu",
                                    className: "absolute right-0 top-[calc(100%+0.5rem)] w-60 overflow-hidden rounded-lg border border-white/10 bg-[#111] py-1.5 shadow-[0_18px_50px_rgba(0,0,0,0.55)]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "border-b border-white/10 px-4 py-3 sm:hidden",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "truncate text-sm font-semibold",
                                                    children: accountName
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/Header.tsx",
                                                    lineNumber: 175,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "mt-0.5 text-xs text-white/45",
                                                    children: t(`roles.${role}`)
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/Header.tsx",
                                                    lineNumber: 176,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/Header.tsx",
                                            lineNumber: 174,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: ROLE_HOME[role],
                                            role: "menuitem",
                                            onClick: ()=>setAccountMenuOpen(false),
                                            className: "flex items-center gap-3 px-4 py-2.5 text-sm text-white/75 transition-colors hover:bg-white/5 hover:text-white",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiGrid"], {
                                                    className: "h-5 w-5 text-[#f0c982]",
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/Header.tsx",
                                                    lineNumber: 186,
                                                    columnNumber: 21
                                                }, this),
                                                t("dashboard")
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/Header.tsx",
                                            lineNumber: 180,
                                            columnNumber: 19
                                        }, this),
                                        role === "collector" || role === "seller" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/profile",
                                            role: "menuitem",
                                            onClick: ()=>setAccountMenuOpen(false),
                                            className: "flex items-center gap-3 px-4 py-2.5 text-sm text-white/75 transition-colors hover:bg-white/5 hover:text-white",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiUser"], {
                                                    className: "h-5 w-5 text-white/45",
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/Header.tsx",
                                                    lineNumber: 196,
                                                    columnNumber: 23
                                                }, this),
                                                t("profile")
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/Header.tsx",
                                            lineNumber: 190,
                                            columnNumber: 21
                                        }, this) : null,
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "my-1 border-t border-white/10"
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/Header.tsx",
                                            lineNumber: 200,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            role: "menuitem",
                                            onClick: handleLogout,
                                            className: "flex w-full items-center gap-3 px-4 py-2.5 text-left text-sm text-red-300 transition-colors hover:bg-red-500/10",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiLogOut"], {
                                                    className: "h-5 w-5",
                                                    "aria-hidden": "true"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/Header.tsx",
                                                    lineNumber: 207,
                                                    columnNumber: 21
                                                }, this),
                                                t("logout")
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/Header.tsx",
                                            lineNumber: 201,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/Header.tsx",
                                    lineNumber: 170,
                                    columnNumber: 17
                                }, this) : null
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/Header.tsx",
                            lineNumber: 141,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/auth",
                                    className: "hidden rounded-full border border-[#d7aa63]/50 px-4 py-2.5 text-xs font-semibold tracking-wider text-white transition-colors hover:bg-white/10 md:inline-block",
                                    children: t("login")
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Header.tsx",
                                    lineNumber: 215,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/auth",
                                    className: "rounded-full bg-[#f0c982] px-3 py-2.5 text-[11px] font-semibold tracking-wider text-black transition-colors hover:bg-[#f4d79b] sm:px-5 sm:text-xs",
                                    children: t("register")
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Header.tsx",
                                    lineNumber: 221,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/home/Header.tsx",
                    lineNumber: 137,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/home/Header.tsx",
            lineNumber: 116,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/home/Header.tsx",
        lineNumber: 115,
        columnNumber: 5
    }, this);
}
_s(Header, "jdbGeC+ZHo4NEUFW3cZ94S1lu7E=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$use$2d$api$2d$data$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useApiData"]
    ];
});
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/home/Countdown.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Countdown
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function splitRemaining(ms) {
    const total = Math.max(0, Math.floor(ms / 1000));
    const hours = Math.floor(total / 3600);
    const minutes = Math.floor(total % 3600 / 60);
    const seconds = total % 60;
    return {
        hours,
        minutes,
        seconds
    };
}
function pad(value) {
    return value === null ? "--" : value.toString().padStart(2, "0");
}
function Countdown({ endsAt, prefix, className = "flex items-center gap-1 font-mono text-sm font-semibold text-white", expiredLabel }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("common");
    const expiredLabelLocal = expiredLabel ?? t("expired");
    const [remaining, setRemaining] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Countdown.useEffect": ()=>{
            const timeout = setTimeout({
                "Countdown.useEffect.timeout": ()=>{
                    setRemaining(endsAt - Date.now());
                }
            }["Countdown.useEffect.timeout"], 0);
            const interval = setInterval({
                "Countdown.useEffect.interval": ()=>{
                    setRemaining(endsAt - Date.now());
                }
            }["Countdown.useEffect.interval"], 1000);
            return ({
                "Countdown.useEffect": ()=>{
                    clearTimeout(timeout);
                    clearInterval(interval);
                }
            })["Countdown.useEffect"];
        }
    }["Countdown.useEffect"], [
        endsAt
    ]);
    const { hours, minutes, seconds } = remaining === null ? {
        hours: null,
        minutes: null,
        seconds: null
    } : splitRemaining(remaining);
    if (remaining !== null && remaining <= 0) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
            className: className,
            children: expiredLabelLocal
        }, void 0, false, {
            fileName: "[project]/components/home/Countdown.tsx",
            lineNumber: 54,
            columnNumber: 12
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: className,
        children: [
            prefix ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: prefix
            }, void 0, false, {
                fileName: "[project]/components/home/Countdown.tsx",
                lineNumber: 59,
                columnNumber: 17
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: pad(hours)
            }, void 0, false, {
                fileName: "[project]/components/home/Countdown.tsx",
                lineNumber: 60,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-white/30",
                children: ":"
            }, void 0, false, {
                fileName: "[project]/components/home/Countdown.tsx",
                lineNumber: 61,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: pad(minutes)
            }, void 0, false, {
                fileName: "[project]/components/home/Countdown.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-white/30",
                children: ":"
            }, void 0, false, {
                fileName: "[project]/components/home/Countdown.tsx",
                lineNumber: 63,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: pad(seconds)
            }, void 0, false, {
                fileName: "[project]/components/home/Countdown.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/home/Countdown.tsx",
        lineNumber: 58,
        columnNumber: 5
    }, this);
}
_s(Countdown, "WsWujtzhXAaiKyVKyEzthB9Kk0A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = Countdown;
var _c;
__turbopack_context__.k.register(_c, "Countdown");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/home/LiveAuctionGrid.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LiveAuctionGrid
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$home$2f$Countdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/home/Countdown.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function LiveAuctionGrid({ items }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("liveGrid");
    const [selectedItem, setSelectedItem] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "LiveAuctionGrid.useEffect": ()=>{
            if (!selectedItem) return;
            const handleKeyDown = {
                "LiveAuctionGrid.useEffect.handleKeyDown": (e)=>{
                    if (e.key === "Escape") setSelectedItem(null);
                }
            }["LiveAuctionGrid.useEffect.handleKeyDown"];
            document.body.style.overflow = "hidden";
            window.addEventListener("keydown", handleKeyDown);
            return ({
                "LiveAuctionGrid.useEffect": ()=>{
                    document.body.style.overflow = "";
                    window.removeEventListener("keydown", handleKeyDown);
                }
            })["LiveAuctionGrid.useEffect"];
        }
    }["LiveAuctionGrid.useEffect"], [
        selectedItem
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid grid-cols-1 gap-5 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-5",
                children: items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                        className: "group flex flex-col overflow-hidden rounded-lg border border-[#d7aa63]/35 bg-[#080808] transition-colors hover:border-[#f0c982]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setSelectedItem(item),
                                className: "theme-dark-content relative aspect-[4/3] w-full overflow-hidden bg-black text-left sm:aspect-square",
                                "aria-label": `${t("zoomIn")} ${item.title}`,
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: item.imageSrc,
                                        alt: item.title,
                                        fill: true,
                                        sizes: "(min-width: 1280px) 20vw, (min-width: 768px) 33vw, (min-width: 640px) 50vw, 100vw",
                                        className: "object-contain transition-transform duration-500 group-hover:scale-105"
                                    }, void 0, false, {
                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                        lineNumber: 40,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black to-transparent"
                                    }, void 0, false, {
                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                        lineNumber: 47,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: `absolute left-3 top-3 flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-semibold tracking-wider text-white ${item.status === "ACTIVE" ? "bg-red-500" : "bg-amber-500"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "h-1.5 w-1.5 rounded-full bg-white"
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 53,
                                                columnNumber: 17
                                            }, this),
                                            item.status === "ACTIVE" ? "LIVE" : t("upcomingBadge")
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                        lineNumber: 48,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full border border-white/25 bg-black/45 text-white backdrop-blur",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "material-symbols-outlined text-lg",
                                            children: "favorite"
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                            lineNumber: 57,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                        lineNumber: 56,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                lineNumber: 34,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-1 flex-col gap-3 p-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onClick: ()=>setSelectedItem(item),
                                        className: "text-left",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "text-sm font-semibold text-white",
                                                children: item.title
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 63,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-0.5 text-xs text-white/55",
                                                children: item.subtitle
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 64,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                        lineNumber: 62,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[10px] tracking-wider text-white/45",
                                                children: t("currentPrice")
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 68,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-xl font-bold text-white",
                                                children: item.currentPrice
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 69,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-[11px] text-white/45",
                                                children: t("startingPrice", {
                                                    price: item.estimatedPrice
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 70,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                        lineNumber: 67,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mt-auto grid grid-cols-2 gap-3 border-t border-white/12 pt-3 text-xs",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$home$2f$Countdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        endsAt: item.status === "ACTIVE" ? item.endsAt : item.startsAt
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                        lineNumber: 77,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 text-white/45",
                                                        children: item.status === "ACTIVE" ? t("ends") : t("starts")
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                        lineNumber: 80,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 76,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "font-semibold text-white",
                                                        children: item.bidCount
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                        lineNumber: 85,
                                                        columnNumber: 19
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        className: "mt-1 text-white/45",
                                                        children: t("bids")
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                        lineNumber: 86,
                                                        columnNumber: 19
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 84,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                        lineNumber: 75,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        href: `/auctions/${item.id}`,
                                        className: "mt-1 inline-flex min-h-11 items-center justify-center gap-2 rounded-full border border-[#d7aa63]/50 px-4 py-2.5 text-xs font-semibold tracking-wider text-white transition-colors hover:bg-[#f0c982] hover:text-black",
                                        children: [
                                            item.status === "ACTIVE" ? t("bidNow") : t("viewAuction"),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "material-symbols-outlined text-sm",
                                                children: "arrow_forward"
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                                lineNumber: 95,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                        lineNumber: 90,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                lineNumber: 61,
                                columnNumber: 13
                            }, this)
                        ]
                    }, item.id, true, {
                        fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                        lineNumber: 30,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            selectedItem && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-50 flex items-center justify-center bg-black/85 px-4 py-6 backdrop-blur-sm",
                role: "dialog",
                "aria-modal": "true",
                "aria-label": `${t("zoomIn")} ${selectedItem.title}`,
                onClick: ()=>setSelectedItem(null),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "theme-dark-content theme-dark-surface relative flex w-full max-w-4xl flex-col overflow-hidden rounded-2xl border border-[#d7aa63]/45 bg-[#050505] shadow-[0_30px_120px_rgba(240,201,130,0.2)]",
                    onClick: (event)=>event.stopPropagation(),
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>setSelectedItem(null),
                            className: "absolute right-4 top-4 z-10 flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-black/60 text-white backdrop-blur transition-colors hover:border-[#f0c982] hover:text-[#f0c982]",
                            "aria-label": t("closeZoom"),
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "material-symbols-outlined text-xl",
                                children: "close"
                            }, void 0, false, {
                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                lineNumber: 120,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                            lineNumber: 114,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "relative min-h-[56vh] bg-black sm:min-h-[68vh]",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: selectedItem.imageSrc,
                                alt: selectedItem.title,
                                fill: true,
                                priority: true,
                                sizes: "(min-width: 1024px) 900px, 100vw",
                                className: "object-contain p-6 sm:p-10"
                            }, void 0, false, {
                                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                lineNumber: 124,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                            lineNumber: 123,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-col gap-4 border-t border-white/10 p-5 sm:flex-row sm:items-center sm:justify-between",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs uppercase tracking-[0.28em] text-[#f0c982]",
                                            children: t("selectedItem")
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                            lineNumber: 136,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "mt-2 text-xl font-bold text-white",
                                            children: selectedItem.title
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                            lineNumber: 139,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "mt-1 text-sm text-white/55",
                                            children: selectedItem.subtitle
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                            lineNumber: 140,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                    lineNumber: 135,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: `/auctions/${selectedItem.id}`,
                                    className: "inline-flex w-fit items-center justify-center gap-2 rounded-full bg-[#f0c982] px-6 py-3 text-xs font-bold tracking-wider text-black transition-colors hover:bg-[#f4d79b]",
                                    children: [
                                        t("bidNow"),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "material-symbols-outlined text-sm",
                                            children: "arrow_forward"
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                            lineNumber: 147,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                                    lineNumber: 142,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                            lineNumber: 134,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                    lineNumber: 110,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/home/LiveAuctionGrid.tsx",
                lineNumber: 103,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(LiveAuctionGrid, "+3u5eDh019GIai2GLn+iDhN8E+I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = LiveAuctionGrid;
var _c;
__turbopack_context__.k.register(_c, "LiveAuctionGrid");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/home/PublicProductSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PublicProductSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$home$2f$Countdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/home/Countdown.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const VND = new Intl.NumberFormat("vi-VN");
function PublicProductSection({ lots, categories }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("storefront");
    const [selectedCategoryId, setSelectedCategoryId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const visibleLots = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PublicProductSection.useMemo[visibleLots]": ()=>{
            if (!selectedCategoryId) {
                return lots.slice(0, 4);
            }
            return lots.filter({
                "PublicProductSection.useMemo[visibleLots]": (lot)=>lot.categoryId === selectedCategoryId
            }["PublicProductSection.useMemo[visibleLots]"]);
        }
    }["PublicProductSection.useMemo[visibleLots]"], [
        lots,
        selectedCategoryId
    ]);
    const usedCategories = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PublicProductSection.useMemo[usedCategories]": ()=>categories.filter({
                "PublicProductSection.useMemo[usedCategories]": (category)=>Number(category.count) > 0
            }["PublicProductSection.useMemo[usedCategories]"])
    }["PublicProductSection.useMemo[usedCategories]"], [
        categories
    ]);
    if (lots.length === 0) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "border-b border-white/10 bg-[#050505]",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-[1600px] px-4 py-10 sm:px-6 sm:py-14 lg:px-12",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6 flex flex-col justify-between gap-4 sm:mb-8 md:flex-row md:items-end",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs font-semibold uppercase tracking-[0.24em] text-[#f0c982]",
                                    children: t("featuredLabel")
                                }, void 0, false, {
                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                    lineNumber: 46,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "mt-3 text-2xl font-semibold text-white sm:text-3xl",
                                    children: t("subtitle")
                                }, void 0, false, {
                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/PublicProductSection.tsx",
                            lineNumber: 45,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/storefront",
                            className: "inline-flex w-fit items-center gap-2 rounded-full border border-[#d7aa63]/50 px-5 py-3 text-xs font-semibold tracking-wider text-white transition-colors hover:bg-[#f0c982] hover:text-black",
                            children: [
                                t("viewAll"),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "material-symbols-outlined text-sm",
                                    children: "arrow_forward"
                                }, void 0, false, {
                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                    lineNumber: 58,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/PublicProductSection.tsx",
                            lineNumber: 53,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/home/PublicProductSection.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mb-6 flex gap-2 overflow-x-auto pb-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>setSelectedCategoryId(null),
                            className: `shrink-0 rounded-full px-4 py-2 text-xs font-semibold transition-colors ${selectedCategoryId ? "border border-white/15 text-white/70 hover:border-[#d7aa63] hover:text-white" : "bg-[var(--luxora-gold)] text-black"}`,
                            children: t("all")
                        }, void 0, false, {
                            fileName: "[project]/components/home/PublicProductSection.tsx",
                            lineNumber: 65,
                            columnNumber: 11
                        }, this),
                        usedCategories.map((category)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setSelectedCategoryId(category.id),
                                className: `shrink-0 rounded-full px-4 py-2 text-xs font-medium transition-colors ${selectedCategoryId === category.id ? "bg-[var(--luxora-gold)] text-black" : "border border-white/15 text-white/70 hover:border-[#d7aa63] hover:text-white"}`,
                                children: category.label
                            }, category.id, false, {
                                fileName: "[project]/components/home/PublicProductSection.tsx",
                                lineNumber: 77,
                                columnNumber: 13
                            }, this))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/home/PublicProductSection.tsx",
                    lineNumber: 64,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4",
                    children: visibleLots.map((lot)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                            className: "group flex flex-col overflow-hidden rounded-lg border border-[#d7aa63]/25 bg-[#080808] transition-colors hover:border-[#f0c982]",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "theme-dark-content relative aspect-square w-full overflow-hidden bg-black",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: `/auctions/${lot.id}`,
                                            "aria-label": `${t("viewDetail")} ${lot.title}`,
                                            className: "absolute inset-0",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                "aria-hidden": "true",
                                                className: "absolute inset-0 bg-cover bg-center transition-transform duration-500 group-hover:scale-105",
                                                style: {
                                                    backgroundImage: `url(${lot.image})`
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/PublicProductSection.tsx",
                                                lineNumber: 104,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/PublicProductSection.tsx",
                                            lineNumber: 99,
                                            columnNumber: 17
                                        }, this),
                                        lot.isLive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "pointer-events-none absolute left-3 top-3 flex items-center gap-1.5 rounded-full bg-red-500 px-2.5 py-1 text-[10px] font-semibold tracking-wider text-white",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "h-1.5 w-1.5 rounded-full bg-white"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                                    lineNumber: 112,
                                                    columnNumber: 21
                                                }, this),
                                                "LIVE"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/PublicProductSection.tsx",
                                            lineNumber: 111,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            type: "button",
                                            onClick: ()=>setSelectedCategoryId(lot.categoryId),
                                            className: "absolute right-3 top-3 z-10 rounded-full border border-white/15 bg-black/70 px-2.5 py-1 text-[10px] font-semibold tracking-wider text-white/80 transition-colors hover:border-[#f0c982] hover:text-[#f0c982]",
                                            children: lot.categoryLabel || t("otherCategory")
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/PublicProductSection.tsx",
                                            lineNumber: 116,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                    lineNumber: 98,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: `/auctions/${lot.id}`,
                                    className: "flex flex-1 flex-col gap-3 p-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] tracking-wider text-[#f0c982]",
                                                    children: lot.lotNumber
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                                    lineNumber: 129,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "mt-1 line-clamp-2 min-h-10 text-sm font-semibold text-white",
                                                    children: lot.title
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                                    lineNumber: 132,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/PublicProductSection.tsx",
                                            lineNumber: 128,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-auto border-t border-white/10 pt-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-[10px] tracking-wider text-white/45",
                                                    children: t("priceLabel")
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                                    lineNumber: 137,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xl font-bold text-white",
                                                    children: [
                                                        VND.format(lot.currentBid),
                                                        " ₫"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                                    lineNumber: 140,
                                                    columnNumber: 19
                                                }, this),
                                                lot.endsAt ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$home$2f$Countdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                    endsAt: lot.endsAt,
                                                    prefix: t("remainingPrefix"),
                                                    className: "mt-1 inline-flex items-center gap-1 font-mono text-xs text-white/45"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                                    lineNumber: 144,
                                                    columnNumber: 21
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "mt-1 text-xs text-white/45",
                                                    children: t("noEndSchedule")
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                                    lineNumber: 150,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/PublicProductSection.tsx",
                                            lineNumber: 136,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/PublicProductSection.tsx",
                                    lineNumber: 124,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, lot.id, true, {
                            fileName: "[project]/components/home/PublicProductSection.tsx",
                            lineNumber: 94,
                            columnNumber: 13
                        }, this))
                }, void 0, false, {
                    fileName: "[project]/components/home/PublicProductSection.tsx",
                    lineNumber: 92,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/home/PublicProductSection.tsx",
            lineNumber: 43,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/home/PublicProductSection.tsx",
        lineNumber: 42,
        columnNumber: 5
    }, this);
}
_s(PublicProductSection, "psCGgXMrfBcXNFOsQoADgmrEN8M=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = PublicProductSection;
var _c;
__turbopack_context__.k.register(_c, "PublicProductSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/home/HomeDynamicSections.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomeDynamicSections
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$home$2f$LiveAuctionGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/home/LiveAuctionGrid.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$home$2f$PublicProductSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/home/PublicProductSection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function HomeDynamicSections() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("home");
    const [liveItems, setLiveItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [lots, setLots] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [categories, setCategories] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "HomeDynamicSections.useEffect": ()=>{
            let active = true;
            async function loadInitialData() {
                const [nextLiveItems, nextLots] = await Promise.all([
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchLiveAuctions"])(5),
                    (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchStorefrontLots"])()
                ]);
                const nextCategories = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchStorefrontCategories"])(nextLots);
                if (!active) return;
                setLiveItems(nextLiveItems);
                setLots(nextLots);
                setCategories(nextCategories);
                setLoaded(true);
            }
            async function refreshLiveAuctions() {
                const nextLiveItems = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fetchLiveAuctions"])(5);
                if (active) setLiveItems(nextLiveItems);
            }
            void loadInitialData().catch({
                "HomeDynamicSections.useEffect": ()=>{
                    if (active) setLoaded(true);
                }
            }["HomeDynamicSections.useEffect"]);
            // A scheduled LIVE room can become active while the visitor is already on
            // the homepage, so keep this section synchronized without a manual reload.
            const liveRefreshInterval = window.setInterval({
                "HomeDynamicSections.useEffect.liveRefreshInterval": ()=>void refreshLiveAuctions()
            }["HomeDynamicSections.useEffect.liveRefreshInterval"], 10_000);
            return ({
                "HomeDynamicSections.useEffect": ()=>{
                    active = false;
                    window.clearInterval(liveRefreshInterval);
                }
            })["HomeDynamicSections.useEffect"];
        }
    }["HomeDynamicSections.useEffect"], []);
    if (!loaded) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "border-b border-white/10",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "mx-auto max-w-[1600px] px-4 py-10 sm:px-6 sm:py-14 lg:px-12",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-6 flex items-center justify-between gap-4 sm:mb-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "flex min-w-0 items-center gap-3 text-xs font-semibold tracking-[0.18em] text-white sm:text-sm sm:tracking-[0.25em]",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "h-2 w-2 shrink-0 rounded-full bg-red-500"
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/HomeDynamicSections.tsx",
                                            lineNumber: 71,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "truncate",
                                            children: t("liveSection")
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/HomeDynamicSections.tsx",
                                            lineNumber: 72,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/HomeDynamicSections.tsx",
                                    lineNumber: 70,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/auctions",
                                    className: "flex shrink-0 items-center gap-2 text-[11px] font-medium tracking-wider text-white/60 transition-colors hover:text-white sm:text-xs",
                                    children: [
                                        t("seeAll"),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "material-symbols-outlined text-sm",
                                            children: "arrow_forward"
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/HomeDynamicSections.tsx",
                                            lineNumber: 79,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/HomeDynamicSections.tsx",
                                    lineNumber: 74,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/HomeDynamicSections.tsx",
                            lineNumber: 69,
                            columnNumber: 11
                        }, this),
                        liveItems.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$home$2f$LiveAuctionGrid$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            items: liveItems
                        }, void 0, false, {
                            fileName: "[project]/components/home/HomeDynamicSections.tsx",
                            lineNumber: 86,
                            columnNumber: 13
                        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "rounded-lg border border-white/10 bg-white/[0.02] px-6 py-10 text-center text-sm text-white/50",
                            children: t("noLiveAuctions")
                        }, void 0, false, {
                            fileName: "[project]/components/home/HomeDynamicSections.tsx",
                            lineNumber: 88,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/home/HomeDynamicSections.tsx",
                    lineNumber: 68,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/home/HomeDynamicSections.tsx",
                lineNumber: 67,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$home$2f$PublicProductSection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                lots: lots,
                categories: categories
            }, void 0, false, {
                fileName: "[project]/components/home/HomeDynamicSections.tsx",
                lineNumber: 94,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(HomeDynamicSections, "C7aEn4jbPY2q43t0AclAIsCal98=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = HomeDynamicSections;
var _c;
__turbopack_context__.k.register(_c, "HomeDynamicSections");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/home/HomeCtaSection.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HomeCtaSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function subscribeToAuthState(onStoreChange) {
    window.addEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_STATE_EVENT"], onStoreChange);
    window.addEventListener("storage", onStoreChange);
    return ()=>{
        window.removeEventListener(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_STATE_EVENT"], onStoreChange);
        window.removeEventListener("storage", onStoreChange);
    };
}
function hasStoredToken() {
    return Boolean((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getToken"])());
}
function HomeCtaSection() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("cta");
    const isLoggedIn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"])(subscribeToAuthState, hasStoredToken, {
        "HomeCtaSection.useSyncExternalStore[isLoggedIn]": ()=>false
    }["HomeCtaSection.useSyncExternalStore[isLoggedIn]"]);
    const features = [
        t("feature1"),
        t("feature2"),
        t("feature3")
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "border-b border-white/10",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-[1600px] px-4 py-10 sm:px-6 sm:py-14 lg:px-12",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "theme-dark-content relative overflow-hidden rounded-lg border border-[#d7aa63]/45 bg-black",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: "/images/luxury-watch-hero.webp",
                        alt: t("imageAlt"),
                        fill: true,
                        sizes: "100vw",
                        className: "object-cover object-[72%_center]"
                    }, void 0, false, {
                        fileName: "[project]/components/home/HomeCtaSection.tsx",
                        lineNumber: 36,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-gradient-to-r from-black via-black/88 to-black/30"
                    }, void 0, false, {
                        fileName: "[project]/components/home/HomeCtaSection.tsx",
                        lineNumber: 43,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-y-0 right-0 hidden w-1/2 bg-gradient-to-l from-black/10 to-transparent lg:block"
                    }, void 0, false, {
                        fileName: "[project]/components/home/HomeCtaSection.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative min-h-64 px-4 py-7 sm:px-7 sm:py-8 lg:px-12",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex max-w-[680px] flex-col justify-center",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mb-3 text-[11px] font-semibold uppercase tracking-[0.32em] text-[#f0c982]",
                                    children: t("badge")
                                }, void 0, false, {
                                    fileName: "[project]/components/home/HomeCtaSection.tsx",
                                    lineNumber: 48,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-xl font-semibold tracking-[0.06em] text-white sm:text-2xl sm:tracking-[0.12em] lg:text-3xl",
                                    children: [
                                        t("title1"),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                                            fileName: "[project]/components/home/HomeCtaSection.tsx",
                                            lineNumber: 53,
                                            columnNumber: 17
                                        }, this),
                                        t("title2")
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/HomeCtaSection.tsx",
                                    lineNumber: 51,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-6 flex flex-col gap-3 sm:flex-row",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: "/auctions",
                                            className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-full bg-[#f0c982] px-7 text-sm font-semibold text-black transition-colors hover:bg-[#f4d79b]",
                                            children: [
                                                t("watchLive"),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "material-symbols-outlined text-base",
                                                    "aria-hidden": "true",
                                                    children: "arrow_forward"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/HomeCtaSection.tsx",
                                                    lineNumber: 63,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/HomeCtaSection.tsx",
                                            lineNumber: 58,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            href: isLoggedIn ? "/auctions" : "/auth?mode=signup",
                                            className: "inline-flex min-h-12 items-center justify-center gap-2 rounded-full border border-[#d7aa63]/55 bg-black/35 px-7 text-sm font-semibold text-white transition-colors hover:bg-white/10",
                                            children: [
                                                isLoggedIn ? t("enterRoom") : t("signUp"),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "material-symbols-outlined text-base",
                                                    "aria-hidden": "true",
                                                    children: isLoggedIn ? "gavel" : "person_add"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/HomeCtaSection.tsx",
                                                    lineNumber: 72,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/home/HomeCtaSection.tsx",
                                            lineNumber: 67,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/HomeCtaSection.tsx",
                                    lineNumber: 57,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-5 grid max-w-xl grid-cols-1 gap-3 text-xs text-white/70 sm:grid-cols-3",
                                    children: features.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "inline-flex min-h-10 items-center gap-2 rounded-full border border-white/10 bg-black/35 px-3",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "material-symbols-outlined text-sm text-[#f0c982]",
                                                    "aria-hidden": "true",
                                                    children: "check_circle"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/home/HomeCtaSection.tsx",
                                                    lineNumber: 84,
                                                    columnNumber: 21
                                                }, this),
                                                item
                                            ]
                                        }, item, true, {
                                            fileName: "[project]/components/home/HomeCtaSection.tsx",
                                            lineNumber: 80,
                                            columnNumber: 19
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/home/HomeCtaSection.tsx",
                                    lineNumber: 78,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/HomeCtaSection.tsx",
                            lineNumber: 47,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/home/HomeCtaSection.tsx",
                        lineNumber: 46,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/home/HomeCtaSection.tsx",
                lineNumber: 35,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/home/HomeCtaSection.tsx",
            lineNumber: 34,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/home/HomeCtaSection.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_s(HomeCtaSection, "jJjQPsc6ydUWY6MBh3K+MGKK7Qk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSyncExternalStore"]
    ];
});
_c = HomeCtaSection;
var _c;
__turbopack_context__.k.register(_c, "HomeCtaSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/home/Footer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fa6/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
const socialItems = [
    {
        label: "Facebook",
        href: "https://www.facebook.com",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaFacebookF"]
    },
    {
        label: "Instagram",
        href: "https://www.instagram.com",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaInstagram"]
    },
    {
        label: "X",
        href: "https://x.com",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaXTwitter"]
    },
    {
        label: "YouTube",
        href: "https://www.youtube.com",
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fa6$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FaYoutube"]
    }
];
function Footer() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("footer");
    const year = new Date().getFullYear();
    const footerColumns = [
        {
            title: t("infoTitle"),
            links: [
                {
                    label: t("about"),
                    href: "/about"
                },
                {
                    label: t("contact"),
                    href: "mailto:support@bidzone.com"
                },
                {
                    label: t("terms"),
                    href: "/legal#terms"
                },
                {
                    label: t("privacy"),
                    href: "/legal#privacy"
                }
            ]
        },
        {
            title: t("supportTitle"),
            links: [
                {
                    label: t("helpCenter"),
                    href: "/help"
                },
                {
                    label: t("biddingGuide"),
                    href: "/help#bidding"
                },
                {
                    label: t("payments"),
                    href: "/help#payments"
                },
                {
                    label: t("shipping"),
                    href: "/help#shipping"
                }
            ]
        },
        {
            title: t("categoriesTitle"),
            links: [
                {
                    label: t("watches"),
                    href: "/storefront?category=2"
                },
                {
                    label: t("art"),
                    href: "/storefront?category=1"
                },
                {
                    label: t("jewelry"),
                    href: "/storefront?category=3"
                },
                {
                    label: t("furniture"),
                    href: "/storefront?category=5"
                },
                {
                    label: t("seeAll"),
                    href: "/categories"
                }
            ]
        }
    ];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "bg-black",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "mx-auto max-w-[1600px] px-4 py-10 sm:px-6 lg:px-12",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 gap-10 border-b border-white/10 pb-10 lg:grid-cols-[1.2fr_2fr_1fr]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    href: "/",
                                    className: "inline-flex items-center",
                                    "aria-label": "BidZone",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        className: "h-14 w-auto"
                                    }, void 0, false, {
                                        fileName: "[project]/components/home/Footer.tsx",
                                        lineNumber: 63,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 58,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-4 max-w-xs text-sm leading-relaxed text-white/55",
                                    children: t("tagline")
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 65,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-5 flex gap-3",
                                    children: socialItems.map(({ label, href, icon: Icon })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                            href: href,
                                            target: "_blank",
                                            rel: "noreferrer",
                                            "aria-label": label,
                                            title: label,
                                            className: "flex h-8 w-8 items-center justify-center rounded-full border border-white/15 bg-white/[0.03] text-white/70 transition-colors hover:border-[#f0c982]/60 hover:bg-[#f0c982]/10 hover:text-[#f0c982] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#f0c982]",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Icon, {
                                                className: "h-3.5 w-3.5",
                                                "aria-hidden": "true"
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/Footer.tsx",
                                                lineNumber: 79,
                                                columnNumber: 19
                                            }, this)
                                        }, label, false, {
                                            fileName: "[project]/components/home/Footer.tsx",
                                            lineNumber: 70,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/Footer.tsx",
                            lineNumber: 57,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-1 gap-8 sm:grid-cols-3",
                            children: footerColumns.map((column)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-xs font-semibold tracking-[0.2em] text-[#f0c982]",
                                            children: column.title
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/Footer.tsx",
                                            lineNumber: 88,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                                            className: "mt-4 space-y-2",
                                            children: column.links.map((link)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        href: link.href,
                                                        className: "text-sm text-white/55 transition-colors hover:text-white",
                                                        children: link.label
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/home/Footer.tsx",
                                                        lineNumber: 94,
                                                        columnNumber: 23
                                                    }, this)
                                                }, link.href, false, {
                                                    fileName: "[project]/components/home/Footer.tsx",
                                                    lineNumber: 93,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/Footer.tsx",
                                            lineNumber: 91,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, column.title, true, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 87,
                                    columnNumber: 15
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/home/Footer.tsx",
                            lineNumber: 85,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            id: "contact",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-xs font-semibold tracking-[0.2em] text-[#f0c982]",
                                    children: t("infoTitle")
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 108,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-4 space-y-2 text-sm leading-relaxed text-white/55",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "tel:19008888",
                                                className: "transition-colors hover:text-white",
                                                children: t("contactPhone", {
                                                    phone: "1900 8888"
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/Footer.tsx",
                                                lineNumber: 113,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/Footer.tsx",
                                            lineNumber: 112,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "mailto:support@bidzone.com",
                                                className: "transition-colors hover:text-white",
                                                children: t("contactEmail", {
                                                    email: "support@bidzone.com"
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/Footer.tsx",
                                                lineNumber: 118,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/Footer.tsx",
                                            lineNumber: 117,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "https://www.google.com/maps/search/?api=1&query=123+Le+Loi+Quan+1+Ho+Chi+Minh",
                                                target: "_blank",
                                                rel: "noreferrer",
                                                className: "transition-colors hover:text-white",
                                                children: t("contactAddress", {
                                                    address: "123 Lê Lợi, Quận 1, TP. Hồ Chí Minh"
                                                })
                                            }, void 0, false, {
                                                fileName: "[project]/components/home/Footer.tsx",
                                                lineNumber: 123,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/home/Footer.tsx",
                                            lineNumber: 122,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 111,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/Footer.tsx",
                            lineNumber: 107,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/home/Footer.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col gap-4 pt-6 text-xs text-white/40 sm:flex-row sm:items-center sm:justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: t("copyright", {
                                year
                            })
                        }, void 0, false, {
                            fileName: "[project]/components/home/Footer.tsx",
                            lineNumber: 137,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap items-center gap-x-5 gap-y-2 text-sm font-semibold text-white/75",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "VISA"
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 139,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Mastercard"
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 140,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "PayPal"
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 141,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: "Apple Pay"
                                }, void 0, false, {
                                    fileName: "[project]/components/home/Footer.tsx",
                                    lineNumber: 142,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/home/Footer.tsx",
                            lineNumber: 138,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/home/Footer.tsx",
                    lineNumber: 136,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/home/Footer.tsx",
            lineNumber: 55,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/home/Footer.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
_s(Footer, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c = Footer;
var _c;
__turbopack_context__.k.register(_c, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_1qhitjr._.js.map