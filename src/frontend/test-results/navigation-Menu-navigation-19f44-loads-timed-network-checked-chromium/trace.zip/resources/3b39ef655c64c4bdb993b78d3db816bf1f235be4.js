(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BidZoneLogo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
function BidZoneLogo({ className = "h-10 w-auto", priority = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `inline-flex items-center gap-2.5 ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "relative aspect-square h-full shrink-0",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: "/bidzone-logo.png",
                    alt: "",
                    fill: true,
                    sizes: "64px",
                    priority: priority,
                    className: "object-contain"
                }, void 0, false, {
                    fileName: "[project]/components/brand/BidZoneLogo.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/brand/BidZoneLogo.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-[1.35rem] font-black leading-none tracking-[-0.055em]",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-white",
                        children: "Bid"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/BidZoneLogo.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[#d5b15d]",
                        children: "Zone"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/BidZoneLogo.tsx",
                        lineNumber: 26,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/brand/BidZoneLogo.tsx",
                lineNumber: 24,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/brand/BidZoneLogo.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = BidZoneLogo;
var _c;
__turbopack_context__.k.register(_c, "BidZoneLogo");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/i18n/LanguageSwitcher.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LanguageSwitcher
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-icons/fi/index.mjs [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
/**
 * Persist the locale in NEXT_LOCALE and refresh without changing URL structure.
 */ function setLocaleCookie(locale) {
    document.cookie = `NEXT_LOCALE=${locale}; path=/; max-age=31536000; SameSite=Lax`;
}
function LanguageSwitcher({ compactOnMobile = false }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("language");
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isPending, startTransition] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"])();
    function handleSwitch() {
        // Read the active locale from the cookie.
        const current = document.cookie.split("; ").find((row)=>row.startsWith("NEXT_LOCALE="))?.split("=")[1] ?? "vi";
        const next = current === "vi" ? "en" : "vi";
        setLocaleCookie(next);
        startTransition(()=>{
            router.refresh();
        });
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        type: "button",
        onClick: handleSwitch,
        disabled: isPending,
        "aria-label": t("switchTo"),
        className: `language-switcher${compactOnMobile ? " language-switcher--compact" : ""}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$icons$2f$fi$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FiGlobe"], {
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: compactOnMobile ? "hidden sm:inline" : undefined,
                children: t("current")
            }, void 0, false, {
                fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/i18n/LanguageSwitcher.tsx",
        lineNumber: 41,
        columnNumber: 5
    }, this);
}
_s(LanguageSwitcher, "IQNdCJE7xrs4v6E4HoZyj8QB7U4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTransition"]
    ];
});
_c = LanguageSwitcher;
var _c;
__turbopack_context__.k.register(_c, "LanguageSwitcher");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_BASE_URL",
    ()=>API_BASE_URL,
    "AUTH_STATE_EVENT",
    ()=>AUTH_STATE_EVENT,
    "ApiError",
    ()=>ApiError,
    "adminApi",
    ()=>adminApi,
    "aiApi",
    ()=>aiApi,
    "auctionApi",
    ()=>auctionApi,
    "authApi",
    ()=>authApi,
    "autoBidApi",
    ()=>autoBidApi,
    "chatbotApi",
    ()=>chatbotApi,
    "fetchAccountSummary",
    ()=>fetchAccountSummary,
    "fetchLiveAuctions",
    ()=>fetchLiveAuctions,
    "fetchPublicStats",
    ()=>fetchPublicStats,
    "fetchStorefrontCategories",
    ()=>fetchStorefrontCategories,
    "fetchStorefrontLots",
    ()=>fetchStorefrontLots,
    "getOrCreateDeviceId",
    ()=>getOrCreateDeviceId,
    "getToken",
    ()=>getToken,
    "kycApi",
    ()=>kycApi,
    "orderApi",
    ()=>orderApi,
    "premiumApi",
    ()=>premiumApi,
    "productApi",
    ()=>productApi,
    "sellerApi",
    ()=>sellerApi,
    "sellerContractApi",
    ()=>sellerContractApi,
    "setToken",
    ()=>setToken,
    "toFrontendRole",
    ()=>toFrontendRole,
    "toImageSrc",
    ()=>toImageSrc,
    "updateRoleCookie",
    ()=>updateRoleCookie,
    "uploadImages",
    ()=>uploadImages,
    "userApi",
    ()=>userApi,
    "walletApi",
    ()=>walletApi
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const LOCAL_API_BASE_URL = "http://localhost:8096/api";
const PRODUCTION_API_BASE_URL = "https://api.bidzone.io.vn/api";
const configuredApiBaseUrl = ("TURBOPACK compile-time value", "http://localhost:8096/api")?.trim();
const configuredForLocalhost = configuredApiBaseUrl?.startsWith("http://localhost") || configuredApiBaseUrl?.startsWith("http://127.0.0.1");
const API_BASE_URL = ("TURBOPACK compile-time falsy", 0) ? "TURBOPACK unreachable" : configuredApiBaseUrl || LOCAL_API_BASE_URL;
const orderApi = {
    mine: ()=>apiFetch("/orders"),
    one: (id)=>apiFetch(`/orders/${id}`),
    confirmReceived: (id)=>apiFetch(`/orders/${id}/confirm-received`, {
            method: "POST"
        }),
    shippingFee: ()=>apiFetch("/orders/shipping-fee"),
    staffOrders: (status)=>apiFetch(`/staff/orders${status ? `?status=${encodeURIComponent(status)}` : ""}`),
    shippers: ()=>apiFetch("/staff/shippers"),
    assign: (id, shipperId, note)=>apiFetch(`/staff/orders/${id}/assign`, {
            method: "POST",
            body: JSON.stringify({
                shipperId,
                note
            })
        }),
    failedAction: (id, action, shipperId, note)=>apiFetch(`/staff/orders/${id}/failed-action`, {
            method: "POST",
            body: JSON.stringify({
                action,
                shipperId,
                note
            })
        }),
    shipperMine: ()=>apiFetch("/shipper/orders"),
    shipperStatus: (id, status, note)=>apiFetch(`/shipper/orders/${id}/status`, {
            method: "POST",
            body: JSON.stringify({
                status,
                note
            })
        })
};
// ---------------------------------------------------------------------------
// Core fetch helper — tự gắn JWT (lưu ở localStorage sau khi login)
// ---------------------------------------------------------------------------
const TOKEN_KEY = "bidzone_token";
const DEVICE_ID_KEY = "bidzone_device_id";
const AUTH_ROLE_COOKIE = "bidzone_role";
const AUTH_STATE_EVENT = "bidzone-auth-change";
function getToken() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return window.localStorage.getItem(TOKEN_KEY);
}
// ---------------------------------------------------------------------------
// Request de-duplication — several independent components (Header, sidebar,
// dashboard page) fetch the same "current user" data (profile, wallet) on
// every mount with no shared cache, so a single page load fires the same
// request 2-3x. This coalesces same-key calls made within a short window
// into a single in-flight request/result, without changing any call site's
// signature or return type.
// ---------------------------------------------------------------------------
const DEDUP_TTL_MS = 3000;
const clearDedupCaches = [];
function dedupedWithTtl(ttlMs) {
    let cache = null;
    const clear = ()=>{
        cache = null;
    };
    clearDedupCaches.push(clear);
    const run = (loader)=>{
        const now = Date.now();
        if (cache && now - cache.timestamp < ttlMs) {
            return cache.promise;
        }
        const promise = loader();
        cache = {
            promise,
            timestamp: now
        };
        promise.catch(clear);
        return promise;
    };
    return {
        run,
        clear
    };
}
function setToken(token) {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    if (token) window.localStorage.setItem(TOKEN_KEY, token);
    else window.localStorage.removeItem(TOKEN_KEY);
    clearDedupCaches.forEach((clear)=>clear());
    window.dispatchEvent(new Event(AUTH_STATE_EVENT));
}
/**
 * Central 401 handling: previously only 2 of ~30+ call sites reacted to a 401 by logging
 * out, so an expired/invalid token surfaced everywhere else as a generic, unexplained error
 * instead of the app recognizing the session had ended. Called from every fetch helper below
 * whenever a request that DID send the stored token comes back 401 — clearing the session so
 * `isLoggedIn` (Header, route guards) reacts immediately, without forcing a redirect from
 * inside a data-fetching utility.
 *
 * Only fires when `sentToken` is truthy: a 401 on a request made without a token (e.g. login
 * with a wrong password, sent with `auth: false`) is a normal business-logic failure, not a
 * session expiry, and must not clear an unrelated already-logged-in session.
 */ function handleUnauthorizedResponse(status, sentToken) {
    if (status === 401 && sentToken) {
        setAuthRoleCookie(null);
        setToken(null);
    }
}
function getOrCreateDeviceId() {
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    let deviceId = window.localStorage.getItem(DEVICE_ID_KEY);
    if (!deviceId) {
        deviceId = window.crypto.randomUUID();
        window.localStorage.setItem(DEVICE_ID_KEY, deviceId);
    }
    return deviceId;
}
function setAuthRoleCookie(role) {
    if (typeof document === "undefined") return;
    const secure = window.location.protocol === "https:" ? "; Secure" : "";
    document.cookie = role ? `${AUTH_ROLE_COOKIE}=${role}; path=/; max-age=604800; SameSite=Lax${secure}` : `${AUTH_ROLE_COOKIE}=; path=/; max-age=0; SameSite=Lax${secure}`;
}
function storeLoginResponse(response) {
    if (!response.token) return;
    setAuthRoleCookie(toFrontendRole(response.roleName));
    setToken(response.token);
}
class ApiError extends Error {
    status;
    constructor(status, message){
        super(message), this.status = status;
    }
}
async function apiFetch(path, options = {}) {
    const { auth = true, headers, ...rest } = options;
    const token = auth ? getToken() : null;
    const deviceId = auth ? getOrCreateDeviceId() : null;
    const res = await fetch(`${API_BASE_URL}${path}`, {
        ...rest,
        headers: {
            ...rest.body && !(rest.body instanceof FormData) ? {
                "Content-Type": "application/json"
            } : {},
            ...token ? {
                Authorization: `Bearer ${token}`
            } : {},
            ...deviceId ? {
                "X-Device-Id": deviceId
            } : {},
            ...headers
        }
    });
    if (!res.ok) {
        let message = `HTTP ${res.status}`;
        try {
            const body = await res.json();
            message = body.message ?? body.detail ?? body.error ?? message;
        } catch  {
        /* body không phải JSON */ }
        handleUnauthorizedResponse(res.status, token);
        throw new ApiError(res.status, message);
    }
    if (res.status === 204) return undefined;
    return await res.json();
}
/**
 * POST multipart/form-data (file uploads). Unlike {@link apiFetch} we must NOT
 * set Content-Type — the browser adds the multipart boundary itself.
 */ async function postMultipart(path, form) {
    const token = getToken();
    const res = await fetch(`${API_BASE_URL}${path}`, {
        method: "POST",
        headers: token ? {
            Authorization: `Bearer ${token}`
        } : {},
        body: form
    });
    if (!res.ok) {
        let message = `HTTP ${res.status}`;
        try {
            const body = await res.json();
            message = body.message ?? body.detail ?? body.error ?? message;
        } catch  {
        /* body không phải JSON */ }
        handleUnauthorizedResponse(res.status, token);
        throw new ApiError(res.status, message);
    }
    if (res.status === 204) return undefined;
    return await res.json();
}
async function uploadImages(files) {
    const form = new FormData();
    for (const file of files)form.append("files", file);
    const body = await postMultipart("/uploads", form);
    return body.data ?? [];
}
function toFrontendRole(roleName) {
    switch((roleName ?? "").toLowerCase()){
        case "admin":
            return "admin";
        case "staff":
            return "staff";
        case "seller":
            return "seller";
        case "shipper":
            return "shipper";
        default:
            return "collector";
    }
}
const authApi = {
    async login (usernameOrEmail, password) {
        const res = await apiFetch("/auth/login", {
            method: "POST",
            body: JSON.stringify({
                usernameOrEmail,
                password
            }),
            auth: false
        });
        storeLoginResponse(res);
        return res;
    },
    register (data) {
        return apiFetch("/auth/register", {
            method: "POST",
            body: JSON.stringify(data),
            auth: false
        });
    },
    sendRegistrationEmailCode (email) {
        return apiFetch("/auth/register/email/send-code", {
            method: "POST",
            body: JSON.stringify({
                email
            }),
            auth: false
        });
    },
    verifyRegistrationEmailCode (email, code) {
        return apiFetch("/auth/register/email/verify-code", {
            method: "POST",
            body: JSON.stringify({
                email,
                code
            }),
            auth: false
        });
    },
    verifyEmail (token) {
        return apiFetch(`/auth/verify-email?token=${encodeURIComponent(token)}`, {
            auth: false
        });
    },
    resendEmailVerification (email) {
        return apiFetch("/auth/email-verification/resend", {
            method: "POST",
            body: JSON.stringify({
                email
            }),
            auth: false
        });
    },
    async googleLogin (credential) {
        const res = await apiFetch("/auth/google", {
            method: "POST",
            body: JSON.stringify({
                credential
            }),
            auth: false
        });
        storeLoginResponse(res);
        return res;
    },
    logout () {
        setAuthRoleCookie(null);
        setToken(null);
    }
};
const productApi = {
    search (params) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(params)){
            if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
        }
        return apiFetch(`/products?${q}`, {
            auth: false
        });
    },
    detail (productId) {
        return apiFetch(`/products/${productId}`, {
            auth: false
        });
    },
    categories () {
        return apiFetch("/categories", {
            auth: false
        });
    },
    categoryAttributes (categoryId) {
        return apiFetch(`/categories/${categoryId}/attributes`, {
            auth: false
        });
    },
    featured () {
        return apiFetch("/featured-products", {
            auth: false
        });
    },
    mine () {
        return apiFetch("/seller/products/mine");
    },
    sellerDetail (productId) {
        return apiFetch(`/seller/products/${productId}`);
    },
    create (payload) {
        return apiFetch("/seller/products", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    update (productId, payload) {
        return apiFetch(`/seller/products/${productId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
        });
    }
};
const aiApi = {
    valuation (payload) {
        return apiFetch("/ai/valuation", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    valuationQuota () {
        return apiFetch("/ai/valuation/quota");
    }
};
const kycApi = {
    ocr (frontImage, backImage) {
        const form = new FormData();
        form.append("frontImage", frontImage);
        form.append("backImage", backImage);
        return postMultipart("/kyc/ocr", form);
    },
    submit (payload) {
        const form = new FormData();
        form.append("fullName", payload.fullName);
        form.append("cccdNumber", payload.cccdNumber);
        form.append("dob", payload.dob);
        form.append("gender", payload.gender);
        form.append("issueDate", payload.issueDate);
        form.append("issuePlace", payload.issuePlace);
        form.append("frontImage", payload.frontImage);
        form.append("backImage", payload.backImage);
        form.append("selfieImage", payload.selfieImage);
        form.append("signSellerAgreement", String(payload.signSellerAgreement ?? false));
        return postMultipart("/kyc", form);
    },
    mine () {
        return apiFetch("/kyc/me");
    },
    /** Fetch a private KYC image (owner or staff only) as a blob for rendering. */ async imageBlob (kycId, which) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/kyc/${kycId}/image/${which}`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    }
};
const sellerContractApi = {
    /** Fetch the seller agreement preview PDF as a blob (needs JWT header). */ async previewPdf () {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/seller-contract/preview-pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    /** Fetch the persisted signed agreement PDF. */ async signedPdf () {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/seller-contract/me/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    /**
   * Sign the seller agreement and upgrade User -> Seller immediately.
   * Requires an APPROVED KYC (identityVerified) — enforced server-side.
   */ submit () {
        return apiFetch("/seller-contract/submit", {
            method: "POST"
        });
    },
    mine () {
        return apiFetch("/seller-contract/me");
    }
};
function updateRoleCookie(roleName) {
    setAuthRoleCookie(toFrontendRole(roleName));
    if ("TURBOPACK compile-time truthy", 1) {
        window.dispatchEvent(new Event(AUTH_STATE_EVENT));
    }
}
const premiumApi = {
    status () {
        return apiFetch("/premium/status");
    },
    purchase (plan) {
        return apiFetch("/premium/purchase", {
            method: "POST",
            body: JSON.stringify({
                plan
            })
        });
    }
};
const autoBidApi = {
    set (auctionId, maxBidAmount) {
        return apiFetch(`/bidding/auto/${auctionId}`, {
            method: "POST",
            body: JSON.stringify({
                maxBidAmount
            })
        });
    },
    cancel (auctionId) {
        return apiFetch(`/bidding/auto/${auctionId}`, {
            method: "DELETE"
        });
    },
    get (auctionId) {
        return apiFetch(`/bidding/auto/${auctionId}`);
    }
};
const auctionApi = {
    state (auctionId) {
        return apiFetch(`/auctions/${auctionId}/state`, {
            auth: false
        });
    },
    bids (auctionId) {
        return apiFetch(`/auctions/${auctionId}/bids`, {
            auth: false
        });
    },
    eligibility (auctionId) {
        return apiFetch(`/auctions/${auctionId}/eligibility`);
    },
    /** Bid cao nhất của CHÍNH người gọi — luôn xem được, kể cả phiên giá kín. */ myBid (auctionId) {
        return apiFetch(`/auctions/${auctionId}/my-bid`);
    },
    placeBid (auctionId, bidAmount) {
        return apiFetch(`/auctions/${auctionId}/bid`, {
            method: "POST",
            body: JSON.stringify({
                bidAmount
            })
        });
    },
    pay (auctionId, address) {
        return apiFetch(`/auctions/${auctionId}/pay`, {
            method: "POST",
            body: JSON.stringify(address)
        });
    },
    purchaseContract (auctionId) {
        return apiFetch(`/auctions/${auctionId}/purchase-contract`);
    },
    signPurchaseContract (auctionId) {
        return apiFetch(`/auctions/${auctionId}/purchase-contract/sign`, {
            method: "POST"
        });
    },
    async purchaseContractPdf (auctionId) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/auctions/${auctionId}/purchase-contract/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    deposit (auctionId) {
        return apiFetch(`/deposits?auctionId=${auctionId}`, {
            method: "POST"
        });
    },
    rooms () {
        return apiFetch("/bidding/rooms");
    },
    chatMessages (auctionId) {
        return apiFetch(`/auctions/${auctionId}/chat/messages`, {
            auth: false
        });
    },
    myBids () {
        return apiFetch("/bids/my-bids");
    },
    wonAuctions () {
        return apiFetch("/bids/won");
    }
};
// ---------------------------------------------------------------------------
// WALLET — /api/wallet*
// ---------------------------------------------------------------------------
const walletGetCache = dedupedWithTtl(DEDUP_TTL_MS);
const walletApi = {
    get () {
        return walletGetCache.run(()=>apiFetch("/wallet"));
    },
    transactions () {
        return apiFetch("/wallet/transactions");
    },
    deposit (amount) {
        return apiFetch("/wallet/deposit", {
            method: "POST",
            body: JSON.stringify({
                amount
            })
        });
    },
    withdraw (data) {
        return apiFetch("/wallet/withdraw", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    withdrawals () {
        return apiFetch("/wallet/withdrawals");
    }
};
const userProfileCache = dedupedWithTtl(DEDUP_TTL_MS);
// CollectorSidebar (unread badge) and the /messages page both call this independently, and
// on the backend it's a genuinely slow query (batched, but still ~1s+ against the remote DB) —
// firing it 2-3x concurrently on one page load compounds into visible connection contention.
const myConversationsCache = dedupedWithTtl(DEDUP_TTL_MS);
const userApi = {
    profile () {
        return userProfileCache.run(()=>apiFetch("/users/me/profile"));
    },
    async updateProfile (fullName) {
        const result = await apiFetch("/users/me/profile", {
            method: "PUT",
            body: JSON.stringify({
                fullName
            })
        });
        userProfileCache.clear();
        return result;
    },
    changePassword (data) {
        return apiFetch("/users/me/change-password", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    notifications () {
        return apiFetch("/notifications");
    },
    unreadCount () {
        return apiFetch("/notifications/unread-count");
    },
    markNotificationRead (id) {
        return apiFetch(`/notifications/${id}/read`, {
            method: "POST"
        });
    },
    watchlist () {
        return apiFetch("/watchlist");
    },
    addToWatchlist (productId) {
        return apiFetch(`/watchlist/${productId}`, {
            method: "POST"
        });
    },
    removeFromWatchlist (productId) {
        return apiFetch(`/watchlist/${productId}`, {
            method: "DELETE"
        });
    },
    myKyc () {
        return apiFetch("/kyc/me");
    },
    submitKyc (formData) {
        return apiFetch("/kyc", {
            method: "POST",
            body: formData
        });
    },
    myConversations () {
        return myConversationsCache.run(()=>apiFetch("/v1/conversations/my"));
    },
    createConversation (data) {
        return apiFetch("/v1/conversations", {
            method: "POST",
            body: JSON.stringify(data)
        });
    },
    conversationMessages (conversationId) {
        return apiFetch(`/v1/messages/conversation/${conversationId}`);
    },
    async markConversationRead (conversationId) {
        const result = await apiFetch(`/v1/messages/conversation/${conversationId}/read`, {
            method: "PATCH"
        });
        myConversationsCache.clear();
        return result;
    },
    async sendMessage (conversationId, content) {
        const result = await apiFetch("/v1/messages", {
            method: "POST",
            body: JSON.stringify({
                conversationId,
                content
            })
        });
        myConversationsCache.clear();
        return result;
    },
    // --- Staff support inbox ---
    assignedConversations () {
        return apiFetch("/v1/conversations/assigned");
    },
    unassignedConversations () {
        return apiFetch("/v1/conversations/unassigned");
    },
    assignConversation (conversationId) {
        return apiFetch(`/v1/conversations/${conversationId}/assign`, {
            method: "PATCH"
        });
    },
    closeConversation (conversationId) {
        return apiFetch(`/v1/conversations/${conversationId}/close`, {
            method: "PATCH"
        });
    }
};
async function fetchAccountSummary() {
    const [profile, wallet] = await Promise.all([
        userApi.profile(),
        walletApi.get()
    ]);
    return {
        profile: profile.data,
        wallet
    };
}
async function fetchPublicStats() {
    try {
        const response = await fetch(`${API_BASE_URL}/public/stats`, {
            cache: "no-store",
            signal: AbortSignal.timeout(5000)
        });
        if (!response.ok) return [];
        const stats = await response.json();
        return [
            {
                id: "products",
                value: stats.totalProducts.toLocaleString("vi-VN")
            },
            {
                id: "members",
                value: stats.totalUsers.toLocaleString("vi-VN")
            },
            {
                id: "active-auctions",
                value: stats.activeAuctions.toLocaleString("vi-VN")
            },
            {
                id: "completed-auctions",
                value: stats.completedAuctions.toLocaleString("vi-VN")
            }
        ];
    } catch  {
        return [];
    }
}
const adminApi = {
    summary () {
        return apiFetch("/admin/dashboard/summary");
    },
    revenue () {
        return apiFetch("/admin/dashboard/revenue");
    },
    salesHistory () {
        return apiFetch("/admin/dashboard/sales-history");
    },
    auctionSessions (payment = "ALL") {
        return apiFetch(`/admin/dashboard/auction-sessions?payment=${payment}`);
    },
    categories () {
        return apiFetch("/admin/categories");
    },
    createCategory (categoryName, description) {
        return apiFetch("/admin/categories", {
            method: "POST",
            body: JSON.stringify({
                categoryName,
                description,
                isActive: true
            })
        });
    },
    deleteCategory (categoryId) {
        return apiFetch(`/admin/categories/${categoryId}`, {
            method: "DELETE"
        });
    },
    events () {
        return apiFetch("/admin/events");
    },
    createEvent (payload) {
        return apiFetch("/admin/events", {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    updateEvent (eventId, payload) {
        return apiFetch(`/admin/events/${eventId}`, {
            method: "PUT",
            body: JSON.stringify(payload)
        });
    },
    deleteEvent (eventId) {
        return apiFetch(`/admin/events/${eventId}`, {
            method: "DELETE"
        });
    },
    eventProducts (eventId) {
        return apiFetch(`/admin/events/${eventId}/products`);
    },
    assignExistingProductToEvent (eventId, productId) {
        return apiFetch(`/admin/events/${eventId}/products/existing/${productId}`, {
            method: "POST"
        });
    },
    approveEventProduct (eventProductId) {
        return apiFetch(`/admin/events/products/${eventProductId}/approve`, {
            method: "POST"
        });
    },
    rejectEventProduct (eventProductId, reason) {
        return apiFetch(`/admin/events/products/${eventProductId}/reject`, {
            method: "POST",
            body: JSON.stringify({
                reason
            })
        });
    },
    removeEventProduct (eventProductId) {
        return apiFetch(`/admin/events/products/${eventProductId}`, {
            method: "DELETE"
        });
    },
    availableProducts () {
        return apiFetch("/admin/events/available-products");
    },
    pendingProducts () {
        return apiFetch("/admin/products/pending");
    },
    approveProduct (productId, payload) {
        return apiFetch(`/admin/products/${productId}/approve`, {
            method: "POST",
            body: JSON.stringify(payload)
        });
    },
    rejectProduct (productId, reason = "") {
        return apiFetch(`/admin/products/${productId}/reject`, {
            method: "POST",
            body: JSON.stringify({
                reason
            })
        });
    },
    // KYC review — backend returns a raw List (not an ApiEnvelope) for /kyc/list.
    kycList (status = "PENDING") {
        return apiFetch(`/kyc/list?status=${encodeURIComponent(status)}`);
    },
    approveKyc (kycId) {
        return apiFetch(`/kyc/${kycId}/approve`, {
            method: "POST"
        });
    },
    // reason is a @RequestParam on the backend, so it goes in the query string.
    rejectKyc (kycId, reason) {
        return apiFetch(`/kyc/${kycId}/reject?reason=${encodeURIComponent(reason)}`, {
            method: "POST"
        });
    },
    requestInfoKyc (kycId, reason) {
        return apiFetch(`/kyc/${kycId}/request-info?reason=${encodeURIComponent(reason)}`, {
            method: "POST"
        });
    },
    // --- Users & roles (Admin only) ---
    users (q = "") {
        const qs = q ? `?q=${encodeURIComponent(q)}` : "";
        return apiFetch(`/admin/users${qs}`);
    },
    userStats () {
        return apiFetch("/admin/users/stats");
    },
    updateUserRole (userId, roleName) {
        return apiFetch(`/admin/users/${userId}/role`, {
            method: "PATCH",
            body: JSON.stringify({
                roleName
            })
        });
    },
    updateUserStatus (userId, active) {
        return apiFetch(`/admin/users/${userId}/status`, {
            method: "PATCH",
            body: JSON.stringify({
                active
            })
        });
    },
    // --- Withdrawals (Staff/Admin) — backend returns raw lists, no envelope ---
    withdrawals (status = "") {
        const qs = status ? `?status=${encodeURIComponent(status)}` : "";
        return apiFetch(`/staff/withdrawals${qs}`);
    },
    updateWithdrawal (id, status, staffNote = "") {
        return apiFetch(`/staff/withdrawals/${id}/status`, {
            method: "PUT",
            body: JSON.stringify({
                status,
                staffNote
            })
        });
    },
    // --- Contracts & ledger (Admin/Staff dashboard) ---
    contracts (cccd = "") {
        const qs = cccd ? `?cccd=${encodeURIComponent(cccd)}` : "";
        return apiFetch(`/admin/dashboard/contracts${qs}`);
    },
    async contractPdfBlob (contractId) {
        const token = getToken();
        const res = await fetch(`${API_BASE_URL}/admin/dashboard/contracts/${contractId}/pdf`, {
            headers: token ? {
                Authorization: `Bearer ${token}`
            } : {}
        });
        if (!res.ok) {
            handleUnauthorizedResponse(res.status, token);
            throw new ApiError(res.status, `HTTP ${res.status}`);
        }
        return res.blob();
    },
    balanceLedger (params = {}) {
        const q = new URLSearchParams();
        for (const [k, v] of Object.entries(params)){
            if (v !== undefined && v !== null && v !== "") q.set(k, String(v));
        }
        const qs = q.toString() ? `?${q}` : "";
        return apiFetch(`/admin/dashboard/balance-ledger${qs}`);
    },
    fraudSettings () {
        return apiFetch("/admin/settings/fraud-detection");
    },
    updateFraudSettings (payload) {
        return apiFetch("/admin/settings/fraud-detection", {
            method: "PATCH",
            body: JSON.stringify(payload)
        });
    },
    fraudAlerts (params = {}) {
        const q = new URLSearchParams();
        for (const [key, value] of Object.entries(params)){
            if (value !== undefined && value !== null && value !== "") q.set(key, String(value));
        }
        const qs = q.toString() ? `?${q}` : "";
        return apiFetch(`/admin/fraud-alerts${qs}`);
    },
    reviewFraudAlert (id, note = "") {
        return fraudAlertAction(id, "review", note);
    },
    confirmFraudAlert (id, note = "") {
        return fraudAlertAction(id, "confirm", note);
    },
    dismissFraudAlert (id, note = "") {
        return fraudAlertAction(id, "dismiss", note);
    },
    restoreFraudUser (id, note = "") {
        return fraudAlertAction(id, "restore-user", note);
    }
};
const sellerApi = {
    openEvents () {
        return apiFetch("/seller/events");
    },
    submitExistingProductToEvent (eventId, productId) {
        return apiFetch(`/seller/events/${eventId}/products/existing`, {
            method: "POST",
            body: JSON.stringify({
                productId
            })
        });
    },
    mySubmissions (eventId) {
        return apiFetch(`/seller/events/${eventId}/my-submissions`);
    },
    withdrawSubmission (eventProductId) {
        return apiFetch(`/seller/events/products/${eventProductId}`, {
            method: "DELETE"
        });
    }
};
function fraudAlertAction(id, action, note) {
    return apiFetch(`/admin/fraud-alerts/${id}/${action}`, {
        method: "POST",
        body: JSON.stringify({
            note
        })
    });
}
const chatbotApi = {
    reply (message) {
        return apiFetch("/public/chatbot", {
            method: "POST",
            body: JSON.stringify({
                message
            }),
            auth: false
        });
    }
};
// ---------------------------------------------------------------------------
// HOME — dữ liệu trang chủ (server component dùng được, không cần token)
// ---------------------------------------------------------------------------
const VND = new Intl.NumberFormat("vi-VN");
function toImageSrc(imageUrl) {
    if (!imageUrl) return "/images/auction-products/placeholder.png";
    if (imageUrl.startsWith("http")) return imageUrl;
    // Backend trả đường dẫn tương đối (/uploads/...) — đi qua rewrite trong next.config.ts
    return imageUrl.startsWith("/") ? imageUrl : `/${imageUrl}`;
}
function toLiveAuctionItem(p) {
    const price = p.currentBid && p.currentBid > 0 ? p.currentBid : p.startingPrice;
    return {
        id: String(p.auctionId ?? p.productId),
        status: p.auctionStatus?.toUpperCase() === "UPCOMING" ? "UPCOMING" : "ACTIVE",
        title: p.productName,
        subtitle: p.categoryName ?? "",
        currentPrice: `${VND.format(price)} ₫`,
        estimatedPrice: `${VND.format(p.startingPrice)} ₫`,
        bidCount: p.totalBids ?? 0,
        startsAt: p.auctionStartTime ? new Date(p.auctionStartTime).getTime() : Date.now(),
        endsAt: p.auctionEndTime ? new Date(p.auctionEndTime).getTime() : Date.now(),
        imageSrc: toImageSrc(p.imageUrl)
    };
}
async function fetchLiveAuctions(limit = 5) {
    try {
        const loadByStatus = async (auctionStatus)=>{
            const res = await fetch(`${API_BASE_URL}/products?auctionStatus=${auctionStatus}&size=${limit}`, {
                cache: "no-store",
                signal: AbortSignal.timeout(15000)
            });
            if (!res.ok) return [];
            const page = await res.json();
            return page.content ?? [];
        };
        const [active, upcoming] = await Promise.all([
            loadByStatus("ACTIVE"),
            loadByStatus("UPCOMING")
        ]);
        const uniqueAuctions = new Map();
        for (const product of [
            ...active,
            ...upcoming
        ]){
            if (product.auctionId != null && !uniqueAuctions.has(product.auctionId)) {
                uniqueAuctions.set(product.auctionId, product);
            }
        }
        return [
            ...uniqueAuctions.values()
        ].slice(0, limit).map(toLiveAuctionItem);
    } catch  {
        return [];
    }
}
function slugify(name) {
    return name.normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/đ/gi, "d").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}
const CATEGORY_ICONS = {
    "luxury-watch": "watch",
    "dong-ho": "watch",
    art: "palette",
    "tranh-nghe-thuat": "palette",
    jewelry: "diamond",
    "trang-suc": "diamond",
    automotive: "directions_car",
    furniture: "chair",
    ceramics: "emoji_food_beverage",
    "do-co": "museum"
};
const CATEGORY_IMAGES = {
    art: "/images/categories/art.jpg",
    "tranh-nghe-thuat": "/images/categories/art.jpg",
    "luxury-watch": "/images/categories/watch.jpg",
    "dong-ho": "/images/categories/watch.jpg",
    jewelry: "/images/categories/jewelry.jpg",
    "trang-suc": "/images/categories/jewelry.jpg",
    automotive: "/images/categories/automotive.jpg",
    furniture: "/images/categories/furniture.jpg",
    ceramics: "/images/categories/ceramics.jpg",
    "do-co": "/images/categories/antiques.jpg",
    khac: "/images/categories/collectibles.jpg"
};
function formatTimeLeft(endTime) {
    if (!endTime) return "—";
    const ms = new Date(endTime).getTime() - Date.now();
    if (ms <= 0) return "00:00:00";
    const totalSec = Math.floor(ms / 1000);
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor(totalSec % 3600 / 60);
    const s = totalSec % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function toStorefrontLot(p) {
    return {
        id: String(p.auctionId),
        lotNumber: `LOT ${String(p.productId).padStart(3, "0")}`,
        title: p.productName,
        categoryId: slugify(p.categoryName ?? "khac"),
        categoryLabel: p.categoryName ?? "",
        currentBid: p.currentBid && p.currentBid > 0 ? p.currentBid : p.startingPrice,
        timeLeft: formatTimeLeft(p.auctionEndTime),
        endsAt: p.auctionEndTime ? new Date(p.auctionEndTime).getTime() : null,
        isLive: p.auctionStatus === "ACTIVE",
        auctionStatus: p.auctionStatus,
        image: toImageSrc(p.imageUrl)
    };
}
async function fetchStorefrontLots(limit = 60) {
    try {
        const res = await fetch(`${API_BASE_URL}/products?size=${limit}`, {
            cache: "no-store",
            signal: AbortSignal.timeout(15000)
        });
        if (!res.ok) return [];
        const page = await res.json();
        return (page.content ?? []).filter((p)=>p.auctionId != null).map(toStorefrontLot);
    } catch  {
        return [];
    }
}
async function fetchStorefrontCategories(lots) {
    try {
        const res = await fetch(`${API_BASE_URL}/categories`, {
            cache: "no-store",
            signal: AbortSignal.timeout(15000)
        });
        if (!res.ok) return [];
        const body = await res.json();
        const allLots = lots ?? await fetchStorefrontLots();
        return (body.data ?? []).filter((c)=>c.isActive).map((c)=>{
            const slug = slugify(c.categoryName);
            const inCategory = allLots.filter((lot)=>lot.categoryId === slug);
            return {
                id: slug,
                label: c.categoryName,
                icon: CATEGORY_ICONS[slug] ?? "category",
                count: String(inCategory.length),
                description: c.description ?? "",
                imageSrc: CATEGORY_IMAGES[slug] ?? "/images/categories/collectibles.jpg"
            };
        });
    } catch  {
        return [];
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/shells/StaffSidebar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>StaffSidebar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/BidZoneLogo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$i18n$2f$LanguageSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/i18n/LanguageSwitcher.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const NAV_ITEMS = [
    {
        labelKey: "orders",
        href: "/staff/orders",
        icon: "local_shipping"
    },
    {
        labelKey: "approvals",
        href: "/staff/approvals",
        icon: "fact_check"
    },
    {
        labelKey: "kycReview",
        href: "/staff/kyc-review",
        icon: "badge"
    },
    {
        labelKey: "supportInbox",
        href: "/staff/support",
        icon: "inbox"
    }
];
function StaffSidebar() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("sidebar.staff");
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
        className: "sticky top-0 hidden h-screen w-72 shrink-0 flex-col border-r border-white/10 bg-[var(--luxora-bg-elevated)] md:flex",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-b border-white/10 px-6 py-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/",
                        className: "inline-flex items-center",
                        "aria-label": "BidZone",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$BidZoneLogo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            className: "h-9 w-auto"
                        }, void 0, false, {
                            fileName: "[project]/components/shells/StaffSidebar.tsx",
                            lineNumber: 25,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/shells/StaffSidebar.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-white/40",
                        children: t("workspace")
                    }, void 0, false, {
                        fileName: "[project]/components/shells/StaffSidebar.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shells/StaffSidebar.tsx",
                lineNumber: 23,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-4 mt-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "flex h-10 w-10 items-center justify-center rounded-full bg-[var(--luxora-gold)]/10 text-[var(--luxora-gold)]",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "material-symbols-outlined",
                            children: "support_agent"
                        }, void 0, false, {
                            fileName: "[project]/components/shells/StaffSidebar.tsx",
                            lineNumber: 32,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/shells/StaffSidebar.tsx",
                        lineNumber: 31,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-semibold",
                                children: t("staff")
                            }, void 0, false, {
                                fileName: "[project]/components/shells/StaffSidebar.tsx",
                                lineNumber: 35,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-[11px] text-green-300",
                                children: t("online")
                            }, void 0, false, {
                                fileName: "[project]/components/shells/StaffSidebar.tsx",
                                lineNumber: 36,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/shells/StaffSidebar.tsx",
                        lineNumber: 34,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shells/StaffSidebar.tsx",
                lineNumber: 30,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                className: "flex-1 px-4 py-6",
                children: NAV_ITEMS.map((item)=>{
                    const active = pathname === item.href;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: item.href,
                        className: `mb-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors ${active ? "bg-[var(--luxora-gold)]/10 text-[var(--luxora-gold-light)]" : "text-white/60 hover:bg-white/5 hover:text-white"}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "material-symbols-outlined text-xl",
                                children: item.icon
                            }, void 0, false, {
                                fileName: "[project]/components/shells/StaffSidebar.tsx",
                                lineNumber: 53,
                                columnNumber: 15
                            }, this),
                            t(`items.${item.labelKey}`)
                        ]
                    }, item.href, true, {
                        fileName: "[project]/components/shells/StaffSidebar.tsx",
                        lineNumber: 44,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/components/shells/StaffSidebar.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "border-t border-white/10 px-4 py-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-3 px-3",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$i18n$2f$LanguageSwitcher$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/components/shells/StaffSidebar.tsx",
                            lineNumber: 63,
                            columnNumber: 36
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/shells/StaffSidebar.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: "/auth",
                        onClick: ()=>__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["authApi"].logout(),
                        className: "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-white/60 hover:bg-white/5 hover:text-white",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "material-symbols-outlined text-xl",
                                children: "logout"
                            }, void 0, false, {
                                fileName: "[project]/components/shells/StaffSidebar.tsx",
                                lineNumber: 69,
                                columnNumber: 11
                            }, this),
                            t("logout")
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/shells/StaffSidebar.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/shells/StaffSidebar.tsx",
                lineNumber: 62,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/shells/StaffSidebar.tsx",
        lineNumber: 22,
        columnNumber: 5
    }, this);
}
_s(StaffSidebar, "+KcrlTvLOUYo5s7HuulzDK2y3S8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = StaffSidebar;
var _c;
__turbopack_context__.k.register(_c, "StaffSidebar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/staff/kyc-review/KycReviewClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>KycReviewClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/use-intl/dist/esm/development/react.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/api.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
const STATUS_CLASS = {
    PENDING: "bg-yellow-500/10 text-yellow-300",
    APPROVED: "bg-green-500/10 text-green-300",
    REJECTED: "bg-red-500/10 text-red-300",
    INFO_REQUIRED: "bg-blue-500/10 text-blue-300"
};
const SEVERITY_CLASS = {
    HIGH: "text-red-300",
    MEDIUM: "text-yellow-300",
    LOW: "text-white/50"
};
function fmt(date, locale) {
    return date ? new Intl.DateTimeFormat(locale, {
        dateStyle: "short",
        timeStyle: "short"
    }).format(new Date(date)) : "—";
}
function KycReviewClient() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("staffKycReviewPage");
    const locale = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLocale"])();
    const [items, setItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [selectedId, setSelectedId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [note, setNote] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [busy, setBusy] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [notice, setNotice] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const load = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "KycReviewClient.useCallback[load]": async ()=>{
            setLoading(true);
            setError(null);
            try {
                const list = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adminApi"].kycList("PENDING");
                setItems(list);
                setSelectedId({
                    "KycReviewClient.useCallback[load]": (prev)=>prev && list.some({
                            "KycReviewClient.useCallback[load]": (k)=>k.kycId === prev
                        }["KycReviewClient.useCallback[load]"]) ? prev : list[0]?.kycId ?? null
                }["KycReviewClient.useCallback[load]"]);
            } catch (err) {
                setError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"] ? err.message : t("loadError"));
            } finally{
                setLoading(false);
            }
        }
    }["KycReviewClient.useCallback[load]"], [
        t
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "KycReviewClient.useEffect": ()=>{
            const timer = window.setTimeout({
                "KycReviewClient.useEffect.timer": ()=>void load()
            }["KycReviewClient.useEffect.timer"], 0);
            return ({
                "KycReviewClient.useEffect": ()=>window.clearTimeout(timer)
            })["KycReviewClient.useEffect"];
        }
    }["KycReviewClient.useEffect"], [
        load
    ]);
    const current = items.find((k)=>k.kycId === selectedId) ?? null;
    async function act(kind) {
        if (!current) return;
        if ((kind === "reject" || kind === "info") && !note.trim()) {
            setError(t("noteRequired"));
            return;
        }
        setBusy(true);
        setError(null);
        setNotice(null);
        try {
            if (kind === "approve") await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adminApi"].approveKyc(current.kycId);
            else if (kind === "reject") await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adminApi"].rejectKyc(current.kycId, note.trim());
            else await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["adminApi"].requestInfoKyc(current.kycId, note.trim());
            setNotice(kind === "approve" ? t("approveNotice", {
                name: current.fullName ?? current.email ?? `KYC #${current.kycId}`
            }) : kind === "reject" ? t("rejectNotice") : t("infoNotice"));
            setNote("");
            await load();
        } catch (err) {
            setError(err instanceof __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ApiError"] ? err.message : t("actionError"));
        } finally{
            setBusy(false);
        }
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "m-4 flex min-h-[calc(100vh-2rem)] overflow-x-hidden rounded-3xl border border-white/10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                className: "w-72 shrink-0 overflow-y-auto border-r border-white/10",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-b border-white/10 p-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-xs font-semibold uppercase tracking-wider text-white/40",
                            children: t("queueTitle", {
                                count: items.length
                            })
                        }, void 0, false, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 90,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                        lineNumber: 89,
                        columnNumber: 9
                    }, this),
                    loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "p-4 text-sm text-white/40",
                        children: t("loading")
                    }, void 0, false, {
                        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                        lineNumber: 94,
                        columnNumber: 21
                    }, this),
                    !loading && items.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "p-4 text-sm text-white/40",
                        children: t("emptyQueue")
                    }, void 0, false, {
                        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                        lineNumber: 96,
                        columnNumber: 11
                    }, this),
                    items.map((s)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>{
                                setSelectedId(s.kycId);
                                setNote("");
                                setError(null);
                                setNotice(null);
                            },
                            className: `flex w-full flex-col gap-1 border-b border-white/5 px-4 py-3 text-left transition-colors ${selectedId === s.kycId ? "bg-white/5" : "hover:bg-white/[0.03]"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center justify-between gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "truncate text-sm font-medium",
                                            children: s.fullName ?? s.email ?? `KYC #${s.kycId}`
                                        }, void 0, false, {
                                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                            lineNumber: 113,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: `shrink-0 rounded-full px-2 py-0.5 text-[10px] font-semibold ${STATUS_CLASS[s.status] ?? "bg-white/10 text-white/50"}`,
                                            children: s.status
                                        }, void 0, false, {
                                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                            lineNumber: 114,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 112,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-[11px] text-white/40",
                                    children: fmt(s.submittedAt, locale)
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 118,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, s.kycId, true, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 99,
                            columnNumber: 11
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                lineNumber: 88,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-1 flex-col overflow-y-auto p-6",
                children: !current ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-1 items-center justify-center text-sm text-white/40",
                    children: error ?? t("chooseProfile")
                }, void 0, false, {
                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                    lineNumber: 126,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-lg font-semibold",
                                            children: current.fullName ?? "—"
                                        }, void 0, false, {
                                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                            lineNumber: 133,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-sm text-white/40",
                                            children: [
                                                current.email,
                                                " · ",
                                                fmt(current.submittedAt, locale)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                            lineNumber: 134,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 132,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: `rounded-full px-3 py-1.5 text-xs font-semibold ${STATUS_CLASS[current.status] ?? "bg-white/10 text-white/50"}`,
                                    children: current.status
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 136,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 131,
                            columnNumber: 13
                        }, this),
                        current.cccdDuplicate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300",
                            children: t("duplicateWarning")
                        }, void 0, false, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 142,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                    label: t("identityNumber"),
                                    value: current.cccdNumber
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 148,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                    label: t("phone"),
                                    value: current.phone
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 149,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                    label: t("dob"),
                                    value: current.dob
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 150,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                    label: t("gender"),
                                    value: current.gender
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 151,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                    label: t("issueDate"),
                                    value: current.issueDate
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 152,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                    label: t("issuePlace"),
                                    value: current.issuePlace
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 153,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 147,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DocCard, {
                                    title: t("frontDoc"),
                                    kycId: current.kycId,
                                    which: "front",
                                    exists: !!current.frontImageUrl,
                                    analysis: current.frontImageAnalysis
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 157,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DocCard, {
                                    title: t("backDoc"),
                                    kycId: current.kycId,
                                    which: "back",
                                    exists: !!current.backImageUrl,
                                    analysis: current.backImageAnalysis
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 158,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DocCard, {
                                    title: t("selfieDoc"),
                                    kycId: current.kycId,
                                    which: "selfie",
                                    exists: !!current.selfieImageUrl,
                                    analysis: current.selfieImageAnalysis
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 159,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 156,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-6",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    className: "mb-1.5 block text-xs font-medium text-white/50",
                                    children: t("noteLabel")
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 163,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                                    rows: 3,
                                    value: note,
                                    onChange: (e)=>setNote(e.target.value),
                                    placeholder: t("notePlaceholder"),
                                    className: "w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm outline-none placeholder:text-white/30 focus:border-[var(--luxora-gold)]"
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 166,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 162,
                            columnNumber: 13
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300",
                            children: error
                        }, void 0, false, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 176,
                            columnNumber: 15
                        }, this),
                        notice && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4 rounded-xl border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-300",
                            children: notice
                        }, void 0, false, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 179,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mt-4 flex flex-wrap gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy,
                                    onClick: ()=>act("approve"),
                                    className: "rounded-full bg-green-500/10 px-5 py-2.5 text-sm font-semibold text-green-300 hover:bg-green-500/20 disabled:opacity-50",
                                    children: busy ? "..." : t("approve")
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 183,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy,
                                    onClick: ()=>act("info"),
                                    className: "rounded-full bg-blue-500/10 px-5 py-2.5 text-sm font-semibold text-blue-300 hover:bg-blue-500/20 disabled:opacity-50",
                                    children: t("requestInfo")
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 187,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    disabled: busy,
                                    onClick: ()=>act("reject"),
                                    className: "rounded-full bg-red-500/10 px-5 py-2.5 text-sm font-semibold text-red-300 hover:bg-red-500/20 disabled:opacity-50",
                                    children: t("reject")
                                }, void 0, false, {
                                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                                    lineNumber: 191,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                            lineNumber: 182,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true)
            }, void 0, false, {
                fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                lineNumber: 124,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
        lineNumber: 86,
        columnNumber: 5
    }, this);
}
_s(KycReviewClient, "cQRUISJYX8iDY0CUDtjqlcXqMg0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$use$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useLocale"]
    ];
});
_c = KycReviewClient;
function Info({ label, value }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "glass-panel rounded-xl px-4 py-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[11px] text-white/40",
                children: label
            }, void 0, false, {
                fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                lineNumber: 206,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-0.5 text-sm",
                children: value || "—"
            }, void 0, false, {
                fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                lineNumber: 207,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
        lineNumber: 205,
        columnNumber: 5
    }, this);
}
_c1 = Info;
function DocCard({ title, kycId, which, exists, analysis }) {
    _s1();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"])("staffKycReviewPage");
    const [src, setSrc] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [failed, setFailed] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "DocCard.useEffect": ()=>{
            if (!exists) return;
            let objectUrl = null;
            let cancelled = false;
            __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["kycApi"].imageBlob(kycId, which).then({
                "DocCard.useEffect": (blob)=>{
                    if (cancelled) return;
                    objectUrl = URL.createObjectURL(blob);
                    setSrc(objectUrl);
                }
            }["DocCard.useEffect"]).catch({
                "DocCard.useEffect": ()=>setFailed(true)
            }["DocCard.useEffect"]);
            return ({
                "DocCard.useEffect": ()=>{
                    cancelled = true;
                    if (objectUrl) URL.revokeObjectURL(objectUrl);
                }
            })["DocCard.useEffect"];
        }
    }["DocCard.useEffect"], [
        kycId,
        which,
        exists
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "glass-panel rounded-2xl p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2 flex items-center justify-between",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm font-semibold",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                        lineNumber: 250,
                        columnNumber: 9
                    }, this),
                    analysis && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: `text-[11px] font-semibold ${SEVERITY_CLASS[analysis.severity] ?? "text-white/50"}`,
                        children: t("risk", {
                            score: analysis.riskScore
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                        lineNumber: 252,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                lineNumber: 249,
                columnNumber: 7
            }, this),
            exists && src ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: src,
                target: "_blank",
                rel: "noreferrer",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                    src: src,
                    alt: title,
                    className: "h-36 w-full rounded-xl object-cover"
                }, void 0, false, {
                    fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                    lineNumber: 260,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                lineNumber: 258,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex h-36 items-center justify-center rounded-xl border border-dashed border-white/10 text-xs text-white/30",
                children: !exists ? t("noImage") : failed ? t("imageError") : t("imageLoading")
            }, void 0, false, {
                fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                lineNumber: 263,
                columnNumber: 9
            }, this),
            analysis?.signals?.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "mt-2 space-y-1",
                children: analysis.signals.slice(0, 3).map((sig, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        className: `text-[11px] ${SEVERITY_CLASS[sig.severity] ?? "text-white/50"}`,
                        children: [
                            "• ",
                            sig.message
                        ]
                    }, i, true, {
                        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                        lineNumber: 270,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
                lineNumber: 268,
                columnNumber: 9
            }, this) : null
        ]
    }, void 0, true, {
        fileName: "[project]/app/staff/kyc-review/KycReviewClient.tsx",
        lineNumber: 248,
        columnNumber: 5
    }, this);
}
_s1(DocCard, "U/IC3yQqPXl69HHOqbiGNDYhaKA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useTranslations"]
    ];
});
_c2 = DocCard;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "KycReviewClient");
__turbopack_context__.k.register(_c1, "Info");
__turbopack_context__.k.register(_c2, "DocCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_1bj4j0_._.js.map