(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/performance/MaterialSymbolsLoader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>MaterialSymbolsLoader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
const MATERIAL_SYMBOLS_URL = "https://fonts.googleapis.com/icon?family=Material+Symbols+Outlined";
function MaterialSymbolsLoader() {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MaterialSymbolsLoader.useEffect": ()=>{
            let link = document.querySelector(`link[href="${MATERIAL_SYMBOLS_URL}"]`);
            const revealIcons = {
                "MaterialSymbolsLoader.useEffect.revealIcons": ()=>{
                    document.documentElement.classList.add("material-symbols-ready");
                }
            }["MaterialSymbolsLoader.useEffect.revealIcons"];
            const loadStylesheet = {
                "MaterialSymbolsLoader.useEffect.loadStylesheet": ()=>{
                    if (link) {
                        if (link.sheet) revealIcons();
                        else link.addEventListener("load", revealIcons, {
                            once: true
                        });
                        return;
                    }
                    link = document.createElement("link");
                    link.rel = "stylesheet";
                    link.href = MATERIAL_SYMBOLS_URL;
                    link.addEventListener("load", revealIcons, {
                        once: true
                    });
                    document.head.appendChild(link);
                }
            }["MaterialSymbolsLoader.useEffect.loadStylesheet"];
            if (document.readyState === "complete") loadStylesheet();
            else window.addEventListener("load", loadStylesheet, {
                once: true
            });
            return ({
                "MaterialSymbolsLoader.useEffect": ()=>window.removeEventListener("load", loadStylesheet)
            })["MaterialSymbolsLoader.useEffect"];
        }
    }["MaterialSymbolsLoader.useEffect"], []);
    return null;
}
_s(MaterialSymbolsLoader, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = MaterialSymbolsLoader;
var _c;
__turbopack_context__.k.register(_c, "MaterialSymbolsLoader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=components_performance_MaterialSymbolsLoader_tsx_0tj1ug1._.js.map